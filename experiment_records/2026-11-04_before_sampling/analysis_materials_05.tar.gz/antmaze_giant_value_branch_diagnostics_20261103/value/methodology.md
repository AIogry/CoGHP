# Value 地图诊断方法与边界

本分析比较 v0/v1/v2 × H2L1M1/H4L2M3 六组 β=3、seed0、1M checkpoint。每个版本在独立进程内导入它自己的冻结源码；在物理 GPU1 仅做前向查询，不训练、不写 checkpoint，前后 SHA256 一致。

## 查询对象

- 当前网络的两头 V 取算术平均，和 high/low advantage 加权所使用的 value 一致。不是 target value，也不是 Bellman backup 中的两头最小值。
- 每个 task 使用官方评估 episode0 的完整 goal observation，保留全部 29 维。已经验证六个模型使用的初始完整状态和 goal 逐元素相同。
- 主图 `task_N_dense.png`：固定该 task episode0 初始状态的非 XY 分量（姿态、关节、速度等），只替换 XY。每 0.5 世界单位一个点，总计 5504 个可通行点；墙体遮罩。**这是合成状态切片，不是机器人实际走过地图的轨迹，也未证明每个姿态与墙边几何兼容。**
- 支持图 `task_N_validation.png`：从验证集真实完整状态按通行格分层、每格最多256条取样，共 21389 条、覆盖86格，每格49–256条。所有模型使用完全相同的样本。每格显示 mean-twin-V 的中位数，保留姿态/速度/动作阶段差异，而非把机器人压成 XY。
- `task_N_iqr.png` 显示上述每格 IQR。它混合了格内 XY、pose、velocity 的变化，不能单独解释成 pose 敏感性，也不是统计置信区间。验证样本沿轨迹相关。
- 密集切片和验证中位数图在同一 task 内共享原始 V 色标，六个模型均相同；没有逐图自动调整色阶。
- `task_N_rank.png` 是每个模型单独计算的 value 百分位，用于查看空间排序。**它主动移除了原始数值差异，不能用于比较 value 的绝对大小。**

## 正确性参照与不应作出的推断

- BFS 采用 maze 四邻接可通行格，作为几何距离代理。Spearman 比较 cell-center / validation median V 与负 BFS 距离；邻接一致率检查一步更靠近 goal 的格是否具有更高 V。几何最短距离不包含 ant 朝向、速度、转弯、动力学和执行策略，不是环境时间最优值的真值。
- 非 goal 局部极大值定义为一个格的 V 严格大于全部相邻通行格（阈值1e-6），只排除 goal 格，不排除邻近 goal 格。它可以提示局部排序异常，但不能单独证明真实 actor 会被吸住。
- 固定初始姿态切片在 goal XY 上未必是完整 goal 状态。本分析分别保存 `V_self_goal=V(g,g)`、`V_goalxy_with_initial_pose`、`V_initial`。训练 relabel 的成功标签按状态索引重合，而正式环境成功按 XY 距离判定。因此同 XY、不同非 XY 状态的 V 不必等于0。
- `task_N_heads.png` 显示两头绝对差，**它不是经过校准的不确定性**，两头一致也可能共同错误。
- `task_N_goalpose.png` 取官方前四个 episode 的 goal 非 XY 分量，保持 XY 等于 episode0 goal，再在同样验证状态上查询；显示四种 goal 下各格中位数的极差。它是目标姿态敏感性的有限扰动探针，不是所有目标姿态的范围。
- 热力图能发现空间结构、尺度或局部排序问题，但不能单独证明 value 全部正确，不能把 v0-v2 policy 成功率差异全部归因于 value，也不直接验证候选 latent subgoal 的可达性。

## 输出

- `summary.json`：逐 task/模型的统计、图列表及完整 provenance。
- `queries.npz`：相同输入点、完整状态、goal、取样索引、BFS与覆盖率。
- `v*_m*_values.npz`：全部原始双头前向结果；validation_heads 形状为 task×goal-pose-variant×head×sample。
- `task_N_v*_m*_maps.npz`：用于作图的各地图矩阵、四种目标姿态下的验证格中位数、25/75分位数。
- `v*_provenance.json`：checkpoint 源路径、前后哈希、冻结代码签名、backend 和完整配置。
- `analysis_code/`：本次可重复运行的采样、推理、统计作图脚本；没有修改生产代码。

## 姿态构成的追加核验

全体验证状态地图有明显格间不连续，检查发现部分格子包含较高比例的低趴/倾倒姿态。例如 task5 的格(4,5)，该格样本 torso height 中位数0.257，原始 V 近-99；相邻格(5,6)高度中位数0.544，V约-76。因此无条件格中位数的几何排序差异不能全部归因于 critic 错误。

追加 `task_N_upright.png`：仍使用原来的同一批前向结果，明确选择 torso z>=0.4、归一化 quaternion 的 body-up cosine>=0.5 的真实状态。这是描述性姿态筛选，**不是环境定义的健康标签，更不是基于 V 或模型成绩筛选**。18539/21389条满足条件，86格均至少16条；图使用与主图相同原始色标。`upright_coverage.png`提供样本数、保留比例和原始高度分布。z阈值0.35/0.40/0.45的敏感性分析保存在`upright_support.json`，本次主要几何统计相近。仍未控制关节/速度/朝向/格内XY等全部变量，不能把 upright 几何图当作真实最优 value。

红色叉号标注严格局部极大值，可能包含饱和远场的很小差异。`summary.json`额外保存每个峰高于最佳邻格的幅度，以及幅度>=1、>=2的计数；`geometry_summary_upright.png`仅统计幅度>=1的峰。它们是空间异常候选，不是已经证明的策略吸引点。

复现顺序：`prepare.py` → 为每个版本独立运行 `query_values.py --version v0/v1/v2` → `summarize_render.py` → `upright_support.py` → `peak_prominence.py` → `finalize.py`。推理脚本需 `CUDA_VISIBLE_DEVICES=1 JAX_PLATFORMS=cuda XLA_PYTHON_CLIENT_PREALLOCATE=false`；其它脚本只用CPU。全部脚本均在本目录，原始checkpoint保持不变。

## 已有分支轨迹的配对 critic 查询

`paired_path_values.py --version v0/v1/v2` 在三个独立CPU进程载入各版本冻结M3模型，读取branch目录下两个源native轨迹和同名case.npz中的exact goal及fork observation。真实完整状态与“轨迹XY+固定fork非XY”两种输入都查询三代critic，不更新网络、不运行环境。`summarize_paired_paths.py`保存Spearman、upright筛选对照、value起终/范围和原始双头数组。输出`paired_path_value_checks.json/.npz`。这是真正固定输入的模型比较，不能与各模型各自生成的路线统计混为一谈。
