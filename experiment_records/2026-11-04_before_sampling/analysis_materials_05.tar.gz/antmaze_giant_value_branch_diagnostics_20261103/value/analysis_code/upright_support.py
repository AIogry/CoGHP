import json,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value');q=np.load(ROOT/'queries.npz');grid=q['grid'];free=q['free_cells'];cells=q['validation_cells'];obs=q['validation_observations'];D=json.loads((ROOT/'summary.json').read_text());models=[(v,m) for m in [1,3] for v in ['v0','v1','v2']]
quat=obs[:,3:7];quat=quat/np.linalg.norm(quat,axis=1,keepdims=True);body_up=1-2*(quat[:,1]**2+quat[:,2]**2);upright=(obs[:,2]>=.4)&(body_up>=.5)
index={tuple(c):i for i,c in enumerate(free)};neighbors=[[] for c in free];edges=[]
for k,(i,j) in enumerate(free):
 for c in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
  if c in index:
   z=index[c];neighbors[k].append(z)
   if z>k:edges.append((k,z))
edges=np.array(edges);sel=[(cells==c).all(1) for c in free];counts=np.array([np.sum(s&upright) for s in sel]);fraction=counts/np.array([s.sum() for s in sel]);min_n=16

def matrix(a):
 z=np.full(grid.shape,np.nan);z[free[:,0],free[:,1]]=a;return z

def geom(vals,dist):
 finite=np.isfinite(vals)&np.isfinite(dist);delta=vals[edges[:,0]]-vals[edges[:,1]];dp=dist[edges[:,1]]-dist[edges[:,0]];ok=np.isfinite(delta)&(dp!=0)
 peaks=[k for k in range(len(free)) if dist[k]>0 and np.isfinite(vals[k]) and all(np.isfinite(vals[z]) for z in neighbors[k]) and vals[k]>np.max(vals[neighbors[k]])+1e-6]
 return dict(spearman_to_negative_bfs=float(spearmanr(vals[finite],-dist[finite]).statistic),neighbor_correct_fraction=float(np.mean(delta[ok]*dp[ok]>1e-6)),neighbor_edges=int(ok.sum()),finite_cells=int(finite.sum()),non_goal_local_maxima_count=len(peaks),non_goal_local_maxima=[dict(cell=free[k].tolist(),xy=q['centers'][tuple(free[k])].tolist(),bfs_distance=float(dist[k]),value=float(vals[k])) for k in peaks])
result={'selection_rule':'actual held-out states, z>=0.4 and normalized quaternion body-up cosine>=0.5; descriptive upright subset, not environment success/health or critic-derived filtering','minimum_count_per_cell':min_n,'total_samples':len(obs),'upright_samples':int(upright.sum()),'upright_fraction':float(upright.mean()),'cells_with_at_least_16':int(np.sum(counts>=min_n)),'cell_counts':matrix(counts).tolist(),'cell_upright_fraction':matrix(fraction).tolist(),'results':{}}
colors=plt.get_cmap('viridis').copy();colors.set_bad('#dadfe3');plt.rcParams.update({'font.size':10,'savefig.dpi':180})
for t in range(5):
 records={};result['results'][str(t+1)]=records;dist=q['bfs'][t][free[:,0],free[:,1]];fig,axes=plt.subplots(2,3,figsize=(15,8.8),sharex=True,sharey=True,layout='constrained');lo,hi=D['tasks'][str(t+1)]['shared_raw_color_range']
 for ax,(v,m) in zip(axes.flat,models):
  key=f'{v}_m{m}';values=np.load(ROOT/f'{key}_values.npz')['validation_heads'][t,0].mean(0)
  med=np.array([np.median(values[s&upright]) if n>=min_n else np.nan for s,n in zip(sel,counts)]);gm=geom(med,dist);sensitivity={}
  for thresh in [.35,.4,.45]:
   mask=(obs[:,2]>=thresh)&(body_up>=.5);n=np.array([np.sum(s&mask) for s in sel]);mv=np.array([np.median(values[s&mask]) if nn>=min_n else np.nan for s,nn in zip(sel,n)]);sensitivity[str(thresh)]=geom(mv,dist)
  records[key]=dict(geometry=gm,height_threshold_sensitivity=sensitivity,upright_value_median=float(np.median(values[upright])),other_value_median=float(np.median(values[~upright])))
  D['tasks'][str(t+1)][key]['validation_upright_cell_median']=gm
  np.savez_compressed(ROOT/f'task_{t+1}_{key}_upright.npz',median=matrix(med),counts=matrix(counts),upright_fraction=matrix(fraction))
  im=ax.imshow(matrix(med),origin='lower',extent=(-6,58,-6,42),cmap=colors,vmin=lo,vmax=hi,interpolation='nearest');ax.set(aspect='equal',xlabel='x (world units)',ylabel='y (world units)',xlim=(-6,58),ylim=(-6,42));ax.set_xticks([0,20,40,52]);ax.set_yticks([0,12,24,36]);ax.scatter(*q['poses'][t,:2],s=32,c='white',edgecolor='black',linewidth=.8);ax.scatter(*q['goals'][t,:2],marker='*',s=150,c='#ff5757',edgecolor='black',linewidth=.6)
  for z in gm['non_goal_local_maxima']:ax.scatter(*z['xy'],marker='x',s=28,c='#ff6262',linewidth=1.3)
  ax.set_title(f'{v} / '+('H2 L1 M1' if m==1 else 'H4 L2 M3')+f"\nrho={gm['spearman_to_negative_bfs']:.3f}, edge correct={gm['neighbor_correct_fraction']:.1%}")
 fig.colorbar(im,ax=axes,label='Cell median of mean twin V; raw scale shared with main maps',shrink=.83,pad=.02);fig.suptitle(f'Task {t+1}: held-out upright-state subset\nz >= 0.4, body-up cosine >= 0.5; minimum 16 states/cell; descriptive pose filter, not a health guarantee',fontsize=12);fig.savefig(ROOT/f'task_{t+1}_upright.png');plt.close(fig);D['figures'].append(f'task_{t+1}_upright.png')
fig,axes=plt.subplots(1,3,figsize=(16,4.6),layout='constrained')
for ax,a,title in zip(axes,[matrix(counts),matrix(fraction),matrix(np.array([np.median(obs[s,2]) for s in sel]))],['Actual upright sample count / cell','Fraction passing descriptive upright filter','All-state median torso height / cell']):
 im=ax.imshow(a,origin='lower',extent=(-6,58,-6,42),cmap=colors,interpolation='nearest');ax.set(aspect='equal',xlabel='x',ylabel='y',title=title);fig.colorbar(im,ax=ax,shrink=.75)
fig.savefig(ROOT/'upright_coverage.png');plt.close(fig)
def json_safe(value):
 if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
 if isinstance(value,list):return [json_safe(v) for v in value]
 if isinstance(value,float) and not np.isfinite(value):return None
 return value
(ROOT/'upright_support.json').write_text(json.dumps(json_safe(result),indent=2,allow_nan=False)+'\n');D['upright_support_summary']={k:v for k,v in result.items() if k not in ['results','cell_counts','cell_upright_fraction']};D['provenance']['analysis_code_sha256']['upright_support.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(ROOT/'summary.json').write_text(json.dumps(D,indent=2)+'\n')
print('upright',result['upright_samples'], '/',len(obs),'supported cells',result['cells_with_at_least_16'])
for t,rows in result['results'].items():print('task',t,[(k,round(v['geometry']['spearman_to_negative_bfs'],3),round(v['geometry']['neighbor_correct_fraction'],3)) for k,v in rows.items()])
