import os,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value')
q=np.load(ROOT/'queries.npz');grid=q['grid'];free=q['free_cells'];centers=q['centers'];cells=q['validation_cells'];mask=q['dense_mask'];N=len(free)
models=[(v,m) for m in [1,3] for v in ['v0','v1','v2']]
index={tuple(c):i for i,c in enumerate(free)};edges=[];neighbors=[[] for _ in free]
for k,(i,j) in enumerate(free):
 for other in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
  if other in index:
   z=index[other];neighbors[k].append(z)
   if z>k:edges.append((k,z))
edges=np.array(edges);data_masks=[(cells[:,0]==i)&(cells[:,1]==j) for i,j in free]
def to_grid(vals):
 z=np.full(grid.shape,np.nan);z[free[:,0],free[:,1]]=vals;return z
def geo_metrics(vals,dist):
 delta=vals[edges[:,0]]-vals[edges[:,1]];progress=dist[edges[:,1]]-dist[edges[:,0]];valid=np.isfinite(delta)&np.isfinite(progress)&(progress!=0);ties=np.abs(delta)<=1e-6
 maxima=[i for i in range(N) if dist[i]>0 and len(neighbors[i])>0 and np.isfinite(vals[i]) and vals[i]>np.max(vals[neighbors[i]])+1e-6]
 return dict(spearman_to_negative_bfs=float(spearmanr(vals,-dist).statistic),neighbor_correct_fraction=float(np.mean(delta[valid]*progress[valid]>1e-6)),neighbor_tie_fraction=float(np.mean(ties[valid])),neighbor_edges=int(valid.sum()),non_goal_local_maxima_count=len(maxima),non_goal_local_maxima=[dict(cell=free[i].tolist(),xy=centers[tuple(free[i])].tolist(),bfs_distance=float(dist[i]),value=float(vals[i])) for i in maxima],value_min=float(np.min(vals)),value_max=float(np.max(vals)))
summary={'model_order':[f'{v}_m{m}' for v,m in models],'geometry_edges':len(edges),'tasks':{},'methods':{'value_reduction':'arithmetic mean of current twin V heads, matching high/low advantage weighting; not target V or min-head backup','state_sampling':'task initial full observation with only XY replaced; no physics rollout at synthetic grid states','validation_sampling':'same deterministic per-cell sample of held-out valid observations, cap 256/cell, no model-conditioned sample selection','geometry':'undirected four-neighbor traversable-cell graph; BFS distance is geometry proxy, not time-optimal value ground truth','local_maximum':'strictly greater than all adjacent free-cell values, excludes goal cell only','head_disagreement':'absolute twin-head difference; not calibrated epistemic uncertainty','goal_pose_sensitivity':'four official goal non-XY variants with exact episode0 goal XY; no new goal environments created'},'figures':[]}
all_maps={}
for task in range(5):
 T={};summary['tasks'][str(task+1)]=T;dist=q['bfs'][task][free[:,0],free[:,1]]
 for v,m in models:
  key=f'{v}_m{m}';raw=np.load(ROOT/f'{key}_values.npz');dense=raw['dense_heads'][task].mean(0);cv=raw['center_heads'][task].mean(0);valid=raw['validation_heads'][task].mean(1);assert valid.shape==(4,len(cells));vmed=np.array([[np.median(vals[sel]) for sel in data_masks] for vals in valid]);p25=np.array([np.quantile(valid[0][sel],.25) for sel in data_masks]);p75=np.array([np.quantile(valid[0][sel],.75) for sel in data_masks]);iqr=p75-p25
  disagreement=np.abs(raw['validation_heads'][task,0,0]-raw['validation_heads'][task,0,1]);headmed=np.array([np.median(disagreement[sel]) for sel in data_masks]);pose_range=vmed.max(0)-vmed.min(0)
  edgesigns=np.sign(vmed[:,edges[:,0]]-vmed[:,edges[:,1]]);poseflips=np.any(edgesigns!=edgesigns[0],axis=0)
  synthsign=np.sign(cv[edges[:,0]]-cv[edges[:,1]]);dataagree=np.mean(synthsign==edgesigns[0])
  metric={'synthetic_center':geo_metrics(cv,dist),'validation_cell_median':geo_metrics(vmed[0],dist),'V_self_goal':float(raw['self_goal_heads'][task].mean()),'V_goalxy_with_initial_pose':float(raw['goalxy_resetpose_heads'][task].mean()),'V_initial':float(raw['start_heads'][task].mean()),'validation_within_cell_IQR_median':float(np.median(iqr)),'validation_within_cell_IQR_max':float(np.max(iqr)),'validation_head_absdiff_median':float(np.median(disagreement)),'validation_head_absdiff_p95':float(np.quantile(disagreement,.95)),'goal_pose_cell_median_range_median':float(np.median(pose_range)),'goal_pose_cell_median_range_max':float(np.max(pose_range)),'goal_pose_neighbor_direction_flip_fraction':float(np.mean(poseflips)),'synthetic_vs_validation_neighbor_sign_agreement':float(dataagree),'dense_value_min':float(np.nanmin(dense)),'dense_value_max':float(np.nanmax(dense))}
  T[key]=metric
  rank=np.full_like(dense,np.nan);from scipy.stats import rankdata
  rank[mask]=(rankdata(dense[mask])-1)/(mask.sum()-1)
  all_maps[task,key]=dict(dense=dense,validation=to_grid(vmed[0]),iqr=to_grid(iqr),heads=to_grid(headmed),goalpose=to_grid(pose_range),rank=rank,centers=to_grid(cv))
  np.savez_compressed(ROOT/f'task_{task+1}_{key}_maps.npz',**all_maps[task,key],validation_goal_variant_medians=vmed,validation_p25=p25,validation_p75=p75)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
colors=plt.get_cmap('viridis').copy();colors.set_bad('#dadfe3')
def base(ax,t):
 ax.set(aspect='equal',xlim=(-6,58),ylim=(-6,42),xlabel='x (world units)',ylabel='y (world units)');ax.set_xticks([0,20,40,52]);ax.set_yticks([0,12,24,36]);ax.scatter(*q['poses'][t,:2],s=32,c='white',edgecolor='black',linewidth=.8,zorder=5);ax.scatter(*q['goals'][t,:2],marker='*',s=150,c='#ff5757',edgecolor='black',linewidth=.6,zorder=5)
def panels(task,kind,vmin,vmax,label,title,subtitle):
 fig,axes=plt.subplots(2,3,figsize=(15,8.8),sharex=True,sharey=True,layout='constrained')
 for ax,(v,m) in zip(axes.flat,models):
  key=f'{v}_m{m}';a=all_maps[task,key][kind];im=ax.imshow(a,origin='lower',extent=(-6,58,-6,42),vmin=vmin,vmax=vmax,cmap=colors,interpolation='nearest');base(ax,task);met=summary['tasks'][str(task+1)][key]
  if kind in ['dense','validation','rank']:
   mm=met['validation_cell_median'] if kind=='validation' else met['synthetic_center'];note=f"rho={mm['spearman_to_negative_bfs']:.3f}, edge correct={mm['neighbor_correct_fraction']:.1%}"
   for z in mm['non_goal_local_maxima']:ax.scatter(*z['xy'],marker='x',s=28,c='#ff6262',linewidth=1.3,zorder=6)
  elif kind=='iqr':note=f"median cell IQR={met['validation_within_cell_IQR_median']:.2f}"
  elif kind=='heads':note=f"median |V1-V2|={met['validation_head_absdiff_median']:.2f}"
  else:note=f"median range={met['goal_pose_cell_median_range_median']:.2f}"
  ax.set_title(f'{v} / '+('H2 L1 M1' if m==1 else 'H4 L2 M3')+'\n'+note,fontsize=10)
 fig.colorbar(im,ax=axes,label=label,shrink=.83,pad=.02)
 fig.suptitle(f'Task {task+1}: {title}\n{subtitle}',fontsize=12)
 path=ROOT/f'task_{task+1}_{kind}.png';fig.savefig(path);plt.close(fig);summary['figures'].append(path.name)
for task in range(5):
 vals=np.concatenate([all_maps[task,f'{v}_m{m}'][kind].ravel() for v,m in models for kind in ['dense','validation']]);vmin=float(np.floor(np.nanmin(vals)));vmax=float(np.ceil(np.nanmax(vals)))
 summary['tasks'][str(task+1)]['shared_raw_color_range']=[vmin,vmax]
 panels(task,'dense',vmin,vmax,'Mean twin V (higher = better)','fixed initial pose / velocity XY slice','Synthetic full states; only XY changes. White circle=start; red star=goal; red x=non-goal cell maximum.')
 panels(task,'validation',vmin,vmax,'Cell median of mean twin V','held-out full-state median','Same actual validation states for all models; 49-256 samples/cell. Geometry is a diagnostic proxy.')
 panels(task,'rank',0,1,'Within-panel value percentile (not raw value)','within-model percentile of synthetic slice','Each panel normalized separately to reveal spatial ordering; absolute value differences are removed.')
 for kind,label,title in [('iqr','Within-cell V interquartile range','held-out state dispersion (IQR)'),('heads','Median absolute twin-head difference','twin-head disagreement'),('goalpose','Range of cell medians across four goal poses','goal non-XY sensitivity at fixed goal XY')]:
  hi=max(np.nanmax(all_maps[task,f'{v}_m{m}'][kind]) for v,m in models)
  panels(task,kind,0,hi,label,title,'Common color scale across six panels. Dispersion and head disagreement are not calibrated uncertainty.')
# BFS reference and sampling coverage.
fig,axes=plt.subplots(2,3,figsize=(15,8.8),sharex=True,sharey=True,layout='constrained');bmax=np.nanmax(q['bfs'])
for t,ax in enumerate(axes.flat[:5]):
 im=ax.imshow(q['bfs'][t],origin='lower',extent=(-6,58,-6,42),vmin=0,vmax=bmax,cmap=colors,interpolation='nearest');base(ax,t);ax.set_title(f'Task {t+1}: geometric BFS distance')
fig.colorbar(im,ax=list(axes.flat[:5]),label='Four-neighbor cell steps; not environment time',shrink=.8)
ax=axes.flat[5];cov=np.where(grid==0,q['validation_counts'],np.nan);im=ax.imshow(cov,origin='lower',extent=(-6,58,-6,42),cmap=colors,vmin=0,vmax=256);ax.set(aspect='equal',title='Shared validation state coverage',xlabel='x',ylabel='y');fig.colorbar(im,ax=ax,label='Actual validation states / cell',shrink=.8);fig.suptitle('Geometry reference and data support | map geometry is used only for offline diagnostics',fontsize=12);fig.savefig(ROOT/'geometry_and_coverage.png');plt.close(fig)
# All-task summary matrices.
fig,axes=plt.subplots(1,3,figsize=(16,4.5),layout='constrained')
for ax,field,title,lo,hi in zip(axes,['spearman_to_negative_bfs','neighbor_correct_fraction','non_goal_local_maxima_count'],['Data-supported V vs -BFS: Spearman','Data-supported neighbor ordering','Non-goal local maxima (cell medians)'],[0,0,0],[1,1,None]):
 arr=np.array([[summary['tasks'][str(t+1)][f'{v}_m{m}']['validation_cell_median'][field] for v,m in models] for t in range(5)]);im=ax.imshow(arr,vmin=lo,vmax=hi,cmap='YlGnBu',aspect='auto');ax.set_xticks(range(6),[f'{v} M{m}' for v,m in models],rotation=35,ha='right');ax.set_yticks(range(5),[f'Task {t}' for t in range(1,6)]);ax.set_title(title)
 for i in range(5):
  for j in range(6):ax.text(j,i,f'{arr[i,j]:.3f}' if field=='spearman_to_negative_bfs' else (f'{arr[i,j]:.0%}' if field=='neighbor_correct_fraction' else f'{arr[i,j]:.0f}'),ha='center',va='center',color='white' if arr[i,j]>(hi if hi else arr.max())*.65 else 'black')
 fig.colorbar(im,ax=ax,shrink=.75)
fig.suptitle('Frozen checkpoints @ 1M, beta=3, seed0 | geometry consistency is not proof of calibrated value',fontsize=12);fig.savefig(ROOT/'geometry_summary.png');plt.close(fig)
summary['provenance']={'created_at':datetime.now(timezone.utc).isoformat(),'training_or_parameter_updates':False,'query_metadata':json.loads((ROOT/'queries_metadata.json').read_text()),'models':[x for v in ['v0','v1','v2'] for x in json.loads((ROOT/f'{v}_provenance.json').read_text())],'analysis_code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'analysis_code').glob('*.py')}}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({task:{k:{'rho':v['validation_cell_median']['spearman_to_negative_bfs'],'edges':v['validation_cell_median']['neighbor_correct_fraction'],'maxima':v['validation_cell_median']['non_goal_local_maxima_count']} for k,v in models.items() if k!='shared_raw_color_range'} for task,models in summary['tasks'].items()},indent=2))
