import os,sys,json,argparse,hashlib,inspect,time
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--version',required=True);args=p.parse_args();sys.dont_write_bytecode=True
ROOT=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value');SNAP=ROOT.parent.parent/'antmaze_giant_v2_diagnosis_20261103'/args.version/'snapshot'
manifest=json.loads((SNAP/'campaign.json').read_text());source=Path(manifest['source_dir']);sys.path[:0]=[str(source/'impls'),str(source)]
import jax
import jax.numpy as jnp
from agents.navigation import NavigationAgent
from utils.flax_utils import restore_agent
assert jax.default_backend()=='gpu',jax.devices()
assert Path(inspect.getfile(NavigationAgent)).is_relative_to(source)
assert os.environ['CUDA_VISIBLE_DEVICES']=='1'
q=np.load(ROOT/'queries.npz');free=q['free_cells'];mask=q['dense_mask'];metadata=[]
for run in sorted((SNAP/'runs').iterdir()):
 flags=json.loads((run/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()};m=cfg['num_subgoals'];state=json.loads((run/'run.json').read_text());checkpoint_meta=json.loads((run/'checkpoint_metadata.json').read_text());art=Path(state['run_dir'])/'artifacts';cp=art/'params_1000000.pkl';sha=hashlib.sha256(cp.read_bytes()).hexdigest()
 assert m in [1,3] and cfg['high_alpha']==3 if 'high_alpha' in cfg else m in [1,3]
 model=NavigationAgent.create(flags['seed'],q['validation_observations'][:1],q['actions_example'],cfg);model=restore_agent(model,str(art),1000000,checkpoint_meta,True)
 @jax.jit
 def query(model,obs,goal):return model.network.select('value')(obs,jnp.broadcast_to(goal,obs.shape))
 def batch(obs,goal):
  result=[]
  for off in range(0,len(obs),2048):
   x=obs[off:off+2048];n=len(x);x=np.pad(x,((0,2048-n),(0,0)),mode='edge');v=np.asarray(query(model,x.astype(np.float32),goal.astype(np.float32)));assert v.shape==(2,2048),v.shape;assert np.isfinite(v).all();result.append(v[:,:n])
  return np.concatenate(result,axis=1)
 dense=[];center=[];valid=[];selfv=[];startv=[];goalxy_pose=[]
 for t in range(5):
  pose=q['poses'][t];goal=q['goals'][t];obs=np.repeat(pose[None],mask.sum(),axis=0);obs[:,:2]=q['dense_xy'][mask];vv=batch(obs,goal);gridv=np.full((2,*mask.shape),np.nan,np.float32);gridv[:,mask]=vv;dense.append(gridv)
  obs=np.repeat(pose[None],len(free),axis=0);obs[:,:2]=q['centers'][free[:,0],free[:,1]];center.append(batch(obs,goal))
  valid.append(np.array([batch(q['validation_observations'],g) for g in q['goal_pose_variants'][t]]))
  selfv.append(batch(goal[None],goal)[:,0]);startv.append(batch(pose[None],goal)[:,0]);atgoal=pose.copy();atgoal[:2]=goal[:2];goalxy_pose.append(batch(atgoal[None],goal)[:,0])
  print(json.dumps(dict(version=args.version,M=m,task=t+1,dense_range=[float(np.nanmin(vv)),float(np.nanmax(vv))],Vgg=np.mean(selfv[-1]).item())),flush=True)
 cp_after=hashlib.sha256(cp.read_bytes()).hexdigest();assert sha==cp_after
 out=ROOT/f'{args.version}_m{m}_values.npz';np.savez_compressed(out,dense_heads=np.array(dense),center_heads=np.array(center),validation_heads=np.array(valid),self_goal_heads=np.array(selfv),start_heads=np.array(startv),goalxy_resetpose_heads=np.array(goalxy_pose))
 metadata.append(dict(version=args.version,M=m,method=run.name,checkpoint=str(cp),checkpoint_sha256_before=sha,checkpoint_sha256_after=cp_after,source_dir=str(source),source_signature=manifest['source']['code_signature'],backend=str(jax.devices()),physical_gpu=1,checkpoint_step=1000000,seed=flags['seed'],config=cfg,result_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),result=str(out)))
 del model;jax.clear_caches()
(ROOT/f'{args.version}_provenance.json').write_text(json.dumps(metadata,indent=2)+'\n');print('COMPLETE',args.version,flush=True)
