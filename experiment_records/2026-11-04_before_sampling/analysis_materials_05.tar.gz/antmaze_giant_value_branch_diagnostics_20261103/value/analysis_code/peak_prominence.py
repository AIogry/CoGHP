import json,hashlib
from pathlib import Path
import numpy as np
R=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value');D=json.loads((R/'summary.json').read_text());q=np.load(R/'queries.npz');grid=q['grid']
for t in range(1,6):
 for key in D['model_order']:
  for kind,field,path in [('centers','synthetic_center',R/f'task_{t}_{key}_maps.npz'),('validation','validation_cell_median',R/f'task_{t}_{key}_maps.npz'),('median','validation_upright_cell_median',R/f'task_{t}_{key}_upright.npz')]:
   a=np.load(path)[kind];row=D['tasks'][str(t)][key][field];prom=[]
   for p in row['non_goal_local_maxima']:
    i,j=p['cell'];vs=[a[ni,nj] for ni,nj in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)] if 0<=ni<grid.shape[0] and 0<=nj<grid.shape[1] and grid[ni,nj]==0];z=float(a[i,j]-np.max(vs));p['prominence_above_best_neighbor']=z;prom.append(z)
   row['local_max_prominence_median']=float(np.median(prom)) if prom else None;row['local_max_prominence_max']=max(prom) if prom else None;row['local_max_prominence_at_least_1_count']=sum(x>=1 for x in prom);row['local_max_prominence_at_least_2_count']=sum(x>=2 for x in prom)
D['provenance']['analysis_code_sha256']['peak_prominence.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(R/'summary.json').write_text(json.dumps(D,indent=2)+'\n')
for key in D['model_order']:
 print(key,[(t,D['tasks'][str(t)][key]['synthetic_center']['non_goal_local_maxima_count'],D['tasks'][str(t)][key]['synthetic_center']['local_max_prominence_at_least_1_count'],D['tasks'][str(t)][key]['validation_upright_cell_median']['local_max_prominence_at_least_1_count']) for t in range(1,6)])
