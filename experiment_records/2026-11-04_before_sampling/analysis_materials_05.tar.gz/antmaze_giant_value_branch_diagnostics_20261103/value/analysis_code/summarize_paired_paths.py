import json,hashlib
from pathlib import Path
from collections import deque
import numpy as np
from scipy.stats import spearmanr
R=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value');B=R.parent/'branch';q=np.load(R/'queries.npz');grid=q['grid'];D={'method':'same two source-native traces queried under all three M3 critics; exact saved full goals; no rollout/parameter updates','fixed_fork_control':'each trace observation XY retained; all non-XY components replaced by the exact saved fork observation (synthetic state slice)','caveats':['BFS is only geometric distance, not value ground truth.','Along-trajectory Spearman uses correlated time samples, not an independent statistical test.','Two selected traces do not represent every task or policy state distribution.','Values are mean of current twin heads, consistent with AWR.'],'cases':{},'provenance':{v:json.loads((R/f'paired_path_{v}_provenance.json').read_text()) for v in ['v0','v1','v2']}};arrays={}
def bfs(goal):
 ij=np.floor((goal[:2][::-1]+6)/4).astype(int);d=np.full(grid.shape,np.nan);d[tuple(ij)]=0;pending=deque([tuple(ij)])
 while pending:
  i,j=pending.popleft()
  for ni,nj in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
   if 0<=ni<grid.shape[0] and 0<=nj<grid.shape[1] and grid[ni,nj]==0 and np.isnan(d[ni,nj]):d[ni,nj]=d[i,j]+1;pending.append((ni,nj))
 return d
for case,actor in [('v0_task5_ep1_t546','v0'),('v2_task5_ep3_t115','v2')]:
 base=np.load(B/f'{case}.npz');trace=np.load(B/f'{case}__{actor}__native.npz');obs=trace['observations'];ij=np.floor((obs[:,:2][:,::-1]+6)/4).astype(int);dist=bfs(base['goal'])[ij[:,0],ij[:,1]];quat=obs[:,3:7]/np.linalg.norm(obs[:,3:7],axis=1,keepdims=True);up=1-2*(quat[:,1]**2+quat[:,2]**2);upright=(obs[:,2]>=.4)&(up>=.5);finite=np.isfinite(dist)
 C={'native_actor':actor,'steps':len(obs),'upright_fraction':float(upright.mean()),'bfs_start':float(dist[0]),'bfs_end':float(dist[-1]),'results':{}};D['cases'][case]=C;arrays[case+'__bfs']=dist;arrays[case+'__upright']=upright;arrays[case+'__xy']=obs[:,:2]
 for v in ['v0','v1','v2']:
  raw=np.load(R/f'paired_path_{v}.npz');C['results'][v]={}
  for kind in ['actual','fixedfork']:
   heads=raw[case+'__'+kind+'_heads'];vals=heads.mean(0);arrays[case+'__'+v+'__'+kind+'_heads']=heads;delta=np.diff(vals);progress=-np.diff(dist);moving=np.isfinite(progress)&(progress!=0);samecell=ij[:-1]==ij[1:]
   C['results'][v][kind]={'spearman_to_negative_bfs':float(spearmanr(vals[finite],-dist[finite]).statistic),'spearman_upright_only':float(spearmanr(vals[finite&upright],-dist[finite&upright]).statistic),'value_start':float(vals[0]),'value_end':float(vals[-1]),'value_min':float(vals.min()),'value_max':float(vals.max()),'value_delta':float(vals[-1]-vals[0]),'cell_transition_direction_agreement':float(np.mean(delta[moving]*progress[moving]>0)) if moving.any() else None,'cell_transition_count':int(moving.sum())}
 print(case,json.dumps(C,indent=2))
D['analysis_code_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'analysis_code/paired_path_values.py',Path(__file__)]};(R/'paired_path_value_checks.json').write_text(json.dumps(D,indent=2,allow_nan=False)+'\n');np.savez_compressed(R/'paired_path_value_checks.npz',**arrays)
