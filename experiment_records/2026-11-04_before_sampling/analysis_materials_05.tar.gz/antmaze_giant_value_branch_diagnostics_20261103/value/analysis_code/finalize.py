import json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value');D=json.loads((R/'summary.json').read_text());models=D['model_order']
fig,axes=plt.subplots(1,3,figsize=(16,4.5),layout='constrained')
for ax,field,title,lo,hi in zip(axes,['spearman_to_negative_bfs','neighbor_correct_fraction','local_max_prominence_at_least_1_count'],['Upright V vs -BFS: Spearman','Upright neighbor ordering','Non-goal local maxima: prominence >=1'],[0,0,0],[1,1,None]):
 arr=np.array([[D['tasks'][str(t+1)][k]['validation_upright_cell_median'][field] for k in models] for t in range(5)]);im=ax.imshow(arr,vmin=lo,vmax=hi,cmap='YlGnBu',aspect='auto');ax.set_xticks(range(6),[k.replace('_m',' M') for k in models],rotation=35,ha='right');ax.set_yticks(range(5),[f'Task {t}' for t in range(1,6)]);ax.set_title(title,fontsize=11)
 for i in range(5):
  for j in range(6):ax.text(j,i,f'{arr[i,j]:.3f}' if field=='spearman_to_negative_bfs' else (f'{arr[i,j]:.0%}' if field=='neighbor_correct_fraction' else f'{arr[i,j]:.0f}'),ha='center',va='center',color='white' if arr[i,j]>(hi if hi else arr.max())*.65 else 'black')
 fig.colorbar(im,ax=ax,shrink=.75)
fig.suptitle('Frozen models @1M, beta=3, seed0 | held-out upright subset (z>=0.4, body-up cosine>=0.5)\nGeometry agreement is a diagnostic proxy, not proof of value calibration or policy optimality',fontsize=12);fig.savefig(R/'geometry_summary_upright.png',dpi=180);plt.close(fig)
F={}
for k in models:
 F[k]={}
 for kind in ['synthetic_center','validation_cell_median','validation_upright_cell_median']:
  rows=[D['tasks'][str(t)][k][kind] for t in range(1,6)];F[k][kind]={f:float(np.mean([x[f] for x in rows])) for f in ['spearman_to_negative_bfs','neighbor_correct_fraction']};F[k][kind]['peaks_prominence_at_least_1_total']=sum(x['local_max_prominence_at_least_1_count'] for x in rows)
(R/'aggregate_metrics.json').write_text(json.dumps(F,indent=2)+'\n')
D['provenance']['analysis_code_sha256']['finalize.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();D['figures']+=['geometry_and_coverage.png','geometry_summary.png','geometry_summary_upright.png','upright_coverage.png'];(R/'summary.json').write_text(json.dumps(D,indent=2)+'\n')
