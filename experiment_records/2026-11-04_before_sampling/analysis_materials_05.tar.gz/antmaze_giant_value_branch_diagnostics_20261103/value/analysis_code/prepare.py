import os,sys,json,hashlib
from pathlib import Path
from collections import deque
import numpy as np
sys.dont_write_bytecode=True
ROOT=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_value_branch_diagnostics_20261103/value')
ATLAS=ROOT.parent.parent/'antmaze_giant_map_atlas_20261103'
DIAG=ROOT.parent.parent/'antmaze_giant_v2_diagnosis_20261103'
manifest=json.loads((DIAG/'v2/snapshot/campaign.json').read_text());source=Path(manifest['source_dir']);sys.path[:0]=[str(source/'impls'),str(source)]
from ogbench.utils import load_dataset
maze=json.loads((ATLAS/'maze.json').read_text());grid=np.array(maze['grid']);centers=np.array(maze['cell_xy']);free=np.argwhere(grid==0)
paths={v:json.loads((ATLAS/f'{v}_paths.json').read_text()) for v in ['v0','v1','v2']}
poses=[];goals=[];variants=[];initial=[]
for task in range(1,6):
 refs=paths['v0']['runs']['1']['tasks'][str(task)]['episodes']
 for v in paths:
  for m in ['1','3']:
   other=paths[v]['runs'][m]['tasks'][str(task)]['episodes']
   for e in range(4):
    for k in ['goal_observation','initial_observation']:
     assert np.array_equal(refs[e][k],other[e][k]),(v,m,task,e,k)
 pose=np.array(refs[0]['initial_observation'],np.float32);goal=np.array(refs[0]['goal_observation'],np.float32)
 poses.append(pose);goals.append(goal);vv=np.array([x['goal_observation'] for x in refs],np.float32);vv[:,:2]=goal[:2];variants.append(vv);initial.append(pose[:2])
poses=np.array(poses);goals=np.array(goals);variants=np.array(variants)
# Dense coordinates are interior pixel centers; nearest cell supplies wall mask.
x=np.arange(-6+.25,58,.5);y=np.arange(-6+.25,42,.5);xx,yy=np.meshgrid(x,y);xy=np.stack([xx,yy],-1);ij=np.floor((xy[...,::-1]+6)/4).astype(int);mask=grid[ij[...,0],ij[...,1]]==0
# Use true geometric cell centers separately for adjacency comparisons.
def bfs(g):
 d=np.full(grid.shape,np.nan);d[tuple(g)]=0;q=deque([tuple(g)])
 while q:
  i,j=q.popleft()
  for ni,nj in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
   if 0<=ni<len(grid) and 0<=nj<grid.shape[1] and grid[ni,nj]==0 and np.isnan(d[ni,nj]):d[ni,nj]=d[i,j]+1;q.append((ni,nj))
 return d
bfs_maps=np.array([bfs(np.floor((g[:2][::-1]+6)/4).astype(int)) for g in goals])
valpath=Path(manifest['datasets']['antmaze-giant-navigate-v0-val.npz']['path']);raw=load_dataset(valpath,compact_dataset=True);valid=np.flatnonzero(raw['valids']>0);obs=raw['observations'];cells=np.floor((obs[:,:2][:,::-1]+6)/4).astype(int)
rng=np.random.default_rng(20261103);selected=[];counts=np.zeros(grid.shape,int);available=np.zeros(grid.shape,int)
for i,j in free:
 ids=valid[(cells[valid,0]==i)&(cells[valid,1]==j)];available[i,j]=len(ids)
 choice=np.sort(rng.choice(ids,min(len(ids),256),replace=False));selected.extend(choice.tolist());counts[i,j]=len(choice)
selected=np.array(selected,int)
np.savez_compressed(ROOT/'queries.npz',poses=poses,goals=goals,goal_pose_variants=variants,x=x,y=y,dense_xy=xy,dense_mask=mask,grid=grid,centers=centers,free_cells=free,bfs=bfs_maps,validation_indices=selected,validation_observations=obs[selected],validation_cells=cells[selected],validation_counts=counts,validation_available=available,actions_example=raw['actions'][:1])
info=dict(seed=20261103,cell_world_units=4,dense_resolution=.5,dense_open_points=int(mask.sum()),free_cells=len(free),state_dim=obs.shape[1],validation_points=len(selected),samples_per_cell_cap=256,validation_cells_covered=int((counts>0).sum()),min_samples_per_cell=int(counts[grid==0].min()),validation_dataset_path=str(valpath),validation_dataset_sha256=hashlib.sha256(valpath.read_bytes()).hexdigest(),goal_source='exact task episode0 goal observations; verified equality across 6 models; all full components retained',dense_state_source='task episode0 initial state, only XY replaced; synthetic pose slice',goal_variants='4 official episode goal non-XY states, XY fixed to episode0; isolates goal-pose sensitivity',queries_sha256=hashlib.sha256((ROOT/'queries.npz').read_bytes()).hexdigest(),atlas_path_hashes={v:hashlib.sha256((ATLAS/f'{v}_paths.json').read_bytes()).hexdigest() for v in paths})
(ROOT/'queries_metadata.json').write_text(json.dumps(info,indent=2)+'\n');(ROOT/'maze.json').write_text(json.dumps(maze)+'\n');print(json.dumps(info,indent=2))
