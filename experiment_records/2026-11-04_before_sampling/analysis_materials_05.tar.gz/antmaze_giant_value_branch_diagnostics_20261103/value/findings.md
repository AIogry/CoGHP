# Value 地图实验：结果摘要

已完成六组 v0/v1/v2 × H2L1M1/H4L2M3，固定 β=3、seed0、1M checkpoint。五个任务的密集切片、真实状态地图、姿态筛选地图、色阶/离散度/双头/目标姿态诊断全部可查看；GPU1前向已结束，未训练或改变参数。

**整体地图结构存在，没有看到 v2 与 policy 成功率崩塌相当的全局 value 几何退化。** 固定初始姿态切片的 cell-center V 与负 BFS 的 Spearman 为0.879–0.990；真实 held-out upright 子集为0.900–0.988。但相邻格排序尚不完美，upright 地图为75.0%–85.2%，因此高全局相关不能替代岔路口局部排序检验。

以下是五个 task 等权平均（仅描述这5个固定task，不是独立seed统计）：

| 模型 | 固定姿态 Spearman | 真实 upright Spearman | upright 邻格方向一致率 |
|---|---:|---:|---:|
| v0 M1 | .972 | .974 | 80.7% |
| v1 M1 | .953 | .959 | 81.6% |
| v2 M1 | .962 | .965 | 80.5% |
| v0 M3 | .963 | .966 | 78.9% |
| v1 M3 | .953 | .959 | 81.6% |
| v2 M3 | .966 | .969 | 79.8% |

**重要混杂因素：倒地/姿态组成。** 未筛选真实验证状态的格中位数 Spearman仅0.712–0.833，邻格方向一致率61.4%–71.6%。这并不证明critic本身只有该准确率：例如task5格(4,5)样本高度中位数0.257且明显倾斜，V接近-99；邻格(5,6)高度中位数0.544、V约-76。保留描述性upright子集后，各模型地图恢复清晰。不能把不同格子的低姿态比例差异当作纯几何价值错误。

upright使用z>=0.4、body-up cosine>=0.5，在相同21389状态中保留18539，全部86格仍有至少16个样本。高度阈值0.35/0.40/0.45下统计相近。它不是环境健康判定，尚未控制所有动力学变量；有目的地保留原始全体图和覆盖图供审核。

**目标位置不等于完整目标状态。** 各模型V(g,g)约-0.033到-0.130，接近训练中的零终端目标；固定初始姿态移动到goalXY时，值可以低至-17.57。这不能仅凭二维图判定value错误。保留完整goal的状态语义与正式环境XY成功语义仍存在差别。

**局部峰需要看幅度。** 图中红叉是严格非goal局部极大值，可能包含远场饱和区域的微小差异。summary.json提供每峰高于最佳邻格的幅度，geometry_summary_upright.png只数幅度>=1的峰。这些是进一步分支检验的候选，而非证明actor必然陷入的陷阱。

建议优先阅读 `task_N_dense.png` 与 `task_N_upright.png` 并列，再看 `task_N_validation.png` 和 `upright_coverage.png` 理解全状态组成。`geometry_summary_upright.png` 用于汇总；原始 `geometry_summary.png` 是未筛选全体验证状态，不能作为纯几何value正确率。

原始数据和可复现方法见 `summary.json`、`queries.npz`、`v*_m*_values.npz`、`methodology.md`、`analysis_code/`。BFS仅用在离线诊断，未作为actor输入，也未修改正式评估。

## 同一分支轨迹、跨 critic 配对复核

最后补充两个已完成的 native 分支轨迹前向查询，**没有再运行 rollout**：同一条轨迹完整状态及 exact saved goal 分别交给v0/v1/v2的M3 critic。避免将“不同critic在不同访问区域上的表现”混作模型差异。

| 固定轨迹 | critic v0 / v1 / v2：真实完整状态 V 与负 BFS Spearman | 固定fork非XY控制 |
|---|---|---|
| v0 task5 episode1 t546 | .866 / .762 / .853 | .804 / .638 / .911 |
| v2 task5 episode3 t115 | **−.844 / −.875 / −.835** | **−.921 / −.921 / −.890** |

两条轨迹均99.7%满足上述upright规则，过滤后相关几乎不变；固定fork姿态/速度后第二条仍反向。由此，第二个岔路口区域的局部几何排序异常**不是v2独有退化，也不能用这条轨迹中的倒地/姿态变化解释**。三代critic都存在该问题，是后续online-value选择必须检验的局部错误候选。BFS仍是几何代理，不等价于动力学最优value；350个时间步高度相关，这不是独立样本显著性检验。

数据见 `paired_path_value_checks.json/.npz`，模型和exact input哈希在 `paired_path_v*_provenance.json`。own-critic重算与原轨迹记录最大差≤3.1e−5。
