import json
from pathlib import Path
from collections import deque
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
root=Path(__file__).resolve().parents[1];out=root/'clarifications';atlas=root.parent/'antmaze_giant_map_atlas_20261103'
maze=json.loads((atlas/'maze.json').read_text());grid=np.asarray(maze['grid']);centers=np.asarray(maze['cell_xy']);free=np.argwhere(grid==0)
paired=np.load(root/'value/paired_path_value_checks.npz');case='v2_task5_ep3_t115';goal=np.load(root/'branch'/f'{case}.npz')['goal'][:2]
points=[]
for name,t in [('A',240),('B',420)]:
 i=t-115;xy=paired[case+'__xy'][i];points.append({'label':name,'absolute_time':t,'xy':xy.tolist(),'bfs_cells':int(paired[case+'__bfs'][i]),'value_fixed_nonxy':{v:float(paired[case+'__'+v+'__fixedfork_heads'].mean(0)[i]) for v in ['v0','v1','v2']}})
values=[{'steps_to_goal':T,'ideal_discounted_value':-(1-.99**T)/.01,'fifty_step_improvement_advantage':(.99**(T-50)-.99**T)/.01,'high_beta3_weight_after_cap':min(100,float(np.exp(min(3*(.99**(T-50)-.99**T)/.01,np.log(100)))))} for T in [100,300,500,800,1000]]
facts={'baseline_for_future_research':'v0 training semantics; v1/v2 retained as diagnostic references; no rollback or new training applied','heatmap_smoothing':False,'query_spacing_world_units':.5,'free_query_count':5504,'display_interpolation':'nearest','state_dimensions':29,'fixed_dimensions':27,'local_pair':points,'goal_xy':goal.tolist(),'discount_illustration':values,'limits':['T formula is deterministic ideal arrival with cost-1 until goal, not a conversion of learned V to measured hitting time.','A/B are two selected actual XYs on the same observed trace; all nonXY components replaced with the identical fork observation and full goal held fixed.','BFS is only maze geometry, not exact dynamics-optimal value.']}
(out/'clarification_metrics.json').write_text(json.dumps(facts,indent=2)+'\n')
plt.rcParams.update({'font.size':11,'savefig.dpi':180})
fig,axes=plt.subplots(1,2,figsize=(12,5.7),gridspec_kw={'width_ratios':[1.35,1]})
ax=axes[0]
for (i,j),v in np.ndenumerate(grid):
 if v:ax.add_patch(Rectangle(centers[i,j]-2,4,4,facecolor='#dce1e6',edgecolor='none'))
def cell(xy):
 q=np.floor((np.asarray(xy)+6)/4).astype(int);return int(q[1]),int(q[0])
def route(start,finish):
 prev={start:None};q=deque([start])
 while q:
  u=q.popleft()
  if u==finish:break
  i,j=u
  for v in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
   a,b=v
   if 0<=a<grid.shape[0] and 0<=b<grid.shape[1] and grid[v]==0 and v not in prev:prev[v]=u;q.append(v)
 path=[];v=finish
 while v is not None:path.append(v);v=prev[v]
 return path[::-1]
colors={'A':'#246ea6','B':'#d97928'}
for point in reversed(points):
 path=route(cell(point['xy']),cell(goal));poly=np.array([point['xy'],*[centers[c] for c in path],goal]);ax.plot(poly[:,0],poly[:,1],color=colors[point['label']],lw=2.2,ls='--' if point['label']=='B' else '-',alpha=.8)
 ax.scatter(*point['xy'],c=colors[point['label']],s=65,zorder=5);ax.annotate(f"{point['label']}: {point['bfs_cells']} cells",point['xy'],xytext=(5,10 if point['label']=='A' else 12),textcoords='offset points',fontweight='bold',color=colors[point['label']])
ax.scatter(*goal,marker='*',s=160,c='#b72f43',zorder=6);ax.annotate('Goal',goal,xytext=(-8,-18),textcoords='offset points')
ax.set(xlim=(-6,58),ylim=(-6,42),aspect='equal',xlabel='x (world units)',ylabel='y (world units)',title='Same maze and goal; geometric shortest routes')
ax=axes[1];x=np.arange(2);width=.24
for i,v in enumerate(['v0','v1','v2']):
 y=[p['value_fixed_nonxy'][v] for p in points];bars=ax.bar(x+(i-1)*width,np.array(y)+100,bottom=-100,width=width,color=['#3069a8','#e59528','#c74455'][i],label=v+' critic')
 ax.bar_label(bars,labels=[f'{z:.1f}' for z in y],padding=3,fontsize=10)
ax.set_xticks(x,['A: 13 cells','B: 17 cells']);ax.set(ylim=(-100,-52),ylabel='V (larger / less negative is preferred)',title='All non-XY state components held identical');ax.legend(loc='upper left',fontsize=9);ax.grid(axis='y',alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.suptitle('Local ordering example: farther point B receives higher V in all three critics',fontsize=13);fig.tight_layout();fig.savefig(out/'local_ordering_explanation.png');plt.close(fig)
print(json.dumps(facts,indent=2))
