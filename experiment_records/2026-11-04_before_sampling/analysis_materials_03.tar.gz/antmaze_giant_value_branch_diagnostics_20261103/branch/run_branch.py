"""Read-only, frozen-checkpoint fork interventions. CPU simulator and policy."""
import os,sys,json,argparse,time,hashlib,copy
from pathlib import Path
from functools import partial
from collections import deque
os.environ.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',EGL_PLATFORM='surfaceless',PYTHONDONTWRITEBYTECODE='1')
os.environ.pop('MUJOCO_EGL_DEVICE_ID',None);sys.dont_write_bytecode=True
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--capture',action='store_true');p.add_argument('--run',action='store_true');p.add_argument('--counterfactual-value',action='store_true');p.add_argument('--budget',type=int,default=350);args=p.parse_args()
root=Path(__file__).resolve().parent;atlas=root.parent.parent/'antmaze_giant_map_atlas_20261103';snap=root.parent.parent/'antmaze_giant_v2_diagnosis_20261103'/args.version/'snapshot'
manifest=json.loads((snap/'campaign.json').read_text());source=Path(manifest['source_dir']);sys.path[:0]=[str(source/'impls'),str(source)]
import jax,jax.numpy as jnp,mujoco,ogbench
from agents.navigation import NavigationAgent
from utils.flax_utils import restore_agent
from utils.evaluation import derive_seed,supply_rng
assert jax.default_backend()=='cpu'
for directory in sorted((snap/'runs').iterdir()):
 flags=json.loads((directory/'flags.json').read_text())
 if flags['agent']['num_subgoals']==3:break
cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()};state=json.loads((directory/'run.json').read_text());repro=json.loads((directory/'reproducibility.json').read_text());metadata=json.loads((directory/'checkpoint_metadata.json').read_text());artifacts=Path(state['run_dir'])/'artifacts'
env=ogbench.make_env_and_datasets(flags['env_name'],env_only=True);base=env.unwrapped;ob,_=env.reset(seed=0)
agent=NavigationAgent.create(flags['seed'],ob[None].astype(np.float32),np.zeros((1,8),np.float32),cfg);agent=restore_agent(agent,str(artifacts),1000000,metadata,True)
checkpoint=artifacts/'params_1000000.pkl';hash_before=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
CASES=[dict(id='v0_task5_ep1_t546',version='v0',task=5,episode=1,t=546,junction=[5,5],old=[5,6],new=[4,5]),dict(id='v2_task5_ep3_t115',version='v2',task=5,episode=3,t=115,junction=[5,10],old=[5,11],new=[5,9])]
maze=json.loads((atlas/'maze.json').read_text());grid=np.asarray(maze['grid']);centers=np.asarray(maze['cell_xy']);cells=np.argwhere(grid==0);cellxy=centers[grid==0];ncols=grid.shape[1]
lookup={tuple(c):i for i,c in enumerate(cells)}
adj=[]
for r,c in cells:adj.append([lookup[(r+dr,c+dc)] for dr,dc in [(0,1),(0,-1),(1,0),(-1,0)] if (r+dr,c+dc) in lookup])
D=np.full((len(cells),len(cells)),999,dtype=np.int32)
for i in range(len(cells)):
 D[i,i]=0;q=deque([i])
 while q:
  x=q.popleft()
  for y in adj[x]:
   if D[i,y]==999:D[i,y]=D[i,x]+1;q.append(y)
def cell_id(xy):return int(np.argmin(np.sum((cellxy-np.asarray(xy))**2,axis=-1)))
def compact_cells(path):
 out=[];times=[]
 for t,xy in enumerate(path):
  i=cell_id(xy)
  if (not out or i!=out[-1]) and np.max(np.abs(np.asarray(xy)-cellxy[i]))<=1.6:out.append(i);times.append(t)
 return out,times
def metrics(path,goal,junction):
 ids,times=compact_cells(path);dg=D[:,cell_id(goal)];dist=np.array([dg[cell_id(x)] for x in path]);ji=lookup[tuple(junction)];exits=[]
 for k,i in enumerate(ids[:-1]):
  if i==ji:exits.append({'step':int(times[k+1]),'cell':cells[ids[k+1]].tolist()})
 returns=[]
 for a in range(len(ids)-1):
  if ids[a]!=ji:continue
  later=[b for b in range(a+2,len(ids)) if ids[b]==ji]
  if later:
   b=later[0];exc=int(max(D[ji,ids[c]] for c in range(a,b+1)));duration=times[b]-times[a]
   if exc>=2 and duration>=20:returns.append(dict(start=int(times[a]),end=int(times[b]),duration=int(duration),max_excursion_cells=exc))
 return dict(start_distance_cells=int(dist[0]),end_distance_cells=int(dist[-1]),best_distance_cells=int(dist.min()),net_progress_cells=int(dist[0]-dist[-1]),max_regression_cells=int(np.max(dist-np.minimum.accumulate(dist))),traversed_cells=int(sum(D[a,b] for a,b in zip(ids[:-1],ids[1:]))),stable_cell_transitions=len(ids)-1,branch_exit_changes=sum(exits[k]['cell']!=exits[k-1]['cell'] for k in range(1,len(exits))),junction_exits=exits,junction_returns=returns)

def elapsed_set(t):
 w=env
 while True:
  if hasattr(w,'__dict__') and '_elapsed_steps' in w.__dict__:w._elapsed_steps=t
  if not hasattr(w,'env'):break
  w=w.env

def save_state(case,obs,goal,seed):
 spec=mujoco.mjtState.mjSTATE_INTEGRATION;st=np.zeros(mujoco.mj_stateSize(base.model,spec));mujoco.mj_getState(base.model,base.data,st,spec)
 np.savez_compressed(root/(case['id']+'.npz'),integration=st,observation=obs,goal=goal,qpos=base.data.qpos.copy(),qvel=base.data.qvel.copy())
 meta=dict(case,episode_seed=int(seed),state_spec=int(spec),rng_state=copy.deepcopy(base.np_random.bit_generator.state),goal_xy=np.asarray(base.cur_goal_xy).tolist() if hasattr(base,'cur_goal_xy') else goal[:2].tolist())
 (root/(case['id']+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
 return meta

def restore_case(case):
 data=np.load(root/(case['id']+'.npz'));meta=json.loads((root/(case['id']+'.json')).read_text())
 env.reset(seed=meta['episode_seed'],options=dict(task_id=case['task'],render_goal=False));base.set_goal(goal_xy=np.asarray(meta['goal_xy']));base.np_random.bit_generator.state=copy.deepcopy(meta['rng_state'])
 mujoco.mj_setState(base.model,base.data,data['integration'],mujoco.mjtState(meta['state_spec']));mujoco.mj_forward(base.model,base.data);elapsed_set(case['t'])
 obs=base.get_ob();assert np.allclose(obs,data['observation'],rtol=0,atol=1e-10),np.max(np.abs(obs-data['observation']))
 return obs,data['goal']

@jax.jit
def native_action(agent,obs,goal):return agent.sample_actions(obs,goal,jax.random.PRNGKey(0),0.)
@jax.jit
def plan(agent,obs,goal):return agent.policy(obs[None],goal[None],jax.random.PRNGKey(0),temperature=0.,return_latents=True)[3][0]
@jax.jit
def value(agent,obs,goal):
 v=agent.network.select('value')(obs[None],goal[None]);return (v[0]+v[1])[0]/2
@jax.jit
def commanded_action(agent,obs,goal,targets):
 labels=agent.network.select('goal_rep')(jnp.concatenate([jnp.broadcast_to(obs,targets.shape),targets],-1))[None]
 dist=agent.policy(obs[None],goal[None],jax.random.PRNGKey(0),commands=labels,temperature=0.,chain_source='teacher')[1]
 return jnp.clip(dist.mode()[0],-1,1),labels[0]

if args.capture:
 original=json.loads((atlas/f'{args.version}_paths.json').read_text())
 for case in CASES:
  if case['version']!=args.version:continue
  entry=original['runs']['3']['tasks'][str(case['task'])]['episodes'][case['episode']];task_seed=derive_seed(repro['eval_seed'],case['task']);seed=derive_seed(task_seed,case['episode'],0);actor=supply_rng(agent.sample_actions,rng=jax.random.PRNGKey(derive_seed(task_seed,case['episode'],1)))
  ob,info=env.reset(seed=seed,options=dict(task_id=case['task'],render_goal=False));goal=info['goal'];path=[ob[:2].tolist()];saved=False
  for t in range(min(case['t']+args.budget,len(entry['path_xy'])-1)):
   if t==case['t']:save_state(case,ob,goal,seed);saved=True
   a=np.clip(np.asarray(actor(observations=ob,goals=goal,temperature=0.)),-1,1);ob,_,te,tr,inf=env.step(a);path.append(ob[:2].tolist())
   if te or tr:break
  assert saved
  original_error=float(np.max(np.abs(np.asarray(path)-np.asarray(entry['path_xy'][:len(path)]))))
  ob,goal=restore_case(case);forkpath=[ob[:2].tolist()]
  for t in range(len(path)-case['t']-1):
   a=np.asarray(native_action(agent,ob,goal));ob,_,te,tr,inf=env.step(a);forkpath.append(ob[:2].tolist())
   if te or tr:break
  replay_error=float(np.max(np.abs(np.asarray(forkpath)-np.asarray(path[case['t']:]))))
  result=dict(case=case,original_max_xy_error=original_error,restored_replay_max_xy_error=replay_error,verified_steps=len(forkpath)-1,passed=bool(original_error<1e-6 and replay_error<1e-6))
  (root/(case['id']+'_verification.json')).write_text(json.dumps(result,indent=2)+'\n');print('VERIFY',json.dumps(result),flush=True)
  if not result['passed']:raise ValueError('Replay diverged; interventions invalid')

if args.run:
 bank=np.load(atlas/'candidate_bank.npz');allobs=bank['observations'];allidx=bank['indices'];cellids=np.array([cell_id(o[:2]) for o in allobs]);selected=[]
 # Full spatially balanced atlas candidate bank. The smaller 688-state pilot is preserved separately.
 # Never select using model predictions, return, or validation labels.
 for i in range(len(cells)):
  ids=np.flatnonzero(cellids==i);selected.extend(ids[np.linspace(0,len(ids)-1,min(8,len(ids)),dtype=int)].tolist())
 selected=np.arange(len(allobs));candidate=allobs[selected];candidateidx=allidx[selected];np.savez_compressed(root/'projection_bank.npz',observations=candidate,indices=candidateidx)
 @jax.jit
 def project(agent,obs,commands):
  enc=agent.network.select('goal_rep')(jnp.concatenate([jnp.broadcast_to(obs,candidate.shape),jnp.asarray(candidate)],-1));ds=jnp.mean((commands[:,None]-enc[None])**2,-1);vals,ids=jax.lax.top_k(-ds,8);return ids,-vals
 result=dict(version=args.version,checkpoint=str(checkpoint),checkpoint_sha256=hash_before,source_signature=manifest['source']['code_signature'],backend='cpu',complete=False,budget=args.budget,projection_bank_size=len(candidate),projection_bank_policy='all 7692 full training states from prior spatially balanced atlas bank; same bank across models, no validation labels',cases={})
 for case in CASES:
  verify=json.loads((root/(case['id']+'_verification.json')).read_text());assert verify['passed']
  ob,goal=restore_case(case);test_t=time.monotonic();pr=np.asarray(plan(agent,ob,goal));project(agent,ob,pr)[0].block_until_ready();test_t=time.monotonic()-test_t;test_t2=time.monotonic()
  for _ in range(5):project(agent,ob,pr)[0].block_until_ready()
  print('BENCH',args.version,case['id'],len(candidate),'compile',test_t,'seconds_per_projection',(time.monotonic()-test_t2)/5,flush=True)
  cresult=dict(source_case=case,arms={},local_targets=[]);result['cases'][case['id']]=cresult
  arms=[('native',0),('projected_refresh',1),('hold10',10),('hold25',25),('hold50',50)]
  # Known geometry-supported exits, 2 cells from the junction where possible.
  ji=lookup[tuple(case['junction'])]
  for key in ['old','new']:
   ni=lookup[tuple(case[key])];neighbors=[i for i in adj[ni] if i!=ji];targetcell=neighbors[0] if neighbors else ni
   bankids=np.flatnonzero(cellids==targetcell);targetid=int(bankids[np.argmin(np.linalg.norm(allobs[bankids,:2]-cellxy[targetcell],axis=-1))]);target=allobs[targetid]
   cresult['local_targets'].append(dict(name=key,cell=cells[targetcell].tolist(),target_xy=target[:2].tolist(),train_index=int(allidx[targetid]),target_full_state=target.tolist()))
   arms.append(('known_'+key,0))
  for arm,hold in arms:
   ob,goal=restore_case(case);path=[ob[:2].tolist()];records=[];held=None;start=time.monotonic();local_target=None;success=False;local_reached=False;min_local=None
   if arm.startswith('known_'):
    local=next(x for x in cresult['local_targets'] if x['name']==arm[6:]);local_target=np.asarray(local['target_full_state'],np.float32);held=np.repeat(local_target[None],3,axis=0);min_local=float(np.linalg.norm(ob[:2]-local_target[:2]));budget=min(100,args.budget,1000-case['t'])
   else:budget=min(args.budget,1000-case['t'])
   for step in range(budget):
    pred=np.asarray(plan(agent,ob,goal));projids=None;projres=None;projected=None
    # Diagnostic native projection every 5 steps. For projected-refresh it is an actual intervention each step.
    refresh=(hold>0 and step%hold==0)
    if refresh or step%5==0:
     projids,projres=map(np.asarray,project(agent,ob,pred));projected=candidate[projids[:,0]]
     if refresh:held=projected.copy()
    if arm=='native':a=np.asarray(native_action(agent,ob,goal));command=pred
    else:a,command=map(np.asarray,commanded_action(agent,ob,goal,held))
    v=float(value(agent,ob,goal));assert np.isfinite(a).all() and np.isfinite(pred).all() and np.isfinite(v)
    records.append(dict(step=step,absolute_step=case['t']+step,observation=ob.tolist(),predicted_command=pred.tolist(),applied_command=command.tolist(),action=a.tolist(),value=v,refresh=bool(refresh),held_targets_xy=None if held is None else held[:,:2].tolist(),projected_targets_xy=None if projected is None else projected[:,:2].tolist(),projection_residual=None if projres is None else projres[:,0].tolist(),projection_top8_xy=None if projids is None else candidate[projids,:2].tolist()))
    ob,_,te,tr,info=env.step(a);path.append(ob[:2].tolist());success=bool(info['success'])
    if local_target is not None:
     distance=float(np.linalg.norm(ob[:2]-local_target[:2]));min_local=min(min_local,distance);local_reached=bool(distance<=base._goal_tol)
    if te or tr or local_reached:break
   metrics_row=metrics(path,goal[:2],case['junction']);metrics_row.update(steps=len(records),success=success,local_reached=local_reached,minimum_local_distance=min_local,action_saturation_fraction=float(np.mean(np.abs(np.array([r['action'] for r in records]))>=.999)),wall_seconds=time.monotonic()-start)
   row=dict(arm=arm,hold_steps=hold,summary=metrics_row,path_xy=path,final_observation=ob.tolist(),goal_observation=goal.tolist(),records=records)
   name=case['id']+'__'+args.version+'__'+arm;np.savez_compressed(root/(name+'.npz'),observations=np.asarray([r['observation'] for r in records]),predicted_commands=np.asarray([r['predicted_command'] for r in records]),applied_commands=np.asarray([r['applied_command'] for r in records]),actions=np.asarray([r['action'] for r in records]),values=np.asarray([r['value'] for r in records]),path_xy=np.asarray(path))
   # Full vectors in compressed numeric artifact; readable trace retains geometry/value/action metadata.
   for r in row['records']:
    for key in ['observation','predicted_command','applied_command']:r.pop(key)
   (root/(name+'.json')).write_text(json.dumps(row,separators=(',',':'),allow_nan=False)+'\n');cresult['arms'][arm]={'file':name+'.json','arrays':name+'.npz','summary':metrics_row};(root/(args.version+'_summary.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print('ARM',args.version,case['id'],arm,json.dumps(metrics_row),flush=True)
 result['complete']=True;result['checkpoint_unchanged']=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==hash_before;assert result['checkpoint_unchanged'];(root/(args.version+'_summary.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
if args.counterfactual_value:
 from scipy.stats import spearmanr
 @jax.jit
 def batch_value(agent,obs,goal):
  va,vb=agent.network.select('value')(obs,goal);return (va+vb)/2
 checks={}
 for case in CASES:
  if case['version']!=args.version:continue
  a=np.load(root/(case['id']+'__'+args.version+'__native.npz'));data=np.load(root/(case['id']+'.npz'));observations=a['observations'];goal=data['goal'];goals=np.broadcast_to(goal,observations.shape).copy();fixed=np.broadcast_to(data['observation'],observations.shape).copy();fixed[:,:2]=observations[:,:2];goalpose=goals.copy();goalpose[:,:2]=observations[:,:2];gdist=np.array([D[cell_id(o[:2]),cell_id(goal[:2])] for o in observations]);values={name:np.asarray(batch_value(agent,obs,goals)) for name,obs in [('actual',observations),('fixed_fork_pose',fixed),('fixed_goal_pose',goalpose)]};maxerr=float(np.max(np.abs(values['actual']-a['values'])));assert maxerr<1e-4,maxerr
  checks[case['id']]={name:dict(spearman_negative_graph_distance=float(spearmanr(v,-gdist).statistic),minimum=float(v.min()),maximum=float(v.max()),first=float(v[0]),last=float(v[-1])) for name,v in values.items()};checks[case['id']]['recorded_value_max_error']=maxerr;checks[case['id']]['caveat']='Counterfactual coordinate slice holds all non-XY dimensions constant; hybrids are diagnostic function queries, not guaranteed dynamically realizable full states.'
  np.savez_compressed(root/(case['id']+'_value_slices.npz'),**values,graph_distance=gdist,xy=observations[:,:2])
 (root/(args.version+'_value_slices.json')).write_text(json.dumps(checks,indent=2)+'\n');print('VALUE_SLICES',json.dumps(checks),flush=True)
env.close()
