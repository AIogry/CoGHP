import os,json,hashlib
from pathlib import Path
from collections import deque
os.environ['MPLCONFIGDIR']='/tmp/coghp-branch-matplotlib'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy.stats import spearmanr
r=Path(__file__).resolve().parent;atlas=r.parent.parent/'antmaze_giant_map_atlas_20261103';maze=json.load(open(atlas/'maze.json'));grid=np.array(maze['grid']);centers=np.array(maze['cell_xy']);cells=np.argwhere(grid==0);xy=centers[grid==0];lookup={tuple(c):i for i,c in enumerate(cells)}
adj=[]
for a,b in cells:adj.append([lookup[(a+da,b+db)] for da,db in [(0,1),(0,-1),(1,0),(-1,0)] if (a+da,b+db) in lookup])
D=np.full((len(cells),len(cells)),999,int)
for i in range(len(cells)):
 D[i,i]=0;q=deque([i])
 while q:
  a=q.popleft()
  for b in adj[a]:
   if D[i,b]==999:D[i,b]=D[i,a]+1;q.append(b)
def cid(z):return int(np.argmin(np.sum((xy-np.asarray(z))**2,axis=-1)))
def blocked_dist(start,goal,blocked):
 ds={start:0};q=deque([start])
 while q:
  a=q.popleft()
  if a==goal:return ds[a]
  for b in adj[a]:
   if b!=blocked and b not in ds:ds[b]=ds[a]+1;q.append(b)
 return None
def base(ax,case,goal):
 for (i,j),v in np.ndenumerate(grid):
  if v:ax.add_patch(Rectangle(centers[i,j]-2,4,4,color='#dce2e8',zorder=0))
 ax.scatter(*centers[tuple(case['junction'])],marker='s',s=60,c='black',zorder=5,label='junction')
 ax.scatter(*goal,marker='*',s=100,c='#dc2626',zorder=5,label='goal')
 ax.set(xlim=(-6,58),ylim=(-6,42),aspect='equal');ax.set_xticks([]);ax.set_yticks([])
summaries={v:json.load(open(r/(v+'_summary.json'))) for v in ['v0','v1','v2']}
assert all(x['complete'] for x in summaries.values())
report=dict(protocol='same full MuJoCo fork state; frozen M3 H4/L2 beta3 checkpoints; no training',versions=['v0','v1','v2'],projection_bank_size=7692,episodes=2,intervention_rollouts=42,case_details={},comparisons=[],local_target_results=[],limitations=[
'Two purposively selected fork states; not independent seeds or an estimate of official success rates.',
'Both starts belong to task5. Cross-model comparisons may expose off-policy posture/state distributions.',
'Native means exact original latent command. Projection arms replace all three command slots independently by nearest full training states; this changes the command distribution and may create inconsistent chains.',
'Hold means retain all three raw physical target states for N steps, re-encoding phi(current_observation,target) each step. Final goal stays fixed. No early refresh when a target is reached in this fixed-schedule diagnostic.',
'Compare hold against projected_refresh to distinguish persistence from projection. Native-versus-projected gap is substantial in some cases.',
'688-state pilot outputs are retained separately; reported main results use the full7692 training-state bank.',
'Known exit probes repeat one training-supported raw state in all3 slots. They test XY arrival within0.5 world units over100steps and preserve original final-goal token, not full-state feasibility or an isolated one-token intervention.',
'Traversal count sums shortest grid distances between accepted stable cell-core visits to cover occasional skipped cores; this is a geometry lower bound, not continuous physical path length.',
'Grid distance is a geometry-only proxy. Goal cell distance0 does not mean arrival within the true0.5-unit tolerance.',
'Projection is a diagnostic inverse mapping with ambiguity; inferred XY locations are not directly output by the network.',
'Value is the mean of the twin heads, matching high-advantage averaging; it is recorded without being used to choose actions.'
])
colors=['#2563eb','#a855f7','#059669','#d97706','#e11d48'];arms=['native','projected_refresh','hold10','hold25','hold50']
for caseid,cr in summaries['v0']['cases'].items():
 case=cr['source_case'];data=np.load(r/(caseid+'.npz'));goal=data['goal'][:2];ji=lookup[tuple(case['junction'])];gi=cid(goal)
 exits=[]
 for nei in adj[ji]:exits.append(dict(cell=cells[nei].tolist(),distance_to_goal_without_revisiting_junction=blocked_dist(nei,gi,ji),initial_xy=xy[nei].tolist()))
 report['case_details'][caseid]=dict(source=case,verification=json.load(open(r/(caseid+'_verification.json'))),junction_goal_shortest_cells=int(D[ji,gi]),exit_geometry=exits)
 fig,axes=plt.subplots(3,5,figsize=(20,10.6),constrained_layout=True)
 for vi,v in enumerate(report['versions']):
  for ai,arm in enumerate(arms):
   row=json.load(open(r/summaries[v]['cases'][caseid]['arms'][arm]['file']));a=np.load(r/summaries[v]['cases'][caseid]['arms'][arm]['arrays']);path=a['path_xy'];s=row['summary'];base(axes[vi,ai],case,goal)
   axes[vi,ai].plot(path[:,0],path[:,1],color=colors[ai],lw=1.6);axes[vi,ai].scatter(*path[0],s=30,c='black',marker='o',zorder=6);axes[vi,ai].scatter(*path[-1],s=35,c=colors[ai],marker='X',zorder=6)
   axes[vi,ai].set_title(f'{v} | {arm}\nremaining {s["end_distance_cells"]} cells; backslide {s["max_regression_cells"]}',fontsize=10)
   
   if arm!='native':
    held=np.array([z['held_targets_xy'][-1] for z in row['records']]);hdis=np.linalg.norm(a['observations'][:,:2]-held,axis=-1);refresh=np.array([z['refresh'] for z in row['records']]);s['nearest_held_target_within_0p5_fraction']=float(np.mean(hdis<=.5));s['nearest_held_target_within_0p5_not_refresh_fraction']=float(np.mean((hdis<=.5)&~refresh));s['nearest_held_target_within_1_fraction']=float(np.mean(hdis<=1));s['final_100step_xy_span']=float(np.ptp(path[-100:],axis=0).max())
   
   height=a['observations'][:,2];upcos=1-2*(a['observations'][:,4]**2+a['observations'][:,5]**2);upright=(height>=.4)&(upcos>=.5);s['height_min']=float(height.min());s['height_median']=float(np.median(height));s['body_up_cosine_min']=float(upcos.min());s['body_up_cosine_median']=float(np.median(upcos));s['upright_fraction']=float(upright.mean())
   s['minimum_goal_xy_distance']=float(np.linalg.norm(path-goal,axis=-1).min());s['final_goal_xy_distance']=float(np.linalg.norm(path[-1]-goal));report['comparisons'].append(dict(case=caseid,version=v,arm=arm,**s))
 fig.suptitle(f'{caseid} | 350-step paired fork interventions | all three raw target states held and re-encoded each step\nBlack dot: fork; black square: junction; red star: final goal; X: final position. Native and projected refresh are distinct controls.',fontsize=12)
 fig.savefig(r/(caseid+'_map.png'),dpi=140);plt.close(fig)
 fig,axes=plt.subplots(3,2,figsize=(15,10),constrained_layout=True)
 for vi,v in enumerate(report['versions']):
  for ai,arm in enumerate(arms):
   row=json.load(open(r/summaries[v]['cases'][caseid]['arms'][arm]['file']));a=np.load(r/summaries[v]['cases'][caseid]['arms'][arm]['arrays']);path=a['path_xy'];gd=np.array([D[cid(p),gi] for p in path]);axes[vi,0].plot(case['t']+np.arange(len(gd)),gd,c=colors[ai],label=arm,lw=1.3);axes[vi,1].plot(case['t']+np.arange(len(a['values'])),a['values'],c=colors[ai],lw=1.3)
  axes[vi,0].set(title=f'{v}: remaining graph cells (lower better)',ylabel='cells',xlabel='absolute environment step');axes[vi,1].set(title=f'{v}: learned V(current full state, final goal)',ylabel='V',xlabel='absolute environment step');axes[vi,0].grid(alpha=.2);axes[vi,1].grid(alpha=.2)
 axes[0,0].legend(ncol=3,fontsize=8);fig.suptitle(caseid+' | progress and value by intervention',fontsize=13);fig.savefig(r/(caseid+'_timeline.png'),dpi=140);plt.close(fig)
 # Source-native diagnostics: geometry versus online value and projected target uncertainty.
 v=case['version'];row=json.load(open(r/summaries[v]['cases'][caseid]['arms']['native']['file']));a=np.load(r/summaries[v]['cases'][caseid]['arms']['native']['arrays']);path=a['path_xy'];records=row['records'];times=np.array([x['absolute_step'] for x in records]);gd=np.array([D[cid(p),gi] for p in path[:-1]]);projected=[x for x in records if x['projected_targets_xy'] is not None];pt=np.array([x['absolute_step'] for x in projected]);near=np.array([x['projected_targets_xy'][-1] for x in projected]);spread=np.array([np.quantile(np.linalg.norm(np.array(x['projection_top8_xy'][-1])-near[k],axis=-1),.9) for k,x in enumerate(projected)]);prgd=np.array([D[cid(p),gi] for p in near]);actualgrid=gd[(pt-case['t']).astype(int)]
 native_metrics=dict(value_vs_negative_graph_distance_spearman=float(spearmanr(a['values'],-gd).statistic),projected_near_goal_distance_median=float(np.median(prgd)),projected_near_top8_xy_spread_median=float(np.median(spread)),projected_near_top8_xy_spread_p90=float(np.quantile(spread,.9)),projected_near_progress_fraction=float(np.mean(prgd<actualgrid)),projected_near_regression_fraction=float(np.mean(prgd>actualgrid)))
 height=a['observations'][:,2];upcos=1-2*(a['observations'][:,4]**2+a['observations'][:,5]**2);upright=(height>=.4)&(upcos>=.5);native_metrics.update(upright_count=int(upright.sum()),total_steps=len(upright),upright_value_vs_negative_graph_distance_spearman=float(spearmanr(a['values'][upright],-gd[upright]).statistic),height_min=float(height.min()),height_median=float(np.median(height)),body_up_cosine_min=float(upcos.min()),body_up_cosine_median=float(np.median(upcos)))
 report['case_details'][caseid]['source_native_diagnostics']=native_metrics
 fig,axes=plt.subplots(4,1,figsize=(13,11),sharex=True,constrained_layout=True)
 axes[0].plot(times,gd,label='agent graph distance',color='#2563eb');axes[0].plot(pt,prgd,'.-',label='projected nearest target graph distance',color='#d97706',alpha=.8);axes[0].set(ylabel='cells to goal');axes[0].legend()
 axes[1].plot(times,a['values'],color='#7c3aed');axes[1].set(ylabel='V(current state, goal)')
 axes[2].plot(pt,spread,color='#b45309');axes[2].set(ylabel='top-8 XY spread (world units)',xlabel='absolute environment step')
 axes[3].plot(times,height,label='torso height',color='#059669');axes[3].plot(times,upcos,label='body up cosine',color='#475569',alpha=.7);axes[3].axhline(.4,c='#059669',ls=':',lw=1);axes[3].axhline(.5,c='#475569',ls=':',lw=1);axes[3].set(ylabel='posture diagnostics',xlabel='absolute environment step');axes[3].legend(ncol=2,fontsize=8)
 for ax in axes:ax.grid(alpha=.25)
 fig.suptitle(caseid+' source-native trace | projection sampled every5 steps; graph distance is geometry only',fontsize=12);fig.savefig(r/(caseid+'_native_detail.png'),dpi=140);plt.close(fig)
 for v in report['versions']:
  for arm in ['known_old','known_new']:
   row=json.load(open(r/summaries[v]['cases'][caseid]['arms'][arm]['file']));target=next(x for x in summaries[v]['cases'][caseid]['local_targets'] if x['name']==arm[6:]);s=row['summary'];support=float(np.linalg.norm(np.array(target['target_xy'])-centers[tuple(target['cell'])]));report['local_target_results'].append(dict(case=caseid,version=v,arm=arm,target=target,training_support_center_distance=support,**s))
(r/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
# Compact table; no binary success claim from cell arrival.
rows=''.join(f'<tr><td>{x["case"]}</td><td>{x["version"]}</td><td>{x["arm"]}</td><td>{x["net_progress_cells"]}</td><td>{x["end_distance_cells"]}</td><td>{x["max_regression_cells"]}</td><td>{x["branch_exit_changes"]}</td><td>{x["minimum_goal_xy_distance"]:.2f}</td></tr>' for x in report['comparisons'])
body=''.join(f'<h2>{cid_}</h2><p>出口几何：{json.dumps(report["case_details"][cid_]["exit_geometry"],ensure_ascii=False)}</p><img src="{cid_}_map.png"><img src="{cid_}_timeline.png"><img src="{cid_}_native_detail.png">' for cid_ in report['case_details'])
html='''<!doctype html><meta charset="utf-8"><title>Junction branch diagnostics</title><style>body{font:16px system-ui;max-width:1450px;margin:30px auto;padding:20px;color:#17202a}img{width:100%}table{border-collapse:collapse;font-size:13px}td,th{border:1px solid #ccc;padding:6px}p,li{line-height:1.6}code{font-size:13px}</style><h1>岔路口完整状态分支诊断</h1><p>冻结 1M checkpoint；H4/L2/M3，β=3；v0/v1/v2 × 两个 task5 起点。原生复现与完整 MuJoCo 恢复后350步 XY 误差均为0。主对照30条350步；另有12条最多100步的局部已知目标探针。无训练更新。</p><p><strong>折返性质不同：</strong>v0 原出口较绕，返回后转向出口(4,5)是朝较短路径的修正；v2 原出口通向goal，返回后转向出口(5,9)却进入必须再回来的死胡同。不能把所有改换路线统一视为错误。</p><p>全688状态小库仅为先导；下面使用完整7692训练状态库。投影刷新本身会改变控制，保持时间的效果应与 projected_refresh 比较。</p>'''+body+'<h2>完整数值</h2><table><tr><th>起点</th><th>模型</th><th>干预</th><th>净进展格</th><th>剩余格</th><th>最大回退格</th><th>出口改变</th><th>最小goal XY距离</th></tr>'+rows+'</table><h2>适用范围与限制</h2><ul>'+''.join('<li>'+x+'</li>' for x in report['limitations'])+'</ul><p><a href="summary.json">结构化结果</a> · <a href="run_branch.py">执行代码</a></p>'
(r/'report.html').write_text(html)
prov=dict(checkpoint_updates=False,training_code_changes=False,source_scope='frozen sources imported from campaign source_dir',input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [atlas/'candidate_bank.npz',atlas/'maze.json']},output_summaries_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*summary.json')},scripts_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*.py')},full_bank=7692,source_cases=[c for c in report['case_details']],native_replay_passed=True)
(r/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
print(json.dumps({'cases':report['case_details'],'local_reach':{v:sum(x['local_reached'] for x in report['local_target_results'] if x['version']==v) for v in report['versions']}},indent=2))
# Local target probes: identical physical fork state and final-goal token.
fig,axes=plt.subplots(2,3,figsize=(14,9),constrained_layout=True)
for ci,(caseid,cr) in enumerate(summaries['v0']['cases'].items()):
 case=cr['source_case'];goal=np.load(r/(caseid+'.npz'))['goal'][:2]
 for vi,v in enumerate(report['versions']):
  ax=axes[ci,vi];base(ax,case,goal)
  for arm,col in [('known_old','#2563eb'),('known_new','#d97706')]:
   x=next(x for x in report['local_target_results'] if x['case']==caseid and x['version']==v and x['arm']==arm);a=np.load(r/summaries[v]['cases'][caseid]['arms'][arm]['arrays']);path=a['path_xy'];target=x['target']['target_xy'];ax.plot(path[:,0],path[:,1],c=col,label=f'{arm}: {"reached" if x["local_reached"] else "missed"}');ax.scatter(*target,c=col,marker='o',s=70,facecolors='none');ax.scatter(*path[0],c='black',s=25);ax.scatter(*path[-1],c=col,marker='X',s=25)
  ax.set_title(v+' | '+caseid,fontsize=10);ax.legend(fontsize=8,loc='lower right')
fig.suptitle('Known exit target probes | all3 slots clamped to one full training state; final-goal token unchanged\nCircle: local XY target; arrival tolerance0.5, budget100. Different-condition stress test, not an executor oracle upper bound.',fontsize=12);fig.savefig(r/'known_target_probes.png',dpi=140);plt.close(fig)
# Optional function-only counterfactual values requested to separate dynamic pose from XY ordering.
slices={}
for v in ['v0','v2']:
 p=r/(v+'_value_slices.json')
 if p.exists():slices.update(json.load(open(p)))
if len(slices)==2:
 report['counterfactual_value_slices']=slices
 fig,axes=plt.subplots(2,1,figsize=(13,8),constrained_layout=True)
 for ax,(caseid,checks) in zip(axes,slices.items()):
  z=np.load(r/(caseid+'_value_slices.npz'));case=report['case_details'][caseid]['source'];time=case['t']+np.arange(len(z['actual']))
  for name,col in [('actual','#7c3aed'),('fixed_fork_pose','#059669'),('fixed_goal_pose','#d97706')]:ax.plot(time,z[name],label=f'{name}, rho={checks[name]["spearman_negative_graph_distance"]:.3f}',c=col)
  ax.set(title=caseid+' | exact saved final-goal observation',xlabel='absolute step',ylabel='V');ax.legend(fontsize=9);ax.grid(alpha=.2)
 fig.suptitle('Counterfactual V slices | XY follows the saved path; non-XY state held constant\nFunction queries only: hybrid states need not be dynamically realizable.',fontsize=12);fig.savefig(r/'value_coordinate_slices.png',dpi=140);plt.close(fig)
(r/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
html=(r/'report.html').read_text().replace('<h2>完整数值</h2>','<h2>局部目标执行探针</h2><img src="known_target_probes.png">'+('<h2>固定姿态的 V 坐标切片</h2><img src="value_coordinate_slices.png">' if slices else '')+'<h2>完整数值</h2>');(r/'report.html').write_text(html)
prov['output_summaries_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*summary.json')};prov['scripts_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*.py')};(r/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
