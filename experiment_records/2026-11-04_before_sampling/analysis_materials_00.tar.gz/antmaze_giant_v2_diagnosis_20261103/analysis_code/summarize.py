import csv, hashlib, html, json, math, shutil
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v2_diagnosis_20261103')
prior=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v0_final_analysis_20261030')
old_fd=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v1_attribution_20261031/v0_checkpoint_probes.json')
scores=json.loads((root/'scores.json').read_text())
probes={'v0':json.loads(old_fd.read_text()),**{v:json.loads((root/f'{v}_checkpoint_probes.json').read_text()) for v in ('v1','v2')}}
local={'v0':json.loads((prior/'local_rollout_probes.json').read_text()),**{v:json.loads((root/f'{v}_local_rollouts.json').read_text()) for v in ('v1','v2')}}
short={v:json.loads((root/f'{v}_local_goal_isolation.json').read_text()) for v in scores}
grad={v:json.loads((root/f'{v}_gradient_probes/mechanism_probes.json').read_text()) for v in ('v1','v2')}
assert all(x['complete'] for x in [*local.values(),*short.values(),*grad.values()])
manifest={v:json.loads((root/v/'snapshot/campaign.json').read_text()) for v in scores}
assert all(manifest[v]['study']['protocol']==manifest['v0']['study']['protocol'] for v in scores)
assert all(manifest[v]['study']['metric']==manifest['v0']['study']['metric'] for v in scores)
assert all(manifest[v]['datasets']==manifest['v0']['datasets'] for v in scores)
query=np.load(prior/'checkpoint_probes_extended.queries.npz')
for v in ('v1','v2'):
 q=np.load(root/f'{v}_checkpoint_probes.queries.npz');assert all(np.array_equal(query[k],q[k]) for k in query.files)
for v in scores:
 assert local[v]['indices']==local['v0']['indices']==short[v]['indices']

summary={'computed_at':datetime.now(timezone.utc).isoformat(),'samples':2048,'metric_steps':[800000,900000,1000000],
 'local_diagnostic_starts':32,'local_budget':100,'local_tolerance':0.5,'comparison_integrity':{'same_data_hashes':True,'same_training_eval_protocol':True,'same_offline_queries':True,'same_local_start_states':True},'runs':{}}
for version in scores:
 summary['runs'][version]={}
 for m,score in scores[version].items():
  name=score['method'];p=probes[version]['runs'][name]
  for step,record in p.items():assert record['checkpoint_sha256']==score['checkpoints'][step]['sha256']
  means=lambda fn:float(np.mean([fn(row) for row in p.values()]))
  result={'method':name,'success_mean':score['main_success'],'success_final':score['final_success'],
   'target_rank':means(lambda r:r['waypoints'][-1]['target_effective_rank']),
   'prediction_rank':means(lambda r:r['waypoints'][-1]['predicted_effective_rank']),
   'near_latent_mse':means(lambda r:r['waypoints'][-1]['mse']),
   'near_weighted_latent_mse':means(lambda r:r['waypoints'][-1]['weighted_mse']),
   'geometric_sign_agreement':means(lambda r:r['waypoints'][-1]['geometric_sign_agreement']),
   'near_command_response_rms':math.sqrt(means(lambda r:r['actions']['near_unit_direction_action_fd_mse'])),
   'far_command_response_rms':math.sqrt(means(lambda r:r['actions']['far_unit_direction_action_fd_mse'])),
   'prediction_teacher_action_mse':means(lambda r:r['actions']['predicted_teacher_action_distance']),
   'predicted_action_data_mse':means(lambda r:r['actions']['predicted_data_mse']),
   'teacher_action_data_mse':means(lambda r:r['actions']['teacher_data_mse']),
   'local':local[version]['runs'][name]['summary'], 'local_final_goal':short[version]['runs'][name]['summary']}
  if version in grad:
   g=grad[version]['runs'][name]
   result['gradient_mean_l2']={obj:{group:float(np.mean([row['l2_norm_by_group'][obj][group] for row in g['gradients']])) for group in ('goal_rep','planner','executor','feature_embed')} for obj in ('value','high','low')}
   result['gradient_mean_cosine']={key:None if g['gradients'][0]['cosine'][key] is None else float(np.mean([row['cosine'][key] for row in g['gradients']])) for key in g['gradients'][0]['cosine']}
   if version=='v2':
    assert result['gradient_mean_l2']['low']['planner']==0
    assert all(result['gradient_mean_l2'][obj]['goal_rep']>0 for obj in ('value','high','low'))
  summary['runs'][version][m]=result
(root/'diagnosis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':160})
colors={'v0':'#3069a8','v1':'#e59528','v2':'#c74455'}
labels={'v0':'v0: data commands, joint encoder','v1':'v1: predicted, value-only encoder','v2':'v2: predicted + detach, joint encoder'}
fig,axes=plt.subplots(1,2,figsize=(12,4.3),sharey=True)
for ax,m in zip(axes,('1','3')):
 for v in scores:
  rows=scores[v][m]['evals'];ax.plot([int(r['step'])/1000 for r in rows],[100*float(r['evaluation/overall_success']) for r in rows],marker='o',markersize=4,color=colors[v],label=labels[v])
 ax.axvspan(800,1000,color='#ddd',alpha=.3);ax.set(title='H2/L1/M1' if m=='1' else 'H4/L2/M3',xlabel='Training updates (thousands)',ylim=(0,80));ax.grid(alpha=.15)
axes[0].set_ylabel('Official success (%)');axes[1].legend(fontsize=8,loc='upper left')
fig.suptitle('Same beta = 3, seed 0, dataset and evaluation protocol');fig.tight_layout();fig.savefig(root/'success_curves.png');plt.close(fig)
fig,axes=plt.subplots(1,3,figsize=(13,4))
metrics=[('target_rank','Near-command target effective rank',1),('near_command_response_rms','Action response to command correction',1),('geometric_sign_agreement','Value / geometric progress agreement (%)',100)]
x=np.arange(2)
for ax,(key,title,scale) in zip(axes,metrics):
 for i,v in enumerate(scores):ax.bar(x+(i-1)*.25,[summary['runs'][v][m][key]*scale for m in ('1','3')],width=.23,color=colors[v],label=v)
 ax.set_xticks(x,['M1','M3']);ax.set_title(title,fontsize=10);ax.grid(axis='y',alpha=.15)
fig.legend(['v0','v1','v2'],loc='lower center',ncol=3,frameon=False);axes[2].set_ylim(0,100)
fig.suptitle('2048 identical offline queries; mean across 800k / 900k / 1M checkpoints');fig.tight_layout(rect=(0,.07,1,1));fig.savefig(root/'mechanism_comparison.png');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12,4.4),sharey=True)
conditions=[('local','predicted'),('local','teacher'),('local_final_goal','predicted'),('local_final_goal','teacher')]
for ax,m in zip(axes,('1','3')):
 for i,v in enumerate(scores):
  vals=[summary['runs'][v][m][section][mode]['success_count'] for section,mode in conditions]
  bars=ax.bar(np.arange(4)+(i-1)*.25,vals,width=.23,color=colors[v],label=v)
  ax.bar_label(bars,fontsize=9,padding=2)
 ax.set_xticks(np.arange(4),['Goal +200\nPredicted command','Goal +200\nData command','Goal +50\nPredicted command','Goal +50\nData command'],fontsize=9)
 ax.set_title('M'+m);ax.set_ylim(0,36);ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('Reached same nearest waypoint / 32');axes[1].legend()
fig.suptitle('Paired local probes at 1M; 100-step budget, radius 0.5; not official task scores')
fig.tight_layout();fig.savefig(root/'local_control.png');plt.close(fig)

def table(head,rows):
 return '<table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>'
def metric(v,m,k):return summary['runs'][v][str(m)][k]
score_table=table(['版本','训练 command','encoder','low→planner','M1 主指标','M3 主指标'],[
 ['v0','数据','联合更新','无预测 command 路径',f"{100*metric('v0',1,'success_mean'):.2f}%",f"{100*metric('v0',3,'success_mean'):.2f}%"],
 ['v1','预测均值','仅 value','保留',f"{100*metric('v1',1,'success_mean'):.2f}%",f"{100*metric('v1',3,'success_mean'):.2f}%"],
 ['v2','预测均值','联合更新','停止',f"{100*metric('v2',1,'success_mean'):.2f}%",f"{100*metric('v2',3,'success_mean'):.2f}%"]])
diag_table=table(['配置','近端 target rank','近端 command 响应 RMS','几何进展符号一致','数据动作 MSE（预测 command）'],[[v+' M'+m,f"{metric(v,m,'target_rank'):.2f}",f"{metric(v,m,'near_command_response_rms'):.5f}",f"{100*metric(v,m,'geometric_sign_agreement'):.2f}%",f"{metric(v,m,'predicted_action_data_mse'):.5f}"] for v in scores for m in ('1','3')])
grad_table=table(['配置','value→encoder','high→encoder','low→encoder','high→planner','low→planner'],[[v+' M'+m,*[f"{summary['runs'][v][m]['gradient_mean_l2'][o][g]:.3f}" for o,g in [('value','goal_rep'),('high','goal_rep'),('low','goal_rep'),('high','planner'),('low','planner')]]] for v in ('v1','v2') for m in ('1','3')])
local_table=table(['配置','原生预测 command','数据 command','只换近端','只换远端','近端作为最终 goal：原生','近端作为最终 goal：数据'],[[v+' M'+m,*[f"{summary['runs'][v][m]['local'][mode]['success_count']}/32" if mode in summary['runs'][v][m]['local'] else '—' for mode in ('predicted','teacher','corrected_near','corrected_far')],*[f"{summary['runs'][v][m]['local_final_goal'][mode]['success_count']}/32" for mode in ('predicted','teacher')]] for v in scores for m in ('1','3')])
text=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>CoGHP v2 下降原因诊断 · 2026-11-03</title><style>body{{font:16px/1.75 system-ui,sans-serif;max-width:1150px;margin:40px auto;padding:0 24px;color:#203044}}h1,h2{{line-height:1.35}}h2{{margin-top:34px}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:9px;border-bottom:1px solid #dae1e9;text-align:left}}th{{background:#eff3f8}}img{{max-width:100%}}.note{{background:#f3f6f9;border-left:4px solid #3069a8;padding:12px 18px}}code,pre{{background:#f3f6f9;padding:3px 6px}}pre{{overflow:auto;padding:16px}}a{{color:#235d96}}</style>
<h1>CoGHP v2：rank 恢复后，为什么导航仍然失败？</h1>
<p>已完成的两组 v2 均正常退出。使用相同数据哈希、seed0、训练预算、50 步子目标间隔、β=3、评估协议，比较最后 80/90/100 万步。新增探针在 CPU 上读取冻结 checkpoint，不更新模型、不改训练代码。</p>
<p class="note"><strong>核心结论：</strong>目标 encoder 的有效 rank 已恢复；失败不能继续简单归于 rank 不足。最直接的异常是 planner command 对 executor 的控制作用变弱、局部目标执行可靠性下降。当前最强机制假设是预测 command 与离线动作/局部 advantage 的监督语义不匹配，以及切断 low→planner 后失去共同适应。v1→v2 同时改变 encoder 梯度和 command 梯度，尚不能唯一分配两者的因果贡献。</p>
{score_table}<img src="success_curves.png">
<h2>1. 实现、配置和数值检查</h2><p>六个对照运行均完成 100 万步，10 次正式评估。200 条训练/验证日志各项数值有限；数据、采样、β、评估温度与预算相同。v2 与对应 v1 β3 的配置差异仅为 actor_goal_rep_grad、executor_command_stop_grad、协议名称。冻结源码与 checkpoint SHA256 被校验，历史结果未覆盖。</p>
<p>在实际 1M checkpoint 上分别对 high/low/value 的标量 loss 求导：v2 low→planner 专有参数梯度严格为零；三个 loss 对 goal_rep 都非零。共享 observation feature 仍接收 low loss，这符合本轮设计。下表为同一 256 样本拆成四批后的梯度 L2 范数均值，不是训练全过程。</p>{grad_table}
<h2>2. rank 的确恢复，但不能替代控制质量</h2>{diag_table}<img src="mechanism_comparison.png">
<p>有效 rank 使用同一 2048 个近端目标编码的中心化协方差谱熵计算。M1 的 v2 rank 接近 v0；M3 的 v2 更高，却没有带来更高成功率。因此，rank 可作为表示诊断，但不是充分的优化目标。</p>
<p>command 响应采用真实前向中心有限差分（ε=0.02），沿预测 command 到数据 command 的单位纠正方向测量动作 RMS；避免 stop_gradient 使自动微分敏感性人为归零。M3 从 v1 到 v2 的响应下降约 {100*(1-metric('v2',3,'near_command_response_rms')/metric('v1',3,'near_command_response_rms')):.1f}%。不同模型坐标和纠正方向不同，单凭这一个量不能断言哪个响应大小最优；结合局部 rollout 才有解释力。</p>
<p>Value 对数据片段几何进展的符号一致率没有明显下降。这只说明采样数据上的这个粗代理指标未退化，不能证明 value 对离线分布之外的状态、长程规划或动力学可行性准确。不同 encoder 的 latent MSE 也不能直接当作相同物理目标误差比较。</p>
<h2>3. 局部控制干预</h2><p>所有模型从完全相同的 32 个验证数据完整仿真状态出发，最多执行 100 步，以是否进入真实 50 步 waypoint 的 0.5 XY 半径为诊断成功。原条件最终 goal 是真实 t+200 状态；数据 command 是 t+150/t+100/t+50 完整状态编码，随当前状态重新编码。</p>{local_table}<img src="local_control.png">
<p>v2 M3 把近端预测换成数据目标，达到目标次数由 11 增到 22；全部使用数据 command 是 17。它支持近端接口值得优先检查，也说明混合 chain 之间存在交互，不能把“全部数据 command”称为性能上界。对 v1/v2 而言数据 command 不是其主要训练输入，替换存在分布变化。</p>
<p>另一个诊断将最终 goal 本身改成同一个 t+50 近端目标，并按数据采样逻辑将所有 waypoint slot 裁到该目标。M3 的 v2 原生/数据 command 只有 17/18 次，v0 为 28/29 次；因此问题也不全是官方长程任务太难。这个诊断同时改变目标跨度和 chain，不能解释成仅修改一个 token 的因果实验。所有数字是 32 个配对诊断起点，不是独立训练 seeds。</p>
<h2>4. 目前最有解释力的训练机制</h2>
<p>用 y 表示数据中真实的近端 waypoint，z_data=φ(s,y)。v0 的 low loss 让来自同一片段的 action a 与 z_data 配对，并用针对 y 的 advantage 加权。</p>
<pre>v0: -E_D[ w_L(s,s';y) · log π_L(a | s,g, z_data) ]
v2: -E_D[ w_L(s,s';y) · log π_L(a | s,g, stopgrad(P(s,g))) ]
w_L(s,s';y) = min(exp(3 · [V(s',y)-V(s,y)]), 100)</pre>
<p>v2 更换了动作条件，却仍使用原数据动作和针对数据 waypoint 的权重。输入与推理一致，不代表这个 action 就对应模型新给出的 command。切断梯度能防止 executor 修改 planner，但不会自动恢复 command、动作与权重之间的对应关系。完整 M3 中 y 对应最近端，command 条件实际包含完整 chain。</p>
<p>此外，预测均值 P(s,g) 是 executor 已有 observation/goal 特征的确定性函数。它可能是有用的计算表示，但不再像数据 future command 一样提供该实际片段的未来走向。训练目标允许 executor 主要依赖直接 observation/goal 路径；弱 command 响应与此一致，但不能单凭这些探针证明模型完全忽略了 command。</p>
<p>v0 的 low loss 还直接塑造 φ(s,y) 的局部控制语义。v2 的 low→预测 command 已截断，目标 encoder 的 low 梯度主要来自直接最终 goal。即便 rank 恢复，恢复的也不等于原来的局部控制表示路径。</p>
<h2>5. 对上一轮假设的修正与最小后续对照</h2>
<p>此前把 low→planner 梯度主要视为干扰是不充分的。v1 M3 在相同 β 下明显好于 v2，提示这条路径在当前预测 command 训练方式下可能承担了 planner/executor 共同适应。梯度与 high loss 近乎正交不代表有害；单 checkpoint 的梯度范数也不能证明切断必然有益。</p>
<p>最有区分力的下一组是 <strong>M3、β3、预测均值 command、encoder 联合更新、保留 low→planner</strong>。它与 v2 只差 detach 开关，与 v1 只差 encoder 梯度开关，能补上当前缺失的关键条件。可先按相同评估协议检查 30 万步的分离趋势，再决定是否完成 100 万步；30 万步不能与既有末段主指标混比。这是诊断对照，不要求最终方案必须保留反传。</p>
<p>若仍坚持最终 executor 接口 detach，应优先设计与预测 command 相匹配的动作监督/局部控制约束，而不是期待 rank、β schedule 或更深 HRM 自动解决接口问题。本次没有启动上述训练。</p>
<h2>文件与复现范围</h2><p>结构化结果：<a href="diagnosis_summary.json">diagnosis_summary.json</a>；完整成功率：<a href="scores.json">scores.json</a>。v0/v1/v2 日志快照在对应 snapshot 目录；探针 JSON、query 索引、分析源码及 provenance 保存在本目录。新探针覆盖 12 个 v1/v2 checkpoint、768 个局部诊断回合，复用经过哈希核对的 v0 配对探针。所有模型只有 seed0，不报告算法总体显著性。</p></html>'''
(root/'report.html').write_text(text)
# Keep the actual diagnostic programs and logs next to the result; frozen training sources remain untouched.
repo=Path('/home/eai/Research/CoGHP')
for file in ['probe_joint_planner_attribution.py','probe_joint_planner_rollouts.py','audit_joint_planner_attribution_gradients.py']:
 shutil.copy2(repo/'scripts'/file,root/'analysis_code'/file)
for log in Path('/tmp').glob('coghp-*-20261103.log'):
 if any(token in log.name for token in ['paired-probes','local-rollouts','gradient-probes','local-goal-isolation']):shutil.copy2(log,root/log.name)
provenance={'created_at':summary['computed_at'],'model_parameters_updated':False,'training_code_modified':False,'new_training_started':False,'backend':'cpu','new_offline_checkpoints':12,'new_local_diagnostic_episodes':768,'reused_v0_probes':[str(old_fd),str(prior/'local_rollout_probes.json')], 'source_signatures':{v:m['source']['code_signature'] for v,m in manifest.items()},'analysis_source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'analysis_code').glob('*.py')}}
(root/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print('REPORT',root/'report.html')
print(json.dumps({v:{m:{k:r[k] for k in ['success_mean','target_rank','near_command_response_rms','geometric_sign_agreement']} for m,r in x.items()} for v,x in summary['runs'].items()},indent=2))
