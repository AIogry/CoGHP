import csv,hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v2_diagnosis_20261103')
base=Path('/data/qijunrong/06-RL/offline-rl/exp')
names={'v0':'joint_planner_v0_antmaze_giant_width32_seed0_20261029','v1':'joint_planner_v1_antmaze_giant_predmean_valueonly_beta25_30_35_seed0_20261031','v2':'joint_planner_v2_antmaze_giant_predmean_detached_jointencoder_beta3_seed0_20261103'}
summary={}
for version,name in names.items():
 campaign=base/name;snapshot=root/version/'snapshot';snapshot.mkdir(parents=True,exist_ok=False)
 shutil.copy2(campaign/'campaign.json',snapshot/'campaign.json')
 (snapshot/'captured_at.json').write_text(json.dumps({'campaign':str(campaign),'time':datetime.now(timezone.utc).isoformat()},indent=2))
 summary[version]={}
 for m,method in [(1,'hrm_h2l1_m1' if version=='v0' else 'hrm_beta30_h2l1_m1'),(3,'hrm_h4l2_m3' if version=='v0' else 'hrm_beta30_h4l2_m3')]:
  run=campaign/'runs'/method/'antmaze-giant-navigate-v0/seed_000/attempt_000';target=snapshot/'runs'/method;target.mkdir(parents=True)
  shutil.copy2(run/'run.json',target/'run.json')
  state=json.loads((run/'run.json').read_text());assert state['status']=='completed' and state['returncode']==0
  for f in ['flags.json','checkpoint_metadata.json','reproducibility.json','train.csv','eval.csv']:
   if (run/'artifacts'/f).exists():shutil.copy2(run/'artifacts'/f,target/f)
  evals=list(csv.DictReader((target/'eval.csv').open()));train=list(csv.DictReader((target/'train.csv').open()))
  last=[r for r in evals if int(r['step']) in (800000,900000,1000000)];assert len(last)==3 and len(evals)==10
  summary[version][str(m)]={'method':method,'main_success':sum(float(r['evaluation/overall_success']) for r in last)/3,'final_success':float(evals[-1]['evaluation/overall_success']), 'evals':evals,'checkpoints':{}}
  for step in [800000,900000,1000000]:
   p=run/'artifacts'/f'params_{step}.pkl'
   with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   summary[version][str(m)]['checkpoints'][str(step)]={'path':str(p),'sha256':h}
  for row in train:
   for k,v in row.items():
    if v:
     import math
     assert math.isfinite(float(v)),(version,method,row['step'],k,v)
(root/'scores.json').write_text(json.dumps(summary,indent=2)+'\n')
print({v:{m:round(d['main_success']*100,2) for m,d in x.items()} for v,x in summary.items()})
