import os,sys,json
from pathlib import Path
from collections import deque
import numpy as np
os.environ['JAX_PLATFORMS']='cpu'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v1_review_20261102')
campaign=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v1_antmaze_giant_predmean_valueonly_beta25_30_35_seed0_20261031')
manifest=json.loads((campaign/'campaign.json').read_text());source=Path(manifest['source_dir'])
sys.path[:0]=[str(source/'impls'),str(source)]
import jax
import jax.numpy as jnp
from agents.navigation import NavigationAgent
from utils.flax_utils import restore_agent
from utils.datasets import Dataset,MultiHGCDataset
from ogbench.utils import load_dataset
folder=campaign/'runs/hrm_beta30_h4l2_m3/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts'
flags=json.loads((folder/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
data=Dataset.create(**load_dataset(manifest['datasets'][flags['env_name']+'-val.npz']['path'],compact_dataset=True))
batch=MultiHGCDataset(data,cfg,rng=np.random.default_rng(20261030)).sample(2048,evaluation=True)
saved=np.load('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v0_final_analysis_20261030/checkpoint_probes_extended.queries.npz')
assert np.array_equal(saved['target_indices'],batch['high_actor_target_idxs'])
agent=NavigationAgent.create(0,batch['observations'][:1],batch['actions'][:1],cfg)
agent=restore_agent(agent,str(folder),1000000,json.loads((folder/'checkpoint_metadata.json').read_text()),True)

@jax.jit
def values(agent,b):
 v=agent.network.select('value')
 return jnp.mean(v(b['observations'],b['high_actor_goals']),0),jnp.stack([jnp.mean(v(b['high_actor_targets'][:,j],b['high_actor_goals']),0) for j in range(3)],1)
v0,vfar=[np.asarray(x) for x in values(agent,batch)];v=vfar[:,::-1]
cum=v-v0[:,None];seg=v-np.concatenate([v0[:,None],v[:,:-1]],1)
assert np.allclose(seg.cumsum(1),cum,atol=1e-5)
maze=json.loads(Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_v0_final_analysis_20261030/official_task_paths.json').read_text())['maze']
grid=np.asarray(maze['grid']);xy=np.asarray(maze['cell_xy']);unit=xy[0,1,0]-xy[0,0,0]
def ij(p):return int((p[1]-xy[0,0,1]+unit*.5)/unit),int((p[0]-xy[0,0,0]+unit*.5)/unit)
def bfs(goal):
 d=np.full(grid.shape,-1);d[goal]=0;q=deque([goal])
 while q:
  i,j=q.popleft()
  for a,b in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
   if 0<=a<grid.shape[0] and 0<=b<grid.shape[1] and grid[a,b]==0 and d[a,b]<0:d[a,b]=d[i,j]+1;q.append((a,b))
 return d
cache={};distances=[]
for obs,targets,goal in zip(batch['observations'],batch['high_actor_targets'],batch['high_actor_goals']):
 key=ij(goal)
 if key not in cache:cache[key]=bfs(key)
 d=cache[key];distances.append([d[ij(obs)],*[d[ij(s)] for s in targets[::-1]]])
d=np.asarray(distances);geom={'cumulative':d[:,:1]-d[:,1:],'adjacent':d[:,:-1]-d[:,1:]}
weight_summary={}
for name,a in [('cumulative',cum),('adjacent',seg)]:
 w=np.exp(np.minimum(3*a,np.log(100)))
 gs=geom[name];valid=(gs!=0)&(d[:,1:]>=0)&((d[:,:1] if name=='cumulative' else d[:,:-1])>=0)
 weight_summary[name]=dict(cap_fraction=(w>=100*(1-1e-5)).mean(0).tolist(),mean_weight=w.mean(0).tolist(),
  ess_fraction=(w.sum(0)**2/(len(w)*(w*w).sum(0))).tolist(),
  geometric_sign_agreement=[float(np.mean(np.sign(a[valid[:,i],i])==np.sign(gs[valid[:,i],i]))) for i in range(3)],
  non_tie_counts=valid.sum(0).tolist())
weight_summary['cumulative_positive_segment_negative_fraction']=((cum>0)&(seg<0)).mean(0).tolist()
weight_summary['cumulative_negative_segment_positive_fraction']=((cum<0)&(seg>0)).mean(0).tolist()
idx=batch['high_actor_target_idxs'][:,::-1];prev=np.concatenate([batch['indices'][:,None],idx[:,:-1]],1)
weight_summary['duplicate_segment_fraction']=(idx==prev).mean(0).tolist()
(root/'adjacent_weight_probe.json').write_text(json.dumps(weight_summary,indent=2)+'\n')
print('WEIGHTS',json.dumps(weight_summary),flush=True)

# Rewire only the diagnostic computation graph around a frozen checkpoint.
# No optimizer update or training-code edit is performed.
joint_cfg=dict(cfg,actor_goal_rep_grad=True)
template=NavigationAgent.create(0,batch['observations'][:1],batch['actions'][:1],joint_cfg)
assert jax.tree_util.tree_structure(template.network.params)==jax.tree_util.tree_structure(agent.network.params)
joint=template.replace(network=template.network.replace(params=agent.network.params,model_state=agent.network.model_state))
small={k:v[:64] for k,v in batch.items()}
def norm(tree):return float(np.sqrt(sum(np.square(np.asarray(x,dtype=np.float64)).sum() for x in jax.tree_util.tree_leaves(tree))))
out={};reference_outputs=None
for name,current,detach in [('v1_value_only_attached',agent,False),('joint_encoder_attached',joint,False),('joint_encoder_detached_command',joint,True)]:
 def losses(params):
  high,low,_,pred=current.policy(small['observations'],small['high_actor_goals'],jax.random.PRNGKey(19),params=params,temperature=1.,return_latents=True)
  if detach:
   _,low,_=current.policy(small['observations'],small['high_actor_goals'],jax.random.PRNGKey(19),commands=jax.lax.stop_gradient(pred),params=params,temperature=1.,chain_source='teacher')
  return jnp.stack([current.multi_high_actor_loss(small,high,None,params)[0],current.low_actor_loss(small,low)[0]])
 g={}
 for index,key in enumerate(['high','low']):
  part=jax.jit(jax.grad(lambda params:losses(params)[index]))(current.network.params);a=part['modules_actor_mixer']
  g[key]={'goal_rep':norm(part['modules_goal_rep']),'planner_exclusive':norm({k:a[k] for k in ('planner_core','planner_query_tokens','high_actor_head')}),'shared_feature_embed':norm(a['feature_embed'])}
 _,dist,_,pred=current.policy(small['observations'],small['high_actor_goals'],jax.random.PRNGKey(19),temperature=0.,return_latents=True)
 actual=(np.asarray(dist.mode()),np.asarray(pred))
 if reference_outputs is None:reference_outputs=actual
 assert all(np.array_equal(a,b) for a,b in zip(reference_outputs,actual))
 out[name]=g;print('GRADIENTS',name,json.dumps(g),flush=True)
assert out['joint_encoder_detached_command']['low']['planner_exclusive']==0
assert out['joint_encoder_detached_command']['low']['goal_rep']>0
assert out['joint_encoder_detached_command']['high']['goal_rep']>0
(root/'proposed_gradient_probe.json').write_text(json.dumps({'samples':64,'checkpoint':'hrm_beta30_h4l2_m3@1M','agent_parameters_updated':False,'all_forward_outputs_identical':True,'groups':out},indent=2)+'\n')
