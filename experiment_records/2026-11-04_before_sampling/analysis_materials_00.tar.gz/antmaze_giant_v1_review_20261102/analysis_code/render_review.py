from pathlib import Path
from collections import deque
import json,csv,html,os,shutil
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/coghp-analysis-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

repo=Path('/home/eai/Research/CoGHP');root=repo/'impls/exp/antmaze_giant_v1_review_20261102'
archive=repo/'experiment_records/2026-11-02'
scores=json.loads((archive/'scores.json').read_text())
new=[r for r in scores if r['campaign'].startswith('v1')]
weights=json.loads((root/'adjacent_weight_probe.json').read_text())
grad=json.loads((root/'proposed_gradient_probe.json').read_text())
oldpaths=json.loads((repo/'impls/exp/antmaze_giant_v0_final_analysis_20261030/official_task_paths.json').read_text())
newpaths=json.loads((root/'beta3_task_paths.json').read_text());assert newpaths['complete']
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
for ax,m in zip(axes,(1,3)):
 rows=sorted([r for r in new if r['M']==m],key=lambda r:r['high_alpha'])
 x=[r['high_alpha'] for r in rows];y=[100*r['score'] for r in rows];last=[100*r['checkpoint_scores']['1000000'] for r in rows]
 ax.plot(x,y,'o-',color='#235789',label='Primary: mean of last 3 checkpoints');ax.plot(x,last,'s--',color='#c47724',label='1M checkpoint only',alpha=.85)
 for a,b in zip(x,y):ax.annotate(f'{b:.2f}',(a,b),xytext=(0,8),textcoords='offset points',ha='center',fontsize=8)
 ax.set(title='H2/L1/M1' if m==1 else 'H4/L2/M3',xlabel='High AWR beta',ylabel='Success (%)',xticks=x,ylim=(0,15 if m==1 else 42));ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Completed v1 beta sweep | seed 0; correlated checkpoints')
fig.savefig(root/'beta_scores.png',dpi=180);plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
time_stats={}
for r in sorted([r for r in new if r['M']==1],key=lambda r:r['high_alpha']):
 rows=list(csv.DictReader((archive/'campaigns'/r['campaign']/'runs'/r['method']/'train.csv').open()))
 x=[float(row['step'])/1000 for row in rows]
 for ax,key in zip(axes,['cap_fraction','ess_fraction']):ax.plot(x,[float(row[f'validation/high_actor/weight_0/{key}'])*100 for row in rows],label=f"beta={r['high_alpha']:g}",linewidth=1.2)
 if r['high_alpha']==3:
  time_stats={row['step']:{key:float(row[f'validation/high_actor/weight_0/{key}']) for key in ('cap_fraction','ess_fraction','mean')} | {'adv_std':float(row['validation/high_actor/adv_0/std'])} for row in rows if int(row['step']) in (5000,50000,100000,500000,1000000)}
for ax,title in zip(axes,['Nearest target: weight cap fraction','Nearest target: normalized ESS']):
 ax.set(title=title,xlabel='Training updates (thousands)',ylabel='Percent',ylim=(0,70));ax.grid(alpha=.2);ax.legend(ncol=2,fontsize=8)
fig.suptitle('Fixed validation batch | all beta runs share the value-only critic trajectory')
fig.savefig(root/'weight_time_profiles.png',dpi=180);plt.close(fig)

panels=[('v0 H1/L1/M1',oldpaths,'hrm_h1l1_m1'),('v0 H2/L1/M1',oldpaths,'hrm_h2l1_m1'),('v0 H4/L2/M3',oldpaths,'hrm_h4l2_m3'),('v1 beta3 H2/L1/M1',newpaths,'hrm_beta30_h2l1_m1'),('v1 beta3 H4/L2/M3',newpaths,'hrm_beta30_h4l2_m3')]
maze=oldpaths['maze'];grid=np.array(maze['grid']);xy=np.array(maze['cell_xy']);unit=xy[0,1,0]-xy[0,0,0]
extent=(xy[0,0,0]-unit/2,xy[0,-1,0]+unit/2,xy[0,0,1]-unit/2,xy[-1,0,1]+unit/2)
def ij(p):return int((p[1]-xy[0,0,1]+unit*.5)/unit),int((p[0]-xy[0,0,0]+unit*.5)/unit)
def bfs(goal):
 d=np.full(grid.shape,-1);d[goal]=0;q=deque([goal])
 while q:
  i,j=q.popleft()
  for a,b in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)]:
   if 0<=a<grid.shape[0] and 0<=b<grid.shape[1] and grid[a,b]==0 and d[a,b]<0:d[a,b]=d[i,j]+1;q.append((a,b))
 return d
route_summary=[]
fig,axes=plt.subplots(2,5,figsize=(17,7.8),sharex=True,sharey=True,constrained_layout=True)
for row,task in enumerate(('1','5')):
 reference=oldpaths['runs']['hrm_h1l1_m1']['tasks'][task]['episodes']
 for ax,(label,collection,name) in zip(axes[row],panels):
  group=collection['runs'][name]['tasks'][task];episodes=group['episodes'];backtracking=[];sets=[]
  ax.imshow(grid,extent=extent,origin='lower',cmap=ListedColormap(['#f6f7f9','#b7bec8']),vmin=0,vmax=1)
  for expected,e in zip(reference,episodes):
   assert np.allclose(expected['path_xy'][0],e['path_xy'][0]) and np.allclose(expected['goal_xy'],e['goal_xy'])
   p=np.array(e['path_xy']);color='#238569' if e['success'] else '#c74e4a'
   ax.plot(p[:,0],p[:,1],c=color,alpha=.65,lw=.8);ax.scatter(*p[0],c='#235789',s=10,zorder=4);ax.scatter(*p[-1],c=color,s=18,marker='x',zorder=4)
   d=bfs(ij(e['goal_xy']));ds=np.array([d[ij(x)] for x in p]);valid=ds>=0
   ds=ds[valid];backtracking.append(int(np.max(ds-np.minimum.accumulate(ds))))
   sets.append({ij(x) for x in p})
  ax.scatter(*episodes[0]['goal_xy'],marker='*',c='#edbc3b',edgecolors='#775c22',s=60,zorder=5)
  ax.set(title=label+f"\nTask {task}: {group['summary']['success_count']}/8",aspect='equal')
  jaccard=[1-len(a&b)/len(a|b) for i,a in enumerate(sets) for b in sets[i+1:]]
  route_summary.append(dict(model=label,task=int(task),success_count=group['summary']['success_count'],
   mean_final_cell_distance=group['summary']['mean_final_distance_cells'],
   episodes_with_at_least_3_cells_backtracking=sum(x>=3 for x in backtracking),max_backtracking_by_episode=backtracking,
   stationary_failures=sum(not e['success'] and max(e['last_200_steps_span_xy'])<.5 for e in episodes),
   pairwise_occupancy_dissimilarity=float(np.mean(jaccard))))
fig.suptitle('Task paths: same first 8 evaluation starts | green success, red failure\nCPU diagnostic replay at 1M; route spread is not an estimate of exploration ability',fontsize=12)
fig.savefig(root/'route_comparison.png',dpi=180);plt.close(fig)
(root/'route_summary.json').write_text(json.dumps(route_summary,indent=2)+'\n')
(root/'weight_time_summary.json').write_text(json.dumps(time_stats,indent=2)+'\n')
def table(head,rows):
 line=lambda cells:'<tr>'+''.join('<td>'+html.escape(str(c))+'</td>' for c in cells)+'</tr>'
 return '<table><thead>'+line(head)+'</thead><tbody>'+''.join(line(r) for r in rows)+'</tbody></table>'
betas=sorted({r['high_alpha'] for r in new});lookup={(r['M'],r['high_alpha']):r for r in new}
scoretable=table(['β','M1 主分数','M1 最后点','M3 主分数','M3 最后点'],[[b,*[f"{100*(lookup[m,b]['score'] if key=='mean' else lookup[m,b]['checkpoint_scores']['1000000']):.2f}%" for m,key in [(1,'mean'),(1,'last'),(3,'mean'),(3,'last')]]] for b in betas])
gradtable=table(['临时梯度设置','high→φ','low→φ','low→planner 专属','low→共享状态编码器'],[[name,f"{v['high']['goal_rep']:.3f}",f"{v['low']['goal_rep']:.3f}",f"{v['low']['planner_exclusive']:.3f}",f"{v['low']['shared_feature_embed']:.3f}"] for name,v in grad['groups'].items()])
weighttable=table(['定义，β=3','近端 cap','中间 cap','远端 cap','远端 ESS/N'],[[name,*[f'{100*x:.1f}%' for x in weights[name]['cap_fraction']],f"{100*weights[name]['ess_fraction'][-1]:.1f}%"] for name in ['cumulative','adjacent']])
routetable=table(['模型','任务','成功/8','最终格点距离均值','≥3格几何回退/8','停滞失败数'],[[x['model'],x['task'],x['success_count'],f"{x['mean_final_cell_distance']:.2f}",x['episodes_with_at_least_3_cells_backtracking'],x['stationary_failures']] for x in route_summary])
report=f'''<!doctype html><html lang="zh"><meta charset="utf-8"><title>CoGHP 2026-11-02 研究复核</title>
<style>body{{max-width:1200px;margin:36px auto;padding:0 24px;font:16px/1.8 system-ui,sans-serif;color:#243249}}h2{{margin-top:34px}}img{{width:100%}}table{{width:100%;border-collapse:collapse;font-size:14px}}td{{padding:9px;border-bottom:1px solid #dce3eb}}thead{{background:#edf2f7}}.eq,.note{{padding:16px;background:#f1f5f8;border-radius:6px}}.eq{{white-space:pre-wrap;font-family:ui-monospace,monospace}}</style>
<h1>完成备份后的研究复核：梯度隔离、β、片段差分与路线</h1>
<p>2026-11-02。此前代码、24 组完整实验记录、冻结源码和分析快照已提交并推送：<a href="https://github.com/AIogry/CoGHP/commit/41b3d7dc104114652c7f2bb83631c1bc82bb2be9">41b3d7d</a>。72 个 checkpoint 的二进制仍在原 /data 目录，远端保存了索引和 SHA256。本报告在备份完成后生成，只做诊断，不修改训练代码或模型参数。</p>
<h2>1. β=3 是有依据的参考值，但不是两个 M 的统一主指标最优</h2>{scoretable}<img src="beta_scores.png" alt="complete beta sweep">
<p>最后一个 checkpoint 中 β=3 在两种 M 都最高；预定主指标中 M1 最佳是 β=3.5，M3 最佳是 β=3。只有 seed0，三个 checkpoint 相关，不能把它们视作三个独立重复。固定同样 β=3，旧版 M1/M3 为 63.60%/56.67%，新版为 7.73%/26.80%，分别低 55.87/29.87 个百分点。这排除了“跨轮差距全部来自 β 不同”的解释，但没有拆开 command 与 encoder 改动。</p>
<h2>2. 用户提出的梯度分工在数学上可实现</h2>
<div class="eq">Ẑ = plannerθ(eψ(s), φξ(s,g))
a = executorω(eψ(s), φξ(s,g), stop_gradient(Ẑ))
L = L_value + L_high(Ẑ, stop_gradient(Z_data)) + L_low(a,a_data)</div>
<p>只在 executor 的 command 接口处停止梯度，high loss 仍使用未 detach 的预测并保留完整 BPTT。于是 low loss 对 planner 的 H/L、query、high head 梯度为零，而仍可经直接输入的 φ(s,g) 更新目标编码器。共享 observation feature 编码器 eψ 也仍受 low loss 更新。</p>
<p>在 β=3、H4/L2/M3 的已有 1M checkpoint 上，对 64 个固定查询仅改变临时诊断计算图，逐损失求标量梯度；没有优化器更新。所有配置的前向计划和动作均完全一致，梯度如下：</p>{gradtable}
<p><strong>关键限制：</strong>这并不完整恢复 v0 的 encoder 训练路径。v0 的 low loss 经数据 command φ(s,s_i) 学习未来目标中的执行信息；新方案保持预测 command 且 detach 后，这条路径依然不存在，low loss 只能经直接最终 goal 输入 φ(s,g) 更新 φ。三个 loss 参与更新是可验证的梯度约束，恢复原有效秩或性能则是实验假设。也不能把它描述成 low loss 完全不影响 high actor 的所有共享表征。</p>
<h2>3. β schedule 的两个动机需要分开</h2><img src="weight_time_profiles.png" alt="weight cap and ESS time profiles">
<p>固定验证批次中，advantage 标准差由 5k 的 4.916 增至 50k 的 8.615、1M 的 9.567。β=3 的近端 cap 从 22.7% 增至约 49.6%。随着 value 数值范围增长，即使 β 不变，βA 的分布也在改变。</p>
<p>“早期 critic 不可靠，因此先小后大”是置信度课程；“随着 A 的尺度增大而减小 β”是尺度校准。仅有静态 β sweep 和 A 的方差，不能判定哪一种课程更好。截断下，降低 β 还可能解除大量相同的 100 权重，使 ESS 先下降；不能用 cap 单独选 schedule。</p>
<p>而且新梯度方案会令 low→planner 专属梯度归零，β 不再需要通过增强 high loss 去抗衡这条 low loss 路径。恢复 actor 对 encoder 的梯度后，critic/encoder 的演化也会重新与 β 耦合。本轮 β 最优值不能不加检验地迁移到新结构。</p>
<p>可复核的最小起点：新梯度结构先固定 β=3，得到同 β 的结构对照。随后仅比较一个温和候选 β(t)=2+min(t/100000,1) 与固定 3；2→3 与 100k 是待验证的设计，不是从静态曲线证明的最优课程。记录 β、cap、ESS、平均权重和梯度，并保存 schedule 的 update 计数。不要同时改变 Δ、片段权重和监督轮数。</p>
<h2>4. 相邻差分确实分离了局部进展，但没有天然保证更准确</h2>
<div class="eq">按时间由近到远：u₀=s，uᵢ=s(t+iΔ)，vᵢ=V(uᵢ,g)
Aᶜᵘᵐᵢ = vᵢ−v₀
Aˢᵉᵍᵢ = vᵢ−vᵢ₋₁
Σᵢ Aˢᵉᵍᵢ = Aᶜᵘᵐ_M，但逐位置指数加权后的 loss 不等价。</div>
<p>基于新 β=3 模型的 critic，在原有 2048 配对查询上重算：</p>{weighttable}
<p>远端有 8.25% 查询的累计分数为正而最后一段为负，也有 8.20% 累计为负而最后一段为正；中间位置对应 6.49% 与 6.74%。局部差分可识别被先前进展掩盖的退步，也会奖励坏前缀后的恢复。这是评分语义变化，不能只解释成降低权重饱和。</p>
<p>最近目标权重不变，M1 两种方案严格相同。远端相邻目标约 20.2% 因截断而重复，此时 A=0、w=1；不能把 cap 下降都归因于质量区分改善。按各自进展定义，远端累计/相邻分数对几何非平局进展的符号一致率约为 93.4%/89.6%，比较对象和有效样本数不同，不能当成同题准确率差。这仍是 learned-value 代理，未评价 executor 的实际片段可达性。</p>
<p>只改变评分参考状态时，command 编码仍是 φ(s,uᵢ)，不应顺便改成 φ(uᵢ₋₁,uᵢ)。代码中目标按远→近存储，配对时必须使用时间上的前一状态。该方案应在新梯度结构稳定后单独对照。</p>
<h2>5. 路线集中、跨回合分叉和回合内回退是三个不同对象</h2><img src="route_comparison.png" alt="paired route replay">{routetable}
<p>本次补跑 β=3 两种配置在任务 1、5 各前 8 个正式起点，共 32 条 CPU 诊断轨迹；旧图沿用已有相同起点。8 条轨迹仅观察失败形态，不替代每任务 50 次、三个 checkpoint 的正式结果。回退定义为某时刻格点距离超过此前最小距离至少 3 格；停滞为失败轨迹末 200 步 XY 范围小于 0.5。它们都是几何代理。</p>
<p>H1/L1/M1 在旧任务 5 中呈现稳定绕墙路线；新模型中可看到不同的通道选择、回退和超时。路径更分散不能直接解释为更强的搜索能力。当前温度为零，HRM 隐状态每个环境步重置，没有显式跨步试路记录；输入状态/姿态/目标观测的小扰动及闭环执行偏差，都可能引起分叉。</p>
<p>理论上应检查完整闭环的局部放大率：δs(t+1)≈[∂f/∂s+(∂f/∂a)(∂π/∂s)]δs(t)，而非只看 HRM 深度或路线条数。后续诊断应分别统计同一起点微扰下的分支选择与成功率、单回合的持续进展和回退、接近目标后的精确到达。由于 φ(s,u) 依赖当前 s，不能直接把相邻时刻 latent 的 L2 差当作物理目标改变或计划抖动。</p>
<h2>范围与复现</h2><p>本报告的数据文件为 adjacent_weight_probe.json、proposed_gradient_probe.json、weight_time_summary.json、route_summary.json 和 beta3_task_paths.json。分析源码副本在 analysis_code/。当前训练实现与备份提交一致，未启动新训练。模型 checkpoint 与原始数据保持不变。</p>
</html>'''
(root/'report.html').write_text(report)
code=root/'analysis_code';code.mkdir(exist_ok=True)
shutil.copy2('/tmp/coghp_review_mechanisms_20261102.py',code/'review_mechanisms.py')
shutil.copy2('/tmp/render_coghp_review_20261102.py',code/'render_review.py')
print('Saved',root/'report.html')
print(json.dumps(route_summary,indent=2))
