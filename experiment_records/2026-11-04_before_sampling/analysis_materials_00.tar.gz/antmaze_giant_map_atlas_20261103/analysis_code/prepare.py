import os,sys,json
from pathlib import Path
os.environ['JAX_PLATFORMS']='cpu';sys.dont_write_bytecode=True
import numpy as np
root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_map_atlas_20261103')
analysis=root.parent/'antmaze_giant_v2_diagnosis_20261103'
manifest=json.loads((analysis/'v2/snapshot/campaign.json').read_text());source=Path(manifest['source_dir'])
sys.path[:0]=[str(source/'impls'),str(source)]
from ogbench.utils import load_dataset
from utils.datasets import Dataset,MultiHGCDataset
flags=json.loads((analysis/'v2/snapshot/runs/hrm_beta30_h4l2_m3/flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
train_path=Path(manifest['datasets'][flags['env_name']+'.npz']['path']);val_path=Path(manifest['datasets'][flags['env_name']+'-val.npz']['path'])
train=load_dataset(train_path,compact_dataset=True)
valid=np.flatnonzero(train['valids']>0);rng=np.random.default_rng(20261103);rng.shuffle(valid)
# Balance actual training states over XY bins; preserve full robot state.
chosen=[];counts={}
for i in valid:
 xy=tuple(np.floor(train['observations'][i,:2]/.75).astype(int))
 if counts.get(xy,0)<4:
  counts[xy]=counts.get(xy,0)+1;chosen.append(int(i))
 if len(chosen)==8192:break
bank=np.asarray(chosen);np.savez_compressed(root/'candidate_bank.npz',indices=bank,observations=train['observations'][bank])
raw=load_dataset(val_path,compact_dataset=True);data=Dataset.create(**raw)
query=MultiHGCDataset(data,cfg,rng=np.random.default_rng(20261103)).sample(65536,evaluation=True)
maze=json.loads((root.parent/'antmaze_giant_v0_final_analysis_20261030/official_task_paths.json').read_text())['maze']
cases=[];selected=[];stats={}
for task_id,task in enumerate(maze['tasks'],1):
 dg=np.linalg.norm(query['high_actor_goals'][:,:2]-task['goal_xy'],axis=1)
 ds=np.linalg.norm(query['observations'][:,:2]-task['init_xy'],axis=1)
 movement=np.linalg.norm(query['high_actor_targets'][:,-1,:2]-query['observations'][:,:2],axis=1)
 candidates=np.flatnonzero((dg<=2)&(query['high_actor_goal_idxs']-query['indices']>=200)&(movement>1)&(np.linalg.norm(query['high_actor_goals'][:,:2]-query['observations'][:,:2],axis=1)>8))
 assert len(candidates)>=6,(task_id,len(candidates))
 picked=[]
 # Start with the closest available data state to the official start; diversify
 # subsequent positions without consulting any model prediction or error.
 first=int(candidates[np.argmin(ds[candidates])]);picked.append(first)
 for _ in range(5):
  xy=query['observations'][candidates,:2];existing=query['observations'][picked,:2]
  separation=np.linalg.norm(xy[:,None]-existing[None],axis=-1).min(1)
  index_separation=np.abs(query['indices'][candidates,None]-query['indices'][np.array(picked)][None]).min(1)
  separation[index_separation<50]=-1
  nxt=int(candidates[np.argmax(separation)]);assert nxt not in picked;picked.append(nxt)
 for j,k in enumerate(picked):
  start=int(query['indices'][k]);goal=int(query['high_actor_goal_idxs'][k]);targets=query['high_actor_target_idxs'][k]
  pathids=np.unique(np.r_[np.arange(start,goal+1,5),targets,goal])
  cases.append(dict(task=task_id,case=j,index=start,goal_index=goal,target_indices=targets.tolist(),observation_xy=query['observations'][k,:2].tolist(),goal_xy=query['high_actor_goals'][k,:2].tolist(),data_target_xy=query['high_actor_targets'][k,:,:2].tolist(),data_path_xy=raw['observations'][pathids,:2].tolist(),goal_distance_to_official=float(dg[k]),start_distance_to_official=float(ds[k]),target_offsets=query['high_actor_target_offsets'][k].tolist()))
  selected.append(k)
 stats[str(task_id)]={'eligible_pool':len(candidates),'closest_start_distance':float(ds[first]),'goal_tolerance_world_units':2.0}
sel=np.array(selected)
np.savez_compressed(root/'offline_queries.npz',observations=query['observations'][sel],goals=query['high_actor_goals'][sel],targets=query['high_actor_targets'][sel],indices=query['indices'][sel],goal_indices=query['high_actor_goal_idxs'][sel])
(root/'offline_cases.json').write_text(json.dumps({'cases':cases,'selection':stats,'query_seed':20261103,'sample_pool':65536},indent=2)+'\n')
(root/'maze.json').write_text(json.dumps(maze,indent=2)+'\n')
print('BANK',len(bank),'XY BINS',len(counts));print('CASE SELECTION',stats)
