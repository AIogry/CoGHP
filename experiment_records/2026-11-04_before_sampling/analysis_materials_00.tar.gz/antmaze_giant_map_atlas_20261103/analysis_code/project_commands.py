"""Post-hoc conditional nearest-state projection; never used by the actor."""
import os,sys,json,argparse,hashlib,time
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--mode',choices=['offline','online'],required=True);args=p.parse_args()
os.environ.update(CUDA_VISIBLE_DEVICES='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',XLA_PYTHON_CLIENT_PREALLOCATE='false',JAX_PLATFORMS='cuda',XLA_FLAGS='--xla_gpu_deterministic_ops');sys.dont_write_bytecode=True
root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_map_atlas_20261103');snapshot=root.parent/'antmaze_giant_v2_diagnosis_20261103'/args.version/'snapshot'
manifest=json.loads((snapshot/'campaign.json').read_text());source=Path(manifest['source_dir']);sys.path[:0]=[str(source/'impls'),str(source)]
import jax
import jax.numpy as jnp
from agents.navigation import NavigationAgent
from utils.flax_utils import restore_agent
assert jax.default_backend()=='gpu'
bank=np.load(root/'candidate_bank.npz');candidates=bank['observations'];candidate_indices=bank['indices'];queries=np.load(root/'offline_queries.npz')
result={'version':args.version,'complete':False,'mode':args.mode,'bank_size':len(candidates),'bank_source':'training data; validation labels excluded','mapping':'argmin over training states y of mean((phi(s,y)-z)**2), separately for each current state s','topk':16,'physical_gpu':1,'updates':0,'source_signature':manifest['source']['code_signature'],'runs':{}}
anchors=np.load(root/f'{args.version}_anchors.npz') if args.mode=='online' else None
for directory in sorted((snapshot/'runs').iterdir()):
 flags=json.loads((directory/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()};m=cfg['num_subgoals'];state=json.loads((directory/'run.json').read_text());metadata=json.loads((directory/'checkpoint_metadata.json').read_text());artifacts=Path(state['run_dir'])/'artifacts'
 agent=NavigationAgent.create(flags['seed'],queries['observations'][:1],np.zeros((1,8),np.float32),cfg);agent=restore_agent(agent,str(artifacts),1000000,metadata,True)
 @jax.jit
 def project(agent,obs,commands):
  repeated=jnp.broadcast_to(obs,(len(candidates),obs.shape[-1]))
  encoded=agent.network.select('goal_rep')(jnp.concatenate([repeated,jnp.asarray(candidates)],axis=-1))
  distances=jnp.mean((commands[:,None,:]-encoded[None,:,:])**2,axis=-1)
  vals,ids=jax.lax.top_k(-distances,16)
  return ids,-vals
 @jax.jit
 def offline_commands(agent,obs,goal,targets):
  targets=targets if m==3 else targets[-1:]
  labels=agent.network.select('goal_rep')(jnp.concatenate([jnp.broadcast_to(obs,targets.shape),targets],axis=-1))
  predicted=agent.policy(obs[None],goal[None],jax.random.PRNGKey(0),temperature=0.,return_latents=True)[3][0]
  return jnp.concatenate([predicted,labels]),predicted,labels
 def mapped(ids,residual,actual=None):
  xy=candidates[ids,:2];spread=np.linalg.norm(xy-xy[0],axis=-1)
  out={'xy':xy[0].tolist(),'top_xy':xy.tolist(),'latent_mse':float(residual[0]),'top16_radius90':float(np.quantile(spread,.9)),'candidate_train_index':int(candidate_indices[ids[0]])}
  if actual is not None:out['roundtrip_xy_error']=float(np.linalg.norm(xy[0]-actual[:2]))
  return out
 rows=[];result['runs'][str(m)]={'method':directory.name,'rows':rows}
 if args.mode=='offline':
  for i,(obs,goal,targets) in enumerate(zip(queries['observations'],queries['goals'],queries['targets'])):
   commands,pred,labels=offline_commands(agent,obs,goal,targets);ids,res=map(np.asarray,project(agent,obs,commands));actual=targets if m==3 else targets[-1:]
   projected=[mapped(ids[j],res[j]) for j in range(m)];calibration=[mapped(ids[m+j],res[m+j],actual[j]) for j in range(m)]
   rows.append({'case_index':i,'predicted':projected,'data_roundtrip':calibration,'projection_gap_xy':[float(np.linalg.norm(np.array(projected[j]['xy'])-actual[j,:2])) for j in range(m)],'latent_mse':np.mean((np.asarray(pred)-np.asarray(labels))**2,axis=-1).tolist()})
  errors=[x['roundtrip_xy_error'] for row in rows for x in row['data_roundtrip']];gaps=[x for row in rows for x in row['projection_gap_xy']]
  result['runs'][str(m)]['summary']={'calibration_median':float(np.median(errors)),'calibration_p90':float(np.quantile(errors,.9)),'projection_gap_median':float(np.median(gaps)),'projection_gap_p90':float(np.quantile(gaps,.9))}
 else:
  subset=np.flatnonzero(anchors['meta'][:,0]==m)
  for k,i in enumerate(subset):
   commands=anchors['commands'][i,-m:];ids,res=map(np.asarray,project(agent,anchors['observations'][i],commands));rows.append({'anchor_id':int(i),'meta':anchors['meta'][i].tolist(),'predicted':[mapped(ids[j],res[j]) for j in range(m)]})
   if k%100==0:print('PROGRESS',args.version,m,k,len(subset),flush=True)
 (root/f'{args.version}_{args.mode}_projections.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
 print('PROJECTED',args.version,m,args.mode,len(rows),result['runs'][str(m)].get('summary'),flush=True);jax.clear_caches()
result['complete']=True;(root/f'{args.version}_{args.mode}_projections.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
