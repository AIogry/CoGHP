import json,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
root=Path('/home/eai/Research/CoGHP/impls/exp/antmaze_giant_map_atlas_20261103')
visual=Path('/home/eai/.codex/visualizations/2026/10/17/01a14918-7671-75c1-b248-83365eccb915/coghp-maze-planner-atlas.html')
maze=json.loads((root/'maze.json').read_text());cases=json.loads((root/'offline_cases.json').read_text());xy=np.asarray(maze['cell_xy']);cell=float(xy[0,1,0]-xy[0,0,0]);bounds=[float(xy[0,0,0]-cell/2),float(xy[0,-1,0]+cell/2),float(xy[0,0,1]-cell/2),float(xy[-1,0,1]+cell/2)]
r=lambda a:np.round(a,2).tolist()
D={'maze':maze['grid'],'origin':xy[0,0].tolist(),'cell':cell,'bounds':bounds,'cases':[],'models':{}}
for c in cases['cases']:
 D['cases'].append({'task':c['task'],'case':c['case'],'index':c['index'],'start':r(c['observation_xy']),'goal':r(c['goal_xy']),'targets':r(c['data_target_xy']),'path':r(c['data_path_xy']),'goalDistance':round(c['goal_distance_to_official'],3),'startDistance':round(c['start_distance_to_official'],3)})
paths={};off={};online={};calibration={}
for v in ['v0','v1','v2']:
 paths[v]=json.loads((root/f'{v}_paths.json').read_text());off[v]=json.loads((root/f'{v}_offline_projections.json').read_text());online[v]=json.loads((root/f'{v}_online_projections.json').read_text());assert paths[v]['complete'] and off[v]['complete'] and online[v]['complete']
 calibration[v]={}
 for m in ['1','3']:
  model={'offline':[],'tasks':{}};D['models'][v+'m'+m]=model;calibration[v][m]=off[v]['runs'][m]['summary']
  def pred(z):return {'xy':r(z['xy']),'top':r(z['top_xy'][1:5]),'spread':round(z['top16_radius90'],3)}
  for row in off[v]['runs'][m]['rows']:
   model['offline'].append({'pred':[pred(z) for z in row['predicted']],'cal':[{'xy':r(z['xy']),'error':round(z['roundtrip_xy_error'],3)} for z in row['data_roundtrip']]})
  lookup={row['anchor_id']:row['predicted'] for row in online[v]['runs'][m]['rows']}
  for task,task_rows in paths[v]['runs'][m]['tasks'].items():
   entries=[];model['tasks'][task]=entries
   for ep in task_rows['episodes']:
    ids=np.unique(np.r_[np.arange(0,len(ep['path_xy']),5),len(ep['path_xy'])-1]);path=np.asarray(ep['path_xy'])
    entries.append({'steps':ep['steps'],'success':ep['success'],'goal':r(ep['goal_xy']),'path':[[int(i),*r(path[i])] for i in ids],'anchors':[{'t':a['t'],'xy':r(a['xy']),'pred':[pred(z) for z in lookup[a['id']]]} for a in ep['anchors']]})
encoded=json.dumps(D,separators=(',',':'),ensure_ascii=False)
(root/'atlas_compact_data.json').write_text(encoded+'\n')
template=(root/'analysis_code/atlas-template.html').read_text();fragment=template.replace('__ATLAS_DATA__',encoded.replace('</','<\\/'));assert len(fragment.encode())<1000000,len(fragment.encode())
visual.write_text(fragment)
print('INLINE BYTES',visual.stat().st_size,'FILE',visual)
(root/'projection_calibration.json').write_text(json.dumps(calibration,indent=2)+'\n')
# Static scientific figures are separate from the inline visualization.
colors={'v0':'#2869a6','v1':'#d28a1f','v2':'#c33c57'};green='#20805d'
plt.rcParams.update({'font.size':10,'savefig.dpi':180,'axes.spines.top':False,'axes.spines.right':False})
def base(ax):
 for i,row in enumerate(maze['grid']):
  for j,val in enumerate(row):
   if val:ax.add_patch(Rectangle(xy[i,j]-cell/2,cell,cell,facecolor='#d9dde1',edgecolor='none'))
 ax.set(xlim=bounds[:2],ylim=bounds[2:],aspect='equal',xlabel='x (world units)',ylabel='y (world units)');ax.set_xticks([0,20,40,52]);ax.set_yticks([0,12,24,36]);ax.grid(alpha=.1)
for task in range(1,6):
 fig,axes=plt.subplots(2,3,figsize=(15,8.8),sharex=True,sharey=True)
 for ri,m in enumerate(['1','3']):
  for ci,v in enumerate(['v0','v1','v2']):
   ax=axes[ri,ci];base(ax);episodes=paths[v]['runs'][m]['tasks'][str(task)]['episodes']
   for ep in episodes:
    a=np.asarray(ep['path_xy']);ax.plot(a[:,0],a[:,1],color=colors[v],alpha=.5,lw=1.2)
   ep=episodes[0];anchor=ep['anchors'][0];row=next(x for x in online[v]['runs'][m]['rows'] if x['anchor_id']==anchor['id']);predicted=np.array([x['xy'] for x in row['predicted']][::-1]);chain=np.vstack([anchor['xy'],predicted]);ax.plot(chain[:,0],chain[:,1],'--',color=colors[v],lw=1.4);ax.scatter(predicted[:,0],predicted[:,1],marker='^',color=colors[v],s=35,zorder=6)
   ax.scatter(*ep['path_xy'][0],color='black',s=24,zorder=7);ax.scatter(*ep['goal_xy'],marker='*',color='black',s=100,zorder=7)
   ax.set_title(f"{v} / M{m} | diagnostic successes {sum(x['success'] for x in episodes)}/4")
 fig.suptitle(f'Task {task}: actual executed paths | beta=3, seed0, 1M | same four evaluation seeds\nDashed triangles: projected initial subgoals of episode 0, not collision-free planned paths',fontsize=12)
 fig.tight_layout();fig.savefig(root/f'task_{task}_routes.png');plt.close(fig)
 fig,axes=plt.subplots(2,3,figsize=(15,8.8),sharex=True,sharey=True);case_idx=(task-1)*6;c=cases['cases'][case_idx]
 for ri,m in enumerate(['1','3']):
  for ci,v in enumerate(['v0','v1','v2']):
   ax=axes[ri,ci];base(ax);raw=np.asarray(c['data_path_xy']);ax.plot(raw[:,0],raw[:,1],color='#555',lw=1.1,alpha=.55)
   row=off[v]['runs'][m]['rows'][case_idx];targets=np.array(c['data_target_xy'])[-int(m):];p=np.array([z['xy'] for z in row['predicted']]);cal=np.array([z['xy'] for z in row['data_roundtrip']]);chain=np.vstack([c['observation_xy'],p[::-1]])
   ax.plot(chain[:,0],chain[:,1],'--',color=colors[v],lw=1.4);ax.scatter(p[:,0],p[:,1],marker='^',color=colors[v],s=45,zorder=5);ax.scatter(targets[:,0],targets[:,1],facecolors='none',edgecolors=green,s=60,zorder=6);ax.scatter(cal[:,0],cal[:,1],marker='s',facecolors='none',edgecolors=green,s=25,zorder=6)
   for j in range(int(m)):
    ax.plot([p[j,0],targets[j,0]],[p[j,1],targets[j,1]],':',color='#555',lw=.8)
   ax.scatter(*c['observation_xy'],color='black',s=24,zorder=7);ax.scatter(*c['goal_xy'],marker='*',color='black',s=100,zorder=7)
   gaps=row['projection_gap_xy'];errs=[z['roundtrip_xy_error'] for z in row['data_roundtrip']]
   ax.set_title(f"{v} / M{m} | near gap {gaps[-1]:.2f}, calibration {errs[-1]:.2f}")
 fig.suptitle(f'Task {task} goal-neighborhood validation case 1 | same data state/goal across six models\nTriangle: predicted projection; circle: real data target; square: data-latent round trip; one cell = 4 units',fontsize=12)
 fig.tight_layout();fig.savefig(root/f'task_{task}_subgoals.png');plt.close(fig)
(root/'methodology.md').write_text('''# 地图可视化方法\n\n比较 v0/v1/v2、H2L1M1/H4L2M3 六组，全部 β3、seed0、1M checkpoint。\n\n- 正式任务：五个 task，每个取官方评估的前四个 episode seed。六组的完整初始状态与 goal 逐元素相同。真实轨迹由原生 CPU policy 执行；每 100 步另行记录 planner command，不反馈到策略。\n- 离线配对：从验证集按现有 MultiHGCDataset 采样 65536 条查询，再选最终 goal 距各 task 官方 goal ≤2 单位、goal 偏移≥200步、近端位移>1 的六条空间分散片段。它们不是从官方起点采集的演示。Task 1 没有接近官方起点的合格片段；图中始终显示真实起点及与官方起点距离。\n- 坐标投影：固定当前完整状态 s，从 7692 个空间分层抽取的训练完整状态 y 中，寻找使 ||phi(s,y)-z||² 最小的候选。每个模型使用自己的冻结 encoder。显示最近候选 XY；没有训练 decoder、没有参数更新、没有把 maze 输入 actor。\n- 校准：对真正的数据标签 z=phi(s,y_data) 做同样检索，并报告检索 XY 与真实 y_data XY 的距离。候选池来自训练集，配对标签来自验证集。校准不是预测 command 投影误差的严格上界。\n- 所有距离均是投影后 XY 距离，不是高层模型直接输出的物理坐标误差。邻近候选点云提示非唯一性。投影候选都来自真实数据，因此不能用“投影点在通道内”证明原始 latent 合法，也不能用虚线穿墙判定实际规划不可行。\n- 正式回放没有配对的真实数据 future target，不人为指定一个数据点当真值。离线配对保留真实数据轨迹和监督标签；M3 以近到远连接50/100/150步目标，模型保存顺序仍为远到近。\n- 原始轨迹和投影以完整精度保存在 JSON/NPZ；交互图将路径每5步降采样、坐标保留2位小数，每个检索点显示前4个额外候选，完整前16候选保存在原始 JSON。\n- 四个回放和六个片段只作可视化，不替代50 episode/任务正式评估，也不估计跨训练 seed 的显著性。\n''')
provenance={'created_at':datetime.now(timezone.utc).isoformat(),'model_updates':False,'training_code_changed':False,'versions':['v0','v1','v2'],'M':[1,3],'checkpoint':1000000,'beta':3,'official_replay_count':120,'offline_cases':30,'candidate_bank_size':7692,'projection_anchors':sum(len(x['rows']) for d in online.values() for x in d['runs'].values()),'raw_inputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.npz')},'analysis_code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'analysis_code').iterdir() if p.is_file()},'inline_path':str(visual)}
(root/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print('STATIC FIGURES DONE',root)
