"""Group-standardized AWR shares with raw-episode cluster bootstrap."""
import os,json,csv
from pathlib import Path
import numpy as np
from audit_core import standardized_estimate
ROOT=Path(__file__).resolve().parents[1];p=json.loads((ROOT/'protocol.json').read_text());a=np.load(ROOT/'junction_queries.npz');geo=json.loads((ROOT/'geometry.json').read_text());ncell=len(geo['grid'])*len(geo['grid'][0]);ncols=len(geo['grid'][0]);E=50;B=p['bootstrap_replicates']
boot=np.random.default_rng(p['bootstrap_seed']).multinomial(E,np.full(E,1/E),size=B).astype(np.float64)
np.savez_compressed(ROOT/'bootstrap_episode_counts.npz',counts=boot,seed=p['bootstrap_seed'])
base=a['base_eligible'];left=a['left_before_target'];returned=a['returned_by_target'];unclipped=~a['clipped'];common=base&left[:,0]&unclipped.all(1)
view_masks={
 'first_exit':[base&left[:,h]&~returned[:,h] for h in range(3)],
 'supervision':[base&left[:,h] for h in range(3)],
 'first_exit_common':[common&~returned[:,2]]*3,
 'supervision_common':[common]*3}
grouping={'strict':(a['junction'].astype(np.int64)*ncell+a['incoming'])*ncell+a['goal_cell'],
 'same_exit_region':(a['junction'].astype(np.int64)*ncell+a['incoming'])*ncell+a['goal_region']}
weights=a['weights'].astype(np.float64);advantages=a['advantages'].astype(np.float64);y=a['Y'];visits=a['visit_id'];episodes=a['episode_id'];exits=a['first_exit'];bins=a['distance_bin'];base_indices=np.flatnonzero(base)
category_names=['single_exit','multiple_same_category','mixed_below_support','mixed_supported']

def records(mask,kind,h=None):
 idx=np.flatnonzero(mask);g=grouping[kind][idx];order=np.argsort(g,kind='stable');idx=idx[order];g=g[order]
 boundaries=np.r_[0,np.flatnonzero(np.diff(g))+1,len(g)] if len(g) else np.array([0])
 out=[]
 for lo,hi in zip(boundaries[:-1],boundaries[1:]):
  ii=idx[lo:hi];short=ii[y[ii]==1];long=ii[y[ii]==0]
  ns=len(np.unique(visits[short]));nl=len(np.unique(visits[long]));es=len(np.unique(episodes[short]));el=len(np.unique(episodes[long]));ne=len(np.unique(exits[ii]));mixed=ns>0 and nl>0;supported=mixed and min(ns,nl)>=5 and min(es,el)>=3
  cat='single_exit' if ne==1 else ('multiple_same_category' if not mixed else ('mixed_supported' if supported else 'mixed_below_support'))
  first=int(ii[0]);J=int(a['junction'][first]);inc=int(a['incoming'][first]);endkey=int(a['goal_cell'][first] if kind=='strict' else a['goal_region'][first]);db=int(bins[first]);assert np.all(bins[ii]==db)
  row={'group_id':int(g[lo]),'junction':J,'junction_cell':f'{J//ncols},{J%ncols}','incoming':inc,'incoming_cell':f'{inc//ncols},{inc%ncols}','goal_key':endkey,'distance_bin':db,'category':cat,'queries':len(ii),'physical_visits':len(np.unique(visits[ii])),'episodes':len(np.unique(episodes[ii])),'observed_exits':ne,'short_visits':ns,'nonshort_visits':nl,'short_episodes':es,'nonshort_episodes':el,'short_queries':len(short),'nonshort_queries':len(long),'_idx':ii}
  if kind=='strict':row['goal_cell']=f'{endkey//ncols},{endkey%ncols}'
  else:row['goal_region']=endkey
  if h is not None:
   w=weights[ii,h];sy=y[ii];n=len(ii);ws=w.sum();raw=sy.mean();awr=float(w@sy/ws) if ws>0 else None
   row.update(p_raw=float(raw),p_awr=awr,delta_pp=None if awr is None else 100*(awr-raw),weight_sum=float(ws),weight_mean=float(w.mean()),cap_fraction=float(np.mean(w>=100*(1-1e-5))),max_episode_query_fraction=float(np.bincount(episodes[ii],minlength=E).max()/n))
   if mixed and ws>0:
    neps=np.bincount(episodes[ii],minlength=E);ny=np.bincount(episodes[ii],weights=sy,minlength=E);we=np.bincount(episodes[ii],weights=w,minlength=E);wy=np.bincount(episodes[ii],weights=w*sy,minlength=E);loo=[]
    for ep in np.flatnonzero(neps):
     if n-neps[ep]>0 and ws-we[ep]>0:loo.append(100*((w@sy-wy[ep])/(ws-we[ep])-(sy.sum()-ny[ep])/(n-neps[ep])))
    row['leave_one_episode_delta_min_pp']=float(min(loo)) if loo else None;row['leave_one_episode_delta_max_pp']=float(max(loo)) if loo else None
    row['negative_after_every_episode_drop']=bool(supported and awr<raw and loo and max(loo)<0)
   for label,arr in [('short',short),('nonshort',long)]:
    aa=advantages[arr,h];ww=weights[arr,h]
    for key,val in distribution(arr,aa,ww).items():row[label+'_'+key]=val
  out.append(row)
 return out

def distribution(idx,adv,w):
 if not len(idx):return {'n':0,'visits':0,'episodes':0,'adv_mean':None,'adv_q10':None,'adv_median':None,'adv_q90':None,'adv_abs_le_0p1_fraction':None,'weight_mean':None,'weight_median':None,'weight_near_one_fraction':None,'cap_fraction':None,'query_weight_ess':None}
 return dict(n=len(idx),visits=len(np.unique(visits[idx])),episodes=len(np.unique(episodes[idx])),adv_mean=float(adv.mean()),adv_q10=float(np.quantile(adv,.1)),adv_median=float(np.median(adv)),adv_q90=float(np.quantile(adv,.9)),adv_abs_le_0p1_fraction=float(np.mean(abs(adv)<=.1)),weight_mean=float(w.mean()),weight_median=float(np.median(w)),weight_near_one_fraction=float(np.mean((w>=.9)&(w<=1.1))),cap_fraction=float(np.mean(w>=100*(1-1e-5))),query_weight_ess=float(w.sum()**2/(w@w)) if w@w>0 else 0.)

def coverage(rs,idx):
 out=[];denom=len(idx);visitdenom=len(np.unique(visits[idx]))
 for cat in category_names:
  selected=[r for r in rs if r['category']==cat];ii=np.concatenate([r['_idx'] for r in selected]) if selected else np.array([],int)
  pairs=sum(r['physical_visits'] for r in selected)
  out.append({'category':cat,'groups':len(selected),'queries':len(ii),'query_share':len(ii)/denom if denom else None,'physical_visits':len(np.unique(visits[ii])),'physical_visit_any_coverage':len(np.unique(visits[ii]))/visitdenom if visitdenom else None,'episodes':len(np.unique(episodes[ii])),'visit_goal_group_pairs':pairs})
 return out

def aggregate(rs,h,level):
 chosen=[r for r in rs if r['category']=='mixed_supported' or (level=='all_mixed_exploratory' and r['category']=='mixed_below_support')]
 cols=[]
 if chosen:
  for r in chosen:
   ii=r['_idx'];ep=episodes[ii];yy=y[ii];w=weights[ii,h]
   cols.append(np.array([np.bincount(ep,minlength=E),np.bincount(ep,weights=yy,minlength=E),np.bincount(ep,weights=w,minlength=E),np.bincount(ep,weights=w*yy,minlength=E)],dtype=float))
  mats=np.stack(cols,axis=1);n,Y,W,WY=mats.sum(2);resampled=[boot@x.T for x in mats]
  nb,yb,wb,wyb=resampled;valid=(nb>0)&(wb>0);raw_b=np.divide(yb,nb,out=np.zeros_like(yb),where=nb>0);awr_b=np.divide(wyb,wb,out=np.zeros_like(wyb),where=wb>0)
  idx=np.concatenate([r['_idx'] for r in chosen]);short=idx[y[idx]==1];long=idx[y[idx]==0]
 else:
  mats=np.zeros((4,0,E));n=Y=W=WY=np.zeros(0);idx=np.array([],int);short=long=idx
 output=[]
 for equal in (False,True):
  est=standardized_estimate(n,Y,W,WY,equal)
  item={'support_level':level,'group_weighting':'equal_group' if equal else 'sampler_query_frequency','groups':len(chosen),'queries':len(idx),'physical_visits':len(np.unique(visits[idx])),'episodes':len(np.unique(episodes[idx])),'junctions':len({r['junction'] for r in chosen}),'status':'ok' if est else 'insufficient_support','p_raw':None,'p_awr':None,'delta_pp':None,'delta_ci95_low_pp':None,'delta_ci95_high_pp':None,'bootstrap_valid_replicates':0}
  if est:
   item.update(est)
   mix=np.where(valid,1. if equal else nb,0.);den=mix.sum(1);mix=np.divide(mix,den[:,None],out=np.zeros_like(mix),where=den[:,None]>0)
   pr=(mix*raw_b).sum(1);pw=(mix*awr_b).sum(1);dd=100*(pw-pr);good=den>0
   item.update(delta_ci95_low_pp=float(np.quantile(dd[good],.025)),delta_ci95_high_pp=float(np.quantile(dd[good],.975)),p_raw_ci95=np.quantile(pr[good],[.025,.975]).tolist(),p_awr_ci95=np.quantile(pw[good],[.025,.975]).tolist(),bootstrap_valid_replicates=int(good.sum()))
  for label,ii in [('short',short),('nonshort',long)]:
   for key,val in distribution(ii,advantages[ii,h],weights[ii,h]).items():item[label+'_'+key]=val
  output.append(item)
 return output

basecoverage=[];covrows=[];deltarows=[];grouprows=[];statuses=[]
for kind in grouping:
 rs=records(base,kind)
 for db in ('all',1,2,3):
  rr=rs if db=='all' else [r for r in rs if r['distance_bin']==db];idx=np.flatnonzero(base if db=='all' else base&(bins==db))
  for row in coverage(rr,idx):basecoverage.append({'grouping':kind,'distance_bin':db,**row})
for view,masks in view_masks.items():
 for h,H in enumerate([50,100,150]):
  mask=masks[h]
  for kind in grouping:
   rs=records(mask,kind,h)
   for row in rs:grouprows.append({'grouping':kind,'view':view,'horizon':H,**{k:v for k,v in row.items() if k!='_idx'}})
   for db in ('all',1,2,3):
    rr=rs if db=='all' else [r for r in rs if r['distance_bin']==db];idx=np.flatnonzero(mask if db=='all' else mask&(bins==db))
    for row in coverage(rr,idx):covrows.append({'grouping':kind,'view':view,'horizon':H,'distance_bin':db,**row})
    for level in ['supported','all_mixed_exploratory']:
     for row in aggregate(rr,h,level):deltarows.append({'grouping':kind,'view':view,'horizon':H,'distance_bin':db,**row})
  # Category/weight-mass attribution over the same base query pool, not group-mixed estimator.
  for db in ('all',1,2,3):
   allidx=np.flatnonzero(base if db=='all' else base&(bins==db));w=weights[allidx,h]
   categories={'not_yet_departed':~left[allidx,h],'departed_no_return':left[allidx,h]&~returned[allidx,h],'returned':left[allidx,h]&returned[allidx,h]}
   for tag,take in categories.items():
    ii=allidx[take];statuses.append({'view':view,'horizon':H,'distance_bin':db,'category':tag,'queries':len(ii),'physical_visits':len(np.unique(visits[ii])),'episodes':len(np.unique(episodes[ii])),'query_fraction':float(take.mean()) if len(take) else None,'weight_fraction':float(weights[ii,h].sum()/w.sum()) if w.sum()>0 else None,'clipped_fraction':float(a['clipped'][ii,h].mean()) if len(ii) else None})
 print('AGGREGATED',view,flush=True)
# Status mass does not depend on chosen view; deduplicate repeated records.
statuses=[{k:v for k,v in r.items() if k!='view'} for r in statuses if r['view']=='first_exit']
def write_csv(path,rows):
 keys=[]
 for r in rows:
  for k in r:
   if k not in keys:keys.append(k)
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:json.dumps(v) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in rows)
for name,rows in [('coverage_base',basecoverage),('coverage_by_view',covrows),('delta_tables',deltarows),('group_results',grouprows),('label_status_mass',statuses)]:
 write_csv(ROOT/(name+'.csv'),rows)
 (ROOT/(name+'.json')).write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
primary=[r for r in deltarows if r['grouping']=='strict' and r['view']=='first_exit' and r['horizon']==50 and r['support_level']=='supported' and r['group_weighting']=='sampler_query_frequency']
summary={'primary':primary,'coverage_base':basecoverage,'coverage_by_view':covrows,'delta_tables':deltarows,'label_status_mass':statuses,'group_results_count':len(grouprows),'bootstrap_replicates':B,'bootstrap_episode_count':E,'notes':['Unique physical visit counts can overlap across goal groups, coverage classes and distance strata; query-share categories partition queries, physical visit coverages need not sum to100%.','Primary50 horizon and all support thresholds fixed before results.','Group sets selected using physical support are fixed during cluster bootstrap, not reselected per replicate. Empty/zero-weight groups dropped identically for raw and AWR mixing within a replicate.','All-mixed and goal-region-merging rows are exploratory sensitivities, not substitutes for strict-group support.','Weight ESS is query-level concentration, not a count of independent visits or episodes.','No posterior claim about actor probabilities, actual historical gradient contributions or optimal dynamics routes.']}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print('PRIMARY',json.dumps(primary),flush=True)
