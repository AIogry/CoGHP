"""Verify the delivered bundle with Python's standard library only."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
count=0;size=0;listed=set()
for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
    digest,name=line.split('  ',1);p=ROOT/name
    assert ROOT.resolve() in p.resolve().parents, name
    assert not p.is_symlink(), name
    with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    assert actual==digest, name
    count+=1;size+=p.stat().st_size;listed.add(name)
extra=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in listed and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts and p.suffix!='.pyc']
assert not extra,extra
print(f'PASS: {count} files, {size:,} bytes, SHA-256 verified; no unlisted payload files.')
