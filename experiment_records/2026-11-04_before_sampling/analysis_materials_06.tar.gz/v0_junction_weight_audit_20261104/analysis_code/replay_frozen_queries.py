"""Portable replay using only packaged inputs. No simulator and no training.

Default: verify hashes, all original sampler indices, and the 2048-query probe.
--full: additionally re-evaluate every stored junction query with the checkpoint.
Use a compatible Python/JAX environment; versions are in environment.json.
"""
import os, sys, json, hashlib, argparse
from pathlib import Path
os.environ.update(JAX_PLATFORMS='cpu', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'inputs'; SOURCE = INPUT / 'frozen_v0_source'
sys.path[:0] = [str(SOURCE / 'impls'), str(SOURCE)]
import numpy as np
import jax, jax.numpy as jnp
from agents.navigation import NavigationAgent, stable_awr
from ogbench.utils import load_dataset
from utils.datasets import Dataset, MultiHGCDataset
from utils.flax_utils import restore_agent

parser = argparse.ArgumentParser(); parser.add_argument('--full', action='store_true'); args = parser.parse_args()
p = json.loads((ROOT / 'protocol.json').read_text())
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
assert sha(INPUT / 'params_1000000.pkl') == p['checkpoint_sha256']
assert sha(INPUT / 'antmaze-giant-navigate-v0-val.npz') == p['dataset_sha256']
flags = json.loads((INPUT / 'flags.json').read_text())
cfg = {k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
raw = load_dataset(INPUT / 'antmaze-giant-navigate-v0-val.npz', compact_dataset=True)
data = Dataset.create(**raw); obs = raw['observations']
saved = np.load(ROOT / 'unfiltered_sample_indices.npz')
sampler = MultiHGCDataset(data, cfg, rng=np.random.default_rng(p['sampler_seed']))
for start in range(0, p['sample_count'], p['sampler_batch_size']):
    b = sampler.sample(p['sampler_batch_size'], evaluation=True)
    sl = slice(start, start + p['sampler_batch_size'])
    for key,value in [('indices',b['indices']),('goals',b['high_actor_goal_idxs']),('targets',b['high_actor_target_idxs'][:,::-1]),('effective_end',b['trajectory_final_idxs'])]:
        assert np.array_equal(saved[key][sl], value), (start,key)
print('All 1,048,576 original sampler query indices reproduced.', flush=True)
b = MultiHGCDataset(data, cfg, rng=np.random.default_rng(20261030)).sample(2048, evaluation=True)
ref = np.load(INPUT / 'historical_reference/hrm_h4l2_m3_value_samples.npz')
for key,value in [('query_indices',b['indices']),('goal_indices',b['high_actor_goal_idxs']),('target_indices_near_to_far',b['high_actor_target_idxs'][:,::-1])]:
    assert np.array_equal(ref[key],value),key
agent = NavigationAgent.create(flags['seed'], b['observations'][:1], b['actions'][:1], cfg)
agent = restore_agent(agent, str(INPUT), 1000000, json.loads((INPUT / 'checkpoint_metadata.json').read_text()), True)
@jax.jit
def score(agent, start, targets, goals):
    value = agent.network.select('value')
    initial = jnp.mean(value(start, goals), axis=0)
    future = jnp.stack([jnp.mean(value(targets[:,i], goals), axis=0) for i in range(3)], axis=1)
    return initial, future, stable_awr(future-initial[:,None],3.,100.)
initial,future,w = map(np.asarray, score(agent,b['observations'],b['high_actor_targets'][:,::-1],b['high_actor_goals']))
errors = dict(initial=float(abs(initial-ref['initial']).max()), future=float(abs(future-ref['future_near_to_far']).max()))
assert max(errors.values()) < 2e-4
full_errors = None
if args.full:
    q = np.load(ROOT / 'junction_queries.npz'); full_errors = dict(value_start=0.,value_targets=0.,weights=0.)
    for start in range(0,len(q['start_index']),2048):
        ii = np.arange(start,min(start+2048,len(q['start_index']))); n=len(ii);ii=np.pad(ii,(0,2048-n),mode='edge')
        values = score(agent,obs[q['start_index'][ii]],obs[q['target_indices'][ii]],obs[q['goal_index'][ii]])
        for key,value in zip(full_errors,values):
            error=float(abs(np.asarray(value)[:n]-q[key][start:start+n]).max());full_errors[key]=max(full_errors[key],error)
    assert max(full_errors.values()) < .06, full_errors
result = dict(passed=True, all_sampler_indices_exact=True, reference_errors=errors, full_query_errors=full_errors,
              input_paths_are_bundle_relative=True, backend=jax.default_backend(),training_updates=0,simulator_rollouts=0)
(ROOT/'portable_replay_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
