"""Pure geometry/event/aggregation helpers. No simulator or model updates."""
from collections import deque
import numpy as np

def geometry(grid):
    grid=np.asarray(grid); nr,nc=grid.shape; free=np.flatnonzero(grid.ravel()==0)
    adj={}
    for x in free:
        r,c=divmod(int(x),nc)
        adj[int(x)]=[a*nc+b for a,b in [(r-1,c),(r+1,c),(r,c-1),(r,c+1)]
                     if 0<=a<nr and 0<=b<nc and grid[a,b]==0]
    distances=np.full((grid.size,grid.size),-1,np.int16)
    for s in free:
        distances[s,s]=0;q=deque([int(s)])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if distances[s,v]<0:distances[s,v]=distances[s,u]+1;q.append(v)
    junctions=np.array([x for x in free if len(adj[int(x)])==3],np.int32)
    return free,adj,distances,junctions

def physical_visits(core_cells, episode_ends, junctions, adj):
    """One visit is one run in the core-hit sequence; border-only jitter is ignored.

    Adjacent entry/exit is required. A skipped adjacent core is ambiguous, not
    inferred from a later return. Episode boundaries come from raw NPZ terminals.
    """
    core_cells=np.asarray(core_cells);ends=np.asarray(episode_ends);starts=np.r_[0,ends[:-1]+1]
    frame_visit=np.full(len(core_cells),-1,np.int32);frame_episode=np.empty(len(core_cells),np.int16)
    events=[];junction_set=set(map(int,junctions))
    for episode,(lo,hi) in enumerate(zip(starts,ends)):
        frame_episode[lo:hi+1]=episode
        hits=np.flatnonzero(core_cells[lo:hi+1]>=0)+lo
        if len(hits)==0:continue
        hitcells=core_cells[hits];changes=np.flatnonzero(np.r_[True,np.diff(hitcells)!=0])
        run_start=hits[changes];run_last=hits[np.r_[changes[1:]-1,len(hits)-1]];run_cell=hitcells[changes]
        next_same=np.full(len(run_cell),-1,np.int32);seen={}
        for k in range(len(run_cell)-1,-1,-1):
            node=int(run_cell[k]);next_same[k]=seen.get(node,-1);seen[node]=k
        for k,J in enumerate(run_cell):
            J=int(J)
            if J not in junction_set:continue
            before=int(run_cell[k-1]) if k else -1
            after=int(run_cell[k+1]) if k+1<len(run_cell) else -1
            incoming=before if before in adj[J] else -1
            outgoing=after if after in adj[J] else -1
            exit_idx=int(run_start[k+1]) if outgoing>=0 else -1
            return_idx=int(run_start[next_same[k]]) if next_same[k]>=0 else -1
            event_id=len(events)
            assigned=hits[changes[k]:(changes[k+1] if k+1<len(changes) else len(hits))]
            frame_visit[assigned]=event_id
            events.append(dict(visit_id=event_id,episode_id=episode,junction=J,
                entry_idx=int(run_start[k]),last_core_idx=int(run_last[k]),core_frames=len(assigned),
                incoming=incoming,first_exit=outgoing,first_exit_idx=exit_idx,first_return_idx=return_idx,
                incoming_status='known' if incoming>=0 else ('episode_start' if before<0 else 'skipped_adjacent_core'),
                exit_status='known' if outgoing>=0 else ('episode_end' if after<0 else 'skipped_adjacent_core'),
                previous_stable_cell=before,next_stable_cell=after,
                raw_episode_start=int(lo),raw_episode_end=int(hi)))
    return events,frame_visit,frame_episode

def distance_bin(distance):
    distance=np.asarray(distance)
    return np.where(distance==0,0,np.where(distance<10,1,np.where(distance<20,2,3))).astype(np.int8)

def goal_regions(junctions,adj,distances,free):
    """Connected goal cells sharing shortest exit set AND distance stratum."""
    region=np.full((distances.shape[0],distances.shape[0]),-1,np.int16)
    signatures={}; components=[]
    for J in junctions:
        J=int(J);sig={}
        for g in free:
            if g==J:continue
            shorter=tuple(e for e in adj[J] if distances[e,g]==distances[J,g]-1)
            sig[int(g)]=(shorter,int(distance_bin(distances[J,g])))
        todo=set(sig);reg=0
        while todo:
            start=min(todo);todo.remove(start);q=[start];members=[]
            while q:
                x=q.pop();members.append(x);region[J,x]=reg
                for y in adj[x]:
                    if y in todo and sig[y]==sig[start]:todo.remove(y);q.append(y)
            components.append(dict(junction=J,region=reg,goal_cells=sorted(members),shortest_exits=list(sig[start][0]),distance_bin=sig[start][1]));reg+=1
        signatures[J]=sig
    return region,components

def group_support(group,visit,episode,y):
    """Coverage classes and per-class independent physical support."""
    records=[]
    for g in np.unique(group):
        idx=np.flatnonzero(group==g);values=np.unique(y[idx]);v=visit[idx];e=episode[idx]
        short=idx[y[idx]==1];long=idx[y[idx]==0]
        nvs=len(np.unique(visit[short]));nvl=len(np.unique(visit[long]));nes=len(np.unique(episode[short]));nel=len(np.unique(episode[long]))
        records.append({'group':int(g),'n':len(idx),'visits':len(np.unique(v)),'episodes':len(np.unique(e)),
                        'short_visits':nvs,'nonshort_visits':nvl,'short_episodes':nes,'nonshort_episodes':nel,
                        'mixed':len(values)==2,'supported':nvs>=5 and nvl>=5 and nes>=3 and nel>=3})
    return records

def standardized_estimate(n,y,w,wy,equal=False):
    n,y,w,wy=map(lambda a:np.asarray(a,dtype=float),(n,y,w,wy))
    valid=(n>0)&(w>0)
    if not valid.any():return None
    mix=np.where(valid,1.0 if equal else n,0.0);mix/=mix.sum()
    raw=np.divide(y,n,out=np.zeros_like(y),where=n>0)
    awr=np.divide(wy,w,out=np.zeros_like(wy),where=w>0)
    return {'p_raw':float(np.sum(mix*raw)),'p_awr':float(np.sum(mix*awr)),
            'delta_pp':float(100*np.sum(mix*(awr-raw))),'included_groups':int(valid.sum()),'zero_weight_groups':int(np.sum((n>0)&(w<=0)))}
