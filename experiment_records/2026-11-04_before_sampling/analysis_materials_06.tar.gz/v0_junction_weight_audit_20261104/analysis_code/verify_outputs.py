"""Independent checks of stored indices, events, group estimates and support ceiling."""
from pathlib import Path
from collections import defaultdict
import csv, json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
read = lambda name: json.loads((ROOT / (name + '.json')).read_text())
q = np.load(ROOT / 'junction_queries.npz')
f = np.load(ROOT / 'frame_event_index.npz')
pool = np.load(ROOT / 'unfiltered_sample_indices.npz')
events = list(csv.DictReader((ROOT / 'physical_visits.csv').open()))
geo = read('geometry')
nr, nc = np.array(geo['grid']).shape
N = nr * nc
adj = {r['flat_id']: r['neighbors'] for r in geo['junctions']}
checks = []

def check(label, condition):
    assert condition, label
    checks.append(label)

check('Original draw count', len(pool['indices']) == 1048576)
check('All raw episodes preserved', len(f['raw_episode_ends']) == 50)
check('All physical junction visits sampled', len(events) == len(np.unique(q['visit_id'])) == 427)
check('Filter applied after sampler', np.array_equal(q['query_id'], np.flatnonzero(f['visit_id'][pool['indices']] >= 0)))
for src, dest in [('indices', 'start_index'), ('goals', 'goal_index'), ('targets', 'target_indices'), ('effective_end', 'effective_episode_end')]:
    check('Exact original ' + src, np.array_equal(pool[src][q['query_id']], q[dest]))
ep = q['episode_id']; s = q['start_index']; g = q['goal_index']; targets = q['target_indices']
check('No goal crosses raw episode', np.array_equal(f['episode_id'][s], f['episode_id'][g]))
check('No target crosses raw episode', np.all(f['episode_id'][targets] == ep[:, None]))
check('Original compact sampler end is raw end minus one', np.array_equal(q['effective_episode_end'], q['raw_episode_end'] - 1))
check('Actual label indices and near-to-far ordering', np.array_equal(targets, np.minimum(s[:, None] + [50, 100, 150], g[:, None])))
check('No label goes beyond actual sampled goal', np.all(targets <= g[:, None]))
check('Clip labels partition by cause', np.array_equal(q['clipped'], q['clipped_goal_before_episode'] | q['clipped_at_sampler_end']))
check('Cumulative advantage preserved', np.array_equal(q['advantages'], q['value_targets'] - q['value_start'][:, None]))
expected = np.exp(np.minimum(3 * q['advantages'].astype(np.float64), np.log(100.)))
check('Stable AWR weights match mathematical definition', np.allclose(q['weights'], expected, atol=3e-5, rtol=3e-5))
for e in events:
    a = {k: int(v) for k,v in e.items() if k not in ('incoming_status', 'exit_status')}
    j = a['junction']; lo, hi = a['raw_episode_start'], a['raw_episode_end']
    assert lo <= a['entry_idx'] <= a['last_core_idx'] <= hi
    for direction in ['incoming', 'first_exit']:
        assert a[direction] < 0 or a[direction] in adj[j]
    if a['first_exit_idx'] >= 0:
        assert a['last_core_idx'] < a['first_exit_idx'] <= hi
    if a['first_return_idx'] >= 0:
        assert a['first_exit_idx'] < a['first_return_idx'] <= hi
    assert e['incoming_status'] != 'skipped_adjacent_core' and e['exit_status'] != 'skipped_adjacent_core'
checks.append('Every physical visit stays in one episode; entry/exit adjacent; no skipped-core ambiguity')

base = q['base_eligible']; left = q['left_before_target']; ret = q['returned_by_target']
common = base & left[:, 0] & ~q['clipped'].any(axis=1)
mask_views = {
    'first_exit': [base & left[:, h] & ~ret[:, h] for h in range(3)],
    'supervision': [base & left[:, h] for h in range(3)],
    'first_exit_common': [common & ~ret[:, 2]] * 3,
    'supervision_common': [common] * 3,
}
group_ids = {
    'strict': (q['junction'].astype(np.int64) * N + q['incoming']) * N + q['goal_cell'],
    'same_exit_region': (q['junction'].astype(np.int64) * N + q['incoming']) * N + q['goal_region'],
}
group_rows = read('group_results')
for r in group_rows:
    if r['category'] != 'mixed_supported':
        continue
    h = [50, 100, 150].index(r['horizon'])
    ids = np.flatnonzero(mask_views[r['view']][h] & (group_ids[r['grouping']] == r['group_id']))
    for label, y in [('short', 1), ('nonshort', 0)]:
        ii = ids[q['Y'][ids] == y]
        assert len(np.unique(q['visit_id'][ii])) == r[label + '_visits'] >= 5
        assert len(np.unique(ep[ii])) == r[label + '_episodes'] >= 3
checks.append('All supported groups independently deduplicate physical visits and episodes')
for r in read('delta_tables'):
    if r['support_level'] != 'supported' or r['status'] != 'ok':
        continue
    selected = [a for a in group_rows if a['grouping'] == r['grouping'] and a['view'] == r['view'] and a['horizon'] == r['horizon'] and a['category'] == 'mixed_supported' and (r['distance_bin'] == 'all' or a['distance_bin'] == r['distance_bin'])]
    mix = np.array([a['queries'] if r['group_weighting'] == 'sampler_query_frequency' else 1 for a in selected], float)
    mix /= mix.sum()
    raw, awr = [], []
    h = [50, 100, 150].index(r['horizon'])
    for a in selected:
        ii = np.flatnonzero(mask_views[r['view']][h] & (group_ids[r['grouping']] == a['group_id']))
        w = q['weights'][ii, h].astype(np.float64)
        raw.append(q['Y'][ii].mean()); awr.append(w @ q['Y'][ii] / w.sum())
    assert abs(mix @ raw - r['p_raw']) < 1e-10
    assert abs(mix @ awr - r['p_awr']) < 1e-10
    assert abs(100 * (mix @ np.array(awr) - mix @ np.array(raw)) - r['delta_pp']) < 1e-8
checks.append('All supported raw/AWR estimates recomputed directly from stored queries')
for table, keys in [('coverage_base', ['grouping','distance_bin']), ('coverage_by_view', ['grouping','view','horizon','distance_bin'])]:
    groups = defaultdict(list)
    for r in read(table): groups[tuple(r[k] for k in keys)].append(r)
    for rows in groups.values():
        fractions = [r['query_share'] for r in rows if r['query_share'] is not None]
        if fractions: assert abs(sum(fractions) - 1) < 1e-10
checks.append('Coverage categories partition queries within every view and distance bin')
for h in [50,100,150]:
    for db in ['all',1,2,3]:
        rows = [r for r in read('label_status_mass') if r['horizon'] == h and r['distance_bin'] == db]
        assert abs(sum(r['query_fraction'] for r in rows) - 1) < 1e-10
        assert abs(sum(r['weight_fraction'] for r in rows) - 1) < 1e-10
checks.append('Not-yet-left/no-return/returned partition all base queries and weight mass')
boot = np.load(ROOT / 'bootstrap_episode_counts.npz')['counts']
check('Bootstrap units are 50 whole raw episodes', boot.shape == (2000,50) and np.all(boot.sum(1) == 50))

# Independent exhaustive boolean enumeration of feasible (start, future goal)
# pairs for the support ceiling; no geometry shortcut for the time constraints.
from audit_core import geometry, goal_regions, distance_bin
free, all_adj, D, junctions = geometry(geo['grid'])
regions, _ = goal_regions(junctions, all_adj, D, free)
support = defaultdict(lambda: [set(), set(), set(), set()])
for e in events:
    ev = {k:int(v) for k,v in e.items() if k not in ('incoming_status','exit_status')}
    if ev['incoming'] < 0 or ev['first_exit'] < 0: continue
    starts = np.flatnonzero(f['visit_id'] == ev['visit_id'])
    starts = starts[starts <= ev['raw_episode_end'] - 1]
    goals = np.arange(ev['raw_episode_start'], ev['raw_episode_end'])
    labels = np.minimum(starts[:,None] + 50, goals[None,:])
    feasible = (goals[None,:] >= starts[:,None] + 1) & (labels >= ev['first_exit_idx'])
    if ev['first_return_idx'] >= 0: feasible &= labels < ev['first_return_idx']
    cells = np.unique(f['raw_cell'][goals[feasible.any(0)]])
    J = ev['junction']
    for gc in cells:
        if gc == J: continue
        Y = int(D[ev['first_exit'],gc] == D[J,gc] - 1)
        for mode, end in [('strict',gc),('same_exit_region',regions[J,gc])]:
            key = (mode,J,ev['incoming'],int(end),int(distance_bin(D[J,gc])))
            support[key][Y].add(ev['visit_id']);support[key][2+Y].add(ev['episode_id'])
ceiling = read('support_ceiling')['groups']
assert len(ceiling) == len(support)
for r in ceiling:
    counts = support[(r['grouping'],r['junction'],r['incoming'],r['goal_key'],r['distance_bin'])]
    assert [len(x) for x in counts] == [r['nonshort_visits_ceiling'],r['short_visits_ceiling'],r['nonshort_episodes_ceiling'],r['short_episodes_ceiling']]
checks.append('Physical-support ceiling matches exhaustive start/future-goal pair enumeration')
result = dict(passed=True, checks=checks, check_count=len(checks), simulator_rollouts=0, training_updates=0)
(ROOT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
