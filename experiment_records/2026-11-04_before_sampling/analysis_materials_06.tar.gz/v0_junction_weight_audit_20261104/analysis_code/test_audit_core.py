import unittest
import numpy as np
from audit_core import physical_visits,standardized_estimate,group_support

class AuditContracts(unittest.TestCase):
 def test_visits_first_exit_return_and_border_jitter(self):
  cells=np.array([1,1,0,-1,0,2,2,0,0,3,3])
  events,idx,ep=physical_visits(cells,[10],[0],{0:[1,2,3]})
  self.assertEqual(len(events),2)
  self.assertEqual((events[0]['incoming'],events[0]['first_exit'],events[0]['first_exit_idx'],events[0]['first_return_idx']),(1,2,5,7))
  self.assertEqual(idx[2],idx[4]);self.assertNotEqual(idx[4],idx[7])
  self.assertEqual((events[1]['incoming'],events[1]['first_exit']),(2,3))
 def test_episode_boundary_and_unknown_exit(self):
  events,_,_=physical_visits([1,0,0,0,2,0],[2,5],[0],{0:[1,2,3]})
  self.assertEqual(len(events),3)
  self.assertEqual(events[0]['exit_status'],'episode_end')
  self.assertEqual(events[1]['incoming_status'],'episode_start')
 def test_skipped_neighbor_is_not_later_inferred(self):
  events,_,_=physical_visits([1,0,4,2,0],[4],[0],{0:[1,2,3]})
  self.assertEqual(events[0]['first_exit'],-1)
  self.assertEqual(events[0]['exit_status'],'skipped_adjacent_core')
 def test_fifteen_percentage_points(self):
  x=standardized_estimate([10],[4],[100],[55]);self.assertAlmostEqual(x['p_raw'],.4);self.assertAlmostEqual(x['p_awr'],.55);self.assertAlmostEqual(x['delta_pp'],15)
 def test_same_group_mixture(self):
  x=standardized_estimate([10,10],[10,0],[1000,1],[1000,0]);self.assertAlmostEqual(x['delta_pp'],0)
 def test_query_repeats_do_not_create_physical_support(self):
  s=group_support(np.zeros(100,int),np.repeat([0,1],50),np.repeat([0,1],50),np.repeat([0,1],50))[0]
  self.assertTrue(s['mixed']);self.assertFalse(s['supported']);self.assertEqual(s['visits'],2)
 def test_no_supported_weight_is_not_zero_effect(self):
  self.assertIsNone(standardized_estimate([1],[1],[0],[0]))

if __name__=='__main__':unittest.main()
