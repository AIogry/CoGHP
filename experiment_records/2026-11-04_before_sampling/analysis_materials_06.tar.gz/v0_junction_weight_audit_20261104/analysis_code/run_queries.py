"""Frozen-v0 junction AWR audit: sample first, filter second; no simulation."""
import os,sys,json,hashlib,csv,shutil,time
from pathlib import Path
from datetime import datetime,timezone
os.environ.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');sys.dont_write_bytecode=True
import numpy as np
from audit_core import geometry,physical_visits,goal_regions,distance_bin
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
CAMPAIGN=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_antmaze_giant_width32_seed0_20261029')
RUN=CAMPAIGN/'runs/hrm_h4l2_m3/antmaze-giant-navigate-v0/seed_000/attempt_000';ART=RUN/'artifacts'
MAN=json.loads((CAMPAIGN/'campaign.json').read_text());SOURCE=Path(MAN.get('source_dir',CAMPAIGN/'source'))
VAL=Path(MAN['datasets']['antmaze-giant-navigate-v0-val.npz']['path']);CP=ART/'params_1000000.pkl'
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
cp_hash=sha(CP);data_hash=sha(VAL);assert data_hash==MAN['datasets'][VAL.name]['sha256']
protocol=dict(name='frozen-v0-junction-first-exit-AWR-audit',created_at=datetime.now(timezone.utc).isoformat(),
 checkpoint=str(CP),checkpoint_sha256=cp_hash,dataset=str(VAL),dataset_sha256=data_hash,source=str(SOURCE),source_signature=MAN['source']['code_signature'],
 model='v0 H4/L2/M3',checkpoint_step=1000000,high_beta=3,cap=100,horizons_near_to_far=[50,100,150],primary_horizon=50,
 sample_count=1048576,sampler_batch_size=16384,sampler_seed=20261104,filter_order='unchanged MultiHGCDataset sampling first; junction core filter second',
 core_half_width=1.6,cell_width=4,episode_boundary='raw NPZ terminals (not doubled compact-dataset terminal markers)',
 minimum_visits_per_class=5,minimum_episodes_per_class=3,bootstrap_replicates=2000,bootstrap_seed=2026110402,
 primary_group='junction x incoming adjacent cell x exact goal cell',
 sensitivity_group='junction x incoming x connected goal region with identical shortest-exit set and same distance bin',
 distance_bins={'1':'1-9','2':'10-19','3':'>=20'},
 views={'first_exit':'label at/after first adjacent core exit and before next junction core return; clipping retained and flagged',
        'supervision':'label at/after first adjacent core exit, including returns and clipped labels',
        'first_exit_common':'same queries at all horizons: departed by50, all targets untruncated, no return by150',
        'supervision_common':'same queries at all horizons: departed by50 and all targets untruncated; returns retained'},
 group_mixture='first compute within-group shares, then mix both raw and AWR with identical n_g-proportional weights; equal-group sensitivity also reported',
 bootstrap='resample all50 original raw episodes with replacement; keep originally supported group set fixed; absent/zero-weight groups omitted identically from paired estimates; no horizon-wise resampling of individual frames',
 interpretation='Delta is allocation of frozen high-loss sample weights, not actor probability change or reconstruction of historical gradients',
 numerical_backend='CPU, matching historical probe backend',training_updates=0,simulator_rollouts=0)
assert not (ROOT/'protocol.json').exists(),'Refuse overwrite fixed protocol'
(ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(ROOT/'inputs').mkdir(exist_ok=True)
for p in [ART/'flags.json',ART/'checkpoint_metadata.json',RUN/'run.json']:shutil.copy2(p,ROOT/'inputs'/p.name)
sys.path[:0]=[str(SOURCE/'impls'),str(SOURCE)]
import jax,jax.numpy as jnp
from agents.navigation import NavigationAgent,stable_awr
from ogbench.utils import load_dataset
from utils.datasets import Dataset,MultiHGCDataset
from utils.flax_utils import restore_agent
assert jax.default_backend()=='cpu'
flags=json.loads((ART/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
assert cfg['num_subgoals']==3 and cfg['high_alpha']==3 and cfg['subgoal_steps']==50
raw=load_dataset(VAL,compact_dataset=True);data=Dataset.create(**raw);raw_npz=np.load(VAL);episode_ends=np.flatnonzero(raw_npz['terminals'])
obs=raw['observations'];maze=json.loads((BASE/'antmaze_giant_map_atlas_20261103/maze.json').read_text());grid=np.asarray(maze['grid']);centers=np.asarray(maze['cell_xy']);free,adj,D,junctions=geometry(grid);assert len(free)==86 and len(junctions)==10
ij=np.floor((obs[:,:2]-centers[0,0]+2)/4).astype(int);cells=(ij[:,1]*grid.shape[1]+ij[:,0]).astype(np.int16);assert (grid.ravel()[cells]==0).all()
core=np.where(np.max(np.abs(obs[:,:2]-centers.reshape(-1,2)[cells]),axis=1)<=1.6,cells,-1)
events,frame_visit,episode=physical_visits(core,episode_ends,junctions,adj);region,components=goal_regions(junctions,adj,D,free)
with (ROOT/'physical_visits.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(events[0]));writer.writeheader();writer.writerows(events)
np.savez_compressed(ROOT/'frame_event_index.npz',visit_id=frame_visit,episode_id=episode,raw_cell=cells,core_cell=core,raw_episode_ends=episode_ends)
(ROOT/'geometry.json').write_text(json.dumps({'grid':grid.tolist(),'centers':centers.tolist(),'junctions':[{'flat_id':int(J),'cell':[int(J//grid.shape[1]),int(J%grid.shape[1])],'neighbors':adj[int(J)]} for J in junctions],'goal_region_components':components},indent=2)+'\n')
print('EVENTS',len(events),'episodes',len(episode_ends),'coreframes',int((frame_visit>=0).sum()),flush=True)
# Validate historical sampler indices and cumulative weights before expanding.
q=MultiHGCDataset(data,cfg,rng=np.random.default_rng(20261030)).sample(2048,evaluation=True)
reference=np.load(BASE/'antmaze_giant_weight_discussion_20261031/hrm_h4l2_m3_value_samples.npz')
for key,a,b in [('start',q['indices'],reference['query_indices']),('goal',q['high_actor_goal_idxs'],reference['goal_indices']),('targets_near_to_far',q['high_actor_target_idxs'][:,::-1],reference['target_indices_near_to_far'])]:assert np.array_equal(a,b),key
agent=NavigationAgent.create(flags['seed'],q['observations'][:1],q['actions'][:1],cfg);agent=restore_agent(agent,str(ART),1000000,json.loads((ART/'checkpoint_metadata.json').read_text()),True)
@jax.jit
def query(agent,start,targets,goals):
 value=agent.network.select('value')
 initial=jnp.mean(value(start,goals),axis=0)
 future=jnp.stack([jnp.mean(value(targets[:,i],goals),axis=0) for i in range(3)],axis=1)
 return initial,future,stable_awr(future-initial[:,None],3.,100.)
v0,vf,w=[np.asarray(x) for x in query(agent,q['observations'],q['high_actor_targets'][:,::-1],q['high_actor_goals'])]
a=vf-v0[:,None];refa=reference['future_near_to_far']-reference['initial'][:,None];refw=np.exp(np.minimum(3*refa,np.log(100)))
training_a=np.asarray(agent.high_advantages(q))[:,::-1]
check={'samples':2048,'indices_exact':True,'order':'near-to-far50/100/150; training storagefar-to-near','initial_max_abs_error':float(np.max(abs(v0-reference['initial']))),'future_max_abs_error':float(np.max(abs(vf-reference['future_near_to_far']))),'advantage_max_abs_error':float(np.max(abs(a-refa))),'weight_max_abs_error':float(np.max(abs(w-refw))),'training_advantage_max_abs_error':float(np.max(abs(a-training_a)))}
assert check['initial_max_abs_error']<2e-4 and check['future_max_abs_error']<2e-4 and check['weight_max_abs_error']<.06,check
assert check['training_advantage_max_abs_error']<2e-4,check
old=json.loads((BASE/'antmaze_giant_weight_discussion_20261031/weight_forms.json').read_text())['runs']['hrm_h4l2_m3']['cumulative']['3.0']
check['reference_weight_means']=old['mean_weight'];check['current_weight_means']=w.mean(0).tolist();check['passed']=True
(ROOT/'reference_validation.json').write_text(json.dumps(check,indent=2)+'\n');np.savez_compressed(ROOT/'reference_validation_arrays.npz',initial=v0,future_near_to_far=vf,advantage=a,weight=w,query_indices=q['indices'],goal_indices=q['high_actor_goal_idxs'],target_indices_near_to_far=q['high_actor_target_idxs'][:,::-1])
print('REFERENCE',json.dumps(check),flush=True)
# Do not balance exits, relabel from selected visits, or condition original draws.
sampler=MultiHGCDataset(data,cfg,rng=np.random.default_rng(protocol['sampler_seed']));pools={k:[] for k in ['indices','goals','targets','effective_end']}
for start in range(0,protocol['sample_count'],protocol['sampler_batch_size']):
 b=sampler.sample(protocol['sampler_batch_size'],evaluation=True)
 pools['indices'].append(b['indices'].astype(np.int32));pools['goals'].append(b['high_actor_goal_idxs'].astype(np.int32));pools['targets'].append(b['high_actor_target_idxs'][:,::-1].astype(np.int32));pools['effective_end'].append(b['trajectory_final_idxs'].astype(np.int32))
pool={k:np.concatenate(v) for k,v in pools.items()};np.savez_compressed(ROOT/'unfiltered_sample_indices.npz',**pool)
selected=np.flatnonzero(frame_visit[pool['indices']]>=0);qidx=pool['indices'][selected];gidx=pool['goals'][selected];target=pool['targets'][selected];end=pool['effective_end'][selected];visit=frame_visit[qidx]
assert np.all(gidx>=qidx) and np.all(gidx<=end);assert np.array_equal(target,np.minimum(qidx[:,None]+np.array([50,100,150]),gidx[:,None]))
fields={key:np.array([e[key] for e in events]) for key in ['junction','incoming','first_exit','first_exit_idx','first_return_idx']}
J=fields['junction'][visit];incoming=fields['incoming'][visit];exit=fields['first_exit'][visit];exit_time=fields['first_exit_idx'][visit];return_time=fields['first_return_idx'][visit];gcell=cells[gidx];gdist=D[J,gcell]
y=np.full(len(qidx),-1,np.int8);known=exit>=0;y[known]=(D[exit[known],gcell[known]]==gdist[known]-1).astype(np.int8)
valid_base=(incoming>=0)&known&(gdist>0)
left=(exit_time[:,None]>=0)&(target>=exit_time[:,None]);returned=(return_time[:,None]>=0)&(target>=return_time[:,None]);clipped=target<qidx[:,None]+np.array([50,100,150])
basearrays=dict(query_id=selected.astype(np.int32),start_index=qidx,goal_index=gidx,target_indices=target,effective_episode_end=end,raw_episode_end=episode_ends[episode[qidx]],visit_id=visit,episode_id=episode[qidx],junction=J.astype(np.int16),incoming=incoming.astype(np.int16),first_exit=exit.astype(np.int16),first_exit_index=exit_time,first_return_index=return_time,goal_cell=gcell,goal_distance=gdist,distance_bin=distance_bin(gdist),goal_region=region[J,gcell],Y=y,base_eligible=valid_base,left_before_target=left,returned_by_target=returned,clipped=clipped,clipped_goal_before_episode=clipped&(gidx[:,None]<end[:,None]),clipped_at_sampler_end=clipped&(gidx[:,None]==end[:,None]),horizon_exceeds_sampler_end=qidx[:,None]+np.array([50,100,150])>end[:,None])
print('SAMPLED',protocol['sample_count'],'junction core queries',len(qidx),'uniquevisits',len(np.unique(visit)),'baseeligible',int(valid_base.sum()),flush=True)
values0=[];valuesf=[];weights=[];begin=time.time();bs=2048
for start in range(0,len(qidx),bs):
 ids=np.arange(start,min(start+bs,len(qidx)));n=len(ids);ids=np.pad(ids,(0,bs-n),mode='edge')
 vals=query(agent,obs[qidx[ids]],obs[target[ids]],obs[gidx[ids]])
 values0.append(np.asarray(vals[0])[:n]);valuesf.append(np.asarray(vals[1])[:n]);weights.append(np.asarray(vals[2])[:n])
 if start%(bs*10)==0:print('VALUE',start,len(qidx),'seconds',round(time.time()-begin,1),flush=True)
basearrays.update(value_start=np.concatenate(values0),value_targets=np.concatenate(valuesf),weights=np.concatenate(weights));basearrays['advantages']=basearrays['value_targets']-basearrays['value_start'][:,None]
assert all(np.isfinite(basearrays[k]).all() for k in ['value_start','value_targets','weights','advantages'])
np.savez_compressed(ROOT/'junction_queries.npz',**basearrays)
counts={'original_frames':len(obs),'raw_episodes':len(episode_ends),'junctions':len(junctions),'all_physical_visits':len(events),'core_frames':int((frame_visit>=0).sum()),'sampler_queries':len(pool['indices']),'junction_core_queries':len(qidx),'sampled_unique_visits':len(np.unique(visit)),'sampled_episodes':len(np.unique(episode[qidx])),'unknown_incoming_queries':int((incoming<0).sum()),'unknown_exit_queries':int((exit<0).sum()),'goal_in_junction_cell_queries':int((gdist==0).sum()),'base_eligible_queries':int(valid_base.sum()),'checkpoint_unchanged':sha(CP)==cp_hash,'dataset_unchanged':sha(VAL)==data_hash}
assert counts['checkpoint_unchanged'] and counts['dataset_unchanged']
(ROOT/'sampling_summary.json').write_text(json.dumps(counts,indent=2)+'\n');print('COMPLETE QUERIES',json.dumps(counts),flush=True)
