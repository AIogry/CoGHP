"""Render static, offline-readable Chinese research report and scientific figures."""
from pathlib import Path
from collections import Counter
import csv, json, html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.font_manager import FontProperties
from markdown_it import MarkdownIt

ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
load=lambda name:json.loads((ROOT/(name+'.json')).read_text())
D=load('delta_tables'); C=load('coverage_by_view'); G=load('group_results'); S=load('label_status_mass')
geo=load('geometry'); Q=np.load(ROOT/'junction_queries.npz')
font=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if font.exists(): plt.rcParams['font.family']=FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'figure.facecolor':'white','axes.facecolor':'white','savefig.dpi':170})
COL={'single_exit':'#aebbc8','multiple_same_category':'#71849b','mixed_below_support':'#e9b66b','mixed_supported':'#147d75'}
CN={'single_exit':'仅一个出口','multiple_same_category':'多出口、同一类别','mixed_below_support':'短/非短都有，支持不足','mixed_supported':'短/非短都有，达到门槛'}
DB={'all':'支持组总体',1:'1–9 格',2:'10–19 格',3:'≥20 格'}

def row(view='first_exit',h=50,db='all',grouping='strict',weighting='sampler_query_frequency'):
    return next(r for r in D if r['view']==view and r['horizon']==h and r['distance_bin']==db and r['grouping']==grouping and r['group_weighting']==weighting and r['support_level']=='supported')
def cov(db='all',view='first_exit',h=50):
    return [r for r in C if r['grouping']=='strict' and r['view']==view and r['horizon']==h and r['distance_bin']==db]
def pct(x): return '—' if x is None else f'{100*x:.2f}%'
def delta(x): return '支持不足' if x is None else f'{x:+.2f}'
def ci(r): return '—' if r['delta_pp'] is None else f"[{r['delta_ci95_low_pp']:+.2f}, {r['delta_ci95_high_pp']:+.2f}]"
def table(head,rows): return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def savefig(name):
    plt.savefig(FIG/(name+'.png'),bbox_inches='tight');plt.savefig(FIG/(name+'.svg'),bbox_inches='tight');plt.close()

# First figure: coverage first, supported estimates second. No zero bar for NA.
fig,(ax,bx)=plt.subplots(2,1,figsize=(12,9),gridspec_kw={'height_ratios':[1,1.1]})
left=np.zeros(3)
for cat in COL:
    vals=np.array([next(r['query_share'] for r in cov(db) if r['category']==cat)*100 for db in [1,2,3]])
    ax.barh(range(3),vals,left=left,color=COL[cat],label=CN[cat],height=.58)
    for i,(v,l) in enumerate(zip(vals,left)):
        if v>=4: ax.text(l+v/2,i,f'{v:.1f}%',ha='center',va='center',fontsize=10,color='white' if cat=='mixed_supported' else '#182431')
    left+=vals
ax.set_yticks(range(3),[DB[x] for x in [1,2,3]]);ax.invert_yaxis();ax.set_xlim(0,100)
ax.set_xlabel('同一距离层内的查询占比（50 步首次选路；严格同 goal 格）')
ax.set_title('A  覆盖先于效果：达到门槛的查询只占全部 50 步首次选路查询的 4.05%',loc='left',fontsize=13,pad=14)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.24),ncol=2,frameon=False,fontsize=10)
for h,color,dx in [(50,'#147d75',-.17),(100,'#3b6ca8',0),(150,'#b96134',.17)]:
    for i,db in enumerate([1,2,3]):
        r=row(h=h,db=db)
        if r['delta_pp'] is None:continue
        val=r['delta_pp'];bx.errorbar(i+dx,val,yerr=[[max(0,val-r['delta_ci95_low_pp'])],[max(0,r['delta_ci95_high_pp']-val)]],fmt='o',color=color,capsize=4,label=f'{h} 步' if i==0 else None,ms=7)
bx.axhline(0,color='#9da8b2',lw=1);bx.set_xticks(range(3),[DB[x] for x in [1,2,3]]);bx.set_xlim(-.55,2.5)
bx.text(2,15,'无达到门槛的组\n无法估计',ha='center',va='center',color='#6c7884',fontsize=13)
bx.set_ylabel('短路样本权重份额变化 Δ（百分点）');bx.set_title('B  仅汇总达到支持门槛的组；误差线为 episode bootstrap 95% 区间',loc='left',fontsize=13,pad=14)
bx.legend(frameon=False,ncol=3,loc='lower right');bx.grid(axis='y',alpha=.18)
fig.subplots_adjust(hspace=.7)
savefig('coverage_and_delta')

# Physical coverage map. Cell coordinates are zero-based row,column.
events=list(csv.DictReader((ROOT/'physical_visits.csv').open()));counts=Counter(int(e['junction']) for e in events)
primary=[g for g in G if g['grouping']=='strict' and g['view']=='first_exit' and g['horizon']==50 and g['category']=='mixed_supported']
supported=Counter(g['junction'] for g in primary);grid=np.array(geo['grid']);centers=np.array(geo['centers'])
fig,ax=plt.subplots(figsize=(12,8))
ax.imshow(grid,origin='lower',extent=(-6,58,-6,42),cmap=ListedColormap(['#f5f7f9','#293947']),vmin=0,vmax=1,interpolation='nearest')
for i,j in enumerate(geo['junctions'],1):
    y,x=j['cell'];px,py=centers[y,x];has=j['flat_id'] in supported
    ax.scatter(px,py,s=600,color='#d87b28' if has else '#287f9a',edgecolors='white',linewidths=1.4,zorder=3)
    ax.text(px,py,str(i),ha='center',va='center',color='white',weight='bold',zorder=4)
ax.set_title('10 个三岔口全部纳入；橙色仅 2 个岔口存在达到主结果支持门槛的组',loc='left',pad=18)
ax.set_xlabel('世界坐标 X');ax.set_ylabel('世界坐标 Y')
fig.subplots_adjust(right=.70)
legend='编号   格坐标     物理访问 / 支持组\n\n'+'\n'.join(f"J{i:<2}  {tuple(j['cell'])!s:<10} {counts[j['flat_id']]:>3} / {supported[j['flat_id']]}" for i,j in enumerate(geo['junctions'],1))
fig.text(.73,.72,legend,va='top',fontsize=11,linespacing=1.8)
fig.text(.73,.25,'支持条件：\n每类 ≥5 次不同访问\n且每类 ≥3 个原始 episode\n\n一条访问可以匹配多个 goal；\n查询数不等于独立选路次数。',va='top',fontsize=10,color='#465769',linespacing=1.6)
savefig('junction_coverage_map')

# Advantage distributions and saturation, supported h50 groups only.
ncell=grid.size;gids=(Q['junction'].astype(np.int64)*ncell+Q['incoming'])*ncell+Q['goal_cell']
mask=Q['base_eligible']&Q['left_before_target'][:,0]&~Q['returned_by_target'][:,0]
arrays=[];labels=[];colors=[]
for db in [1,2]:
    use=mask & np.isin(gids,[r['group_id'] for r in primary if r['distance_bin']==db])
    for y,label,color in [(1,'较短出口','#147d75'),(0,'非较短出口','#b96134')]:
        arrays.append(Q['advantages'][use&(Q['Y']==y),0]);labels.append(DB[db]+'\n'+label);colors.append(color)
fig,(ax,bx)=plt.subplots(1,2,figsize=(13,5.5))
bp=ax.boxplot(arrays,whis=(10,90),showfliers=False,patch_artist=True,tick_labels=labels)
for b,color in zip(bp['boxes'],colors): b.set_facecolor(color);b.set_alpha(.7)
ax.axhline(np.log(100)/3,color='#7e4e91',ls='--',label='触顶阈值 A ≈ 1.535')
ax.axhline(0,color='#8794a1',lw=.8);ax.set_ylabel('累计 advantage：V(s_h,g) − V(s_0,g)');ax.set_title('A  h=50；箱体为四分位，须为 10%–90%');ax.legend(frameon=False,fontsize=9)
caps=[]
for db in [1,2]:
    rr=row(db=db);caps.extend([100*rr['short_cap_fraction'],100*rr['nonshort_cap_fraction']])
bx.bar(range(4),caps,color=colors,width=.65);bx.set_xticks(range(4),labels);bx.set_ylim(0,114);bx.set_ylabel('w 达到 100 上限的查询比例（%）');bx.set_title('B  中距离仅一个组：两类均大量触顶')
for i,v in enumerate(caps):bx.text(i,v+2,f'{v:.2f}%',ha='center',fontsize=10)
fig.tight_layout();savefig('advantage_and_saturation')

fig,ax=plt.subplots(figsize=(10,5.6))
for view,color,label in [('first_exit_common','#147d75','共同样本：150 步前均未返回（9 组）'),('supervision_common','#b96134','共同样本：允许后续返回（10 组）')]:
    rr=[row(view,h) for h in [50,100,150]];yy=[x['delta_pp'] for x in rr]
    ax.plot([50,100,150],yy,'o-',color=color,label=label,lw=2,ms=7)
    for h,v in zip([50,100,150],yy):
        dy=(-22 if view=='first_exit_common' else 10) if h==50 else (9 if view=='first_exit_common' else -20)
        ax.annotate(f'{v:+.2f}',(h,v),xytext=(0,dy),textcoords='offset points',ha='center',color=color)
ax.set_xticks([50,100,150]);ax.set_ylim(15,32);ax.set_ylabel('短路样本权重份额变化 Δ（百分点）');ax.set_xlabel('标签跨度 h（环境步）')
ax.set_title('同一条曲线内：查询、支持组、组权重固定，三个标签均未截短',loc='left');ax.legend(frameon=False,loc='lower left');ax.grid(alpha=.15)
fig.text(.12,.01,'两条曲线的样本集合不同，不能把两条曲线之差解释为“折返的因果效应”。95% 区间见报告表格。',fontsize=10,color='#465769')
fig.tight_layout(rect=(0,.04,1,1));savefig('common_sample_horizons')

# Compact tables for direct use, without navigating the long-format full files.
outrows=[]
for view in ['first_exit','supervision']:
    for db in [1,2,3]:
        for h in [50,100,150]:
            r=row(view,h,db);cr=next(x for x in cov(db,view,h) if x['category']=='mixed_supported')
            keys=['view','distance_bin','horizon','groups','queries','physical_visits','episodes','p_raw','p_awr','delta_pp','delta_ci95_low_pp','delta_ci95_high_pp','short_adv_q10','short_adv_median','short_adv_q90','nonshort_adv_q10','nonshort_adv_median','nonshort_adv_q90','short_cap_fraction','nonshort_cap_fraction']
            outrows.append({**{k:r[k] for k in keys},'supported_query_coverage':cr['query_share']})
with (ROOT/'primary_distance_horizon_table.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(outrows[0]));w.writeheader();w.writerows(outrows)

body=[]
add=body.append
add('# 冻结 v0：岔口首次出口的 high-loss 加权审计\n\n2026-11-04 · v0 H4/L2/M3 · 1,000,000 步 checkpoint · β=3 · held-out 验证轨迹\n')
add('本次只回答：**在同岔口、同来向、同 goal 格，且数据确实提供两类路线的情形中，v0 的权重把多少监督份额转向几何较短出口？** 全过程没有重训，没有运行模拟器，也没有把地图输入 agent。地图仅用于离线归类。\n')
add('## 1. 先看覆盖：哪些情形真正可以比较\n')
add('原始验证集含 **100,050 个状态、50 条原始 episode、427 次物理岔口访问**。使用原 v0 采样器无条件抽取 **1,048,576 条查询** 后，筛出 **196,876 条岔口核心区查询**；10 个三岔口和 427 次访问都被抽到。已知来向与实际首选出口、且 goal 不在本岔口格的基础查询共 **94,551 条**。其中 50 步标签前已经离开且尚未返回的查询为 **76,143 条**，来自 411 次访问、48 个 episode。\n')
coverage_table=[]
for db in [1,2,3,'all']:
    cr=cov(db);rr=row(db=db);den=sum(r['queries'] for r in cr)
    coverage_table.append([DB[db] if db!='all' else '全部距离',f'{den:,}']+[pct(r['query_share']) for r in cr]+[rr['groups'],rr['physical_visits'],rr['episodes']])
add(table(['到 goal 的 BFS 距离','该层查询数','仅一个出口','多出口但同类','两类都有但支持不足','达到支持门槛','支持组数','支持组独立访问','支持组 episode'],coverage_table)+'\n')
add('“达到支持门槛”要求**较短出口与非较短出口两类，各至少 5 次不同物理访问、各至少 3 个原始 episode**。所有比例均以该距离层的同一批首次选路查询为分母；前四类覆盖相加为 100%。严格主分组为“岔口 × 来向 × goal 所在格”。未达到门槛的组仍保存在完整表中，不进入主效果估计。\n')
cr=cov('all')
add(table(['覆盖类别','组数','查询数','不同物理访问（占全部 427 次）','episode'],[[CN[r['category']],r['groups'],f"{r['queries']:,}",f"{r['physical_visits']}（{r['physical_visits']/427:.2%}）",r['episodes']] for r in cr])+'\n')
add('**同一次物理访问可以匹配多个 relabel goal，从而进入多个组、距离层或覆盖类别。因此独立访问数及其比例不能跨行相加。** 查询比例可相加；查询数不是独立选路次数。主结果只有 **12 组、91 次访问、37 个 episode、2/10 个岔口、3,080 条查询**；仅占 50 步首次选路查询的 **4.05%**。\n')
add('![10 个岔口的物理覆盖](figures/junction_coverage_map.png)\n')
add('## 2. 主结果：50 步的权重份额确有纠偏，但覆盖范围有限\n')
add(table(['距离','支持组 / 访问 / episode','未加权 p_raw','加权 p_AWR','Δ（百分点）','95% episode bootstrap 区间'],[[DB[db],f"{row(db=db)['groups']} / {row(db=db)['physical_visits']} / {row(db=db)['episodes']}",pct(row(db=db)['p_raw']),pct(row(db=db)['p_awr']),delta(row(db=db)['delta_pp']),ci(row(db=db))] for db in ['all',1,2,3]])+'\n')
add('在这 **12 个达到门槛的组**内，短路样本份额 **77.40% → 98.31%，增加 +20.91 个百分点**，区间 **[+9.04, +33.72]**。12 组的点估计都为正。这个结果说明固定 v0 critic 的权重在已覆盖的情形下能显著重新分配监督份额；**不能解释为 high actor 的短路选择概率提升了 20.91 个百分点，也不是导航成功率的增幅。**\n')
add('这里的“较短”指实际首次出口落在一条格图 BFS 最短路上；原路掉头允许为正确选项，并列最短出口全部算正确。它不等同于考虑速度、转向、碰撞及执行难度后的动力学最短路径。分组只固定来向和 goal 格，没有把完整起始姿态、速度与完整 goal observation 匹配成相同状态，所以这是数据加权审计，而不是动作干预的因果实验。\n')
add('![覆盖与分距离、分跨度的主效果](figures/coverage_and_delta.png)\n')
add('### 按距离 × 跨度展开（严格分组、达到支持门槛）\n')
for view,title in [('first_exit','首次选路版：标签前已出岔口，且尚未返回'),('supervision','实际监督版：标签前已出岔口，允许之后返回和截短')]:
    add('**'+title+'**\n')
    rows=[]
    for db in [1,2,3]:
        for h in [50,100,150]:
            r=row(view,h,db);cr=next(x for x in cov(db,view,h) if x['category']=='mixed_supported')
            rows.append([DB[db],h,f"{r['groups']} / {r['physical_visits']} / {r['episodes']}",pct(cr['query_share']),pct(r['p_raw']),pct(r['p_awr']),delta(r['delta_pp']),ci(r)])
    add(table(['距离','h','组 / 访问 / episode','支持查询覆盖率','p_raw','p_AWR','Δ（百分点）','95% 区间'],rows)+'\n')
add('上面不同 h 的样本和支持组会变化。不能把逐列变化直接解释为同一批决策的跨度效应。完整表同时保留两类 advantage 的分位数、均值、权重触顶率、近 1 权重比例和查询权重 ESS，见 [主表 CSV](primary_distance_horizon_table.csv) 与 [完整长表](delta_tables.csv)。ESS 仅描述查询层面的权重集中程度，不是独立访问数。\n')
add('## 3. 小增益来自什么：当前中距离例子是触顶，不是近零 advantage\n')
statrows=[]
for db in [1,2]:
    r=row(db=db)
    for label,key in [('较短出口','short'),('非较短出口','nonshort')]:
        statrows.append([DB[db],label,r[key+'_n'],f"{r[key+'_visits']} / {r[key+'_episodes']}",f"{r[key+'_adv_q10']:.3f} / {r[key+'_adv_median']:.3f} / {r[key+'_adv_q90']:.3f}",f"{r[key+'_weight_mean']:.3f}",pct(r[key+'_cap_fraction']),pct(r[key+'_weight_near_one_fraction'])])
add(table(['距离','首次出口','查询数','独立访问 / episode','A 的 P10 / 中位 / P90','平均 w','触顶率','w ∈ [0.9,1.1]'],statrows)+'\n')
add('β=3、上限 100 时，只要 **A ≥ ln(100)/3 ≈ 1.535** 就触顶。近场短路 A 的中位数为 **17.07**，非短路为 **−10.23**，能形成明显区分。中距离唯一支持组两类 A 的中位数分别为 **4.95 和 2.43**，两类权重触顶率分别为 **100% 和 76.92%**，平均权重约 **100 和 85.85**。因此这一个组的小增益符合“截断饱和压平差异”，不符合“两类 value 变化都接近零、权重都接近 1”的解释。不能据此概括所有中距离。\n')
add('![Advantage 分布与权重触顶](figures/advantage_and_saturation.png)\n')
add('## 4. 把首次选路、后续返回与标签截短分开\n')
add('以下以同一基础集合 **94,551 条查询**为分母，先报告状态及其权重份额。这是原始权重总量统计，不是组内标准化后的 Δ。到标签时仍未出岔口的查询不把后来才发生的出口选择归给当前标签。\n')
sn={'not_yet_departed':'尚未出岔口','departed_no_return':'已出且尚未返回','returned':'已经返回过岔口'}
add(table(['h','标签时状态','查询数','查询占比','权重份额','其中截短占比'],[[r['horizon'],sn[r['category']],f"{r['queries']:,}",pct(r['query_fraction']),pct(r['weight_fraction']),pct(r['clipped_fraction'])] for r in S if r['distance_bin']=='all'])+'\n')
add('三个标签都未截短、都已经出岔口的共同样本上，重新固定样本和分组计算：\n')
rows=[]
for view,label in [('first_exit_common','150 步前始终未返回'),('supervision_common','允许后续返回')]:
    for h in [50,100,150]:
        r=row(view,h);rows.append([label,h,f"{r['groups']} / {r['queries']} / {r['physical_visits']} / {r['episodes']}",pct(r['p_raw']),pct(r['p_awr']),delta(r['delta_pp']),ci(r)])
add(table(['共同样本口径','h','组 / 查询 / 访问 / episode','p_raw','p_AWR','Δ（百分点）','95% 区间'],rows)+'\n')
add('**始终未返回的同一批样本**，三段 Δ 为 **+27.29 / +27.73 / +25.50**；**允许后续返回的另一批共同样本**，为 **+28.28 / +22.38 / +19.85**。这与后段标签可能包含后续纠错进展相容，但两批共同样本不同，因此二者的差值不能当作折返的因果效应。更不能仅凭长跨度总体 Δ 变小就认定 critic 把第一次出口排错。\n')
add('![共同样本上的跨度变化](figures/common_sample_horizons.png)\n')
add('## 5. 远场不能下结论；一个中距离长跨度组值得后续验证\n')
ceil=load('support_ceiling')
add(table(['分组','距离','可能的混合组','最多可达到门槛的组'],[['严格同格' if r['grouping']=='strict' else '同出口集合相邻 goal 合并',DB[r['distance_bin']],r['mixed_groups_possible'],r['supported_groups_possible']] for r in ceil['summary']])+'\n')
add('支持上界额外枚举了**同一批验证轨迹**中所有可由原采样器生成、且满足 50 步首次选路口径的“核心区起点—未来 goal”配对。它只计算可用的独立访问上界，没有给主估计添加任何人工平衡样本。严格远场及相邻 goal 合并后的远场，达到门槛的组仍为 **0**。这也通过逐起点、逐未来索引的独立布尔枚举复核。**继续增加同一批轨迹的 relabel 次数，不能补足远场所需的独立物理路线。** 近中场还有少数可能达到支持门槛但本轮未充分抽中的组，亦不应把“本轮没有支持”解释成绝对没有路线。\n')
add('所以目前不能回答“远场加权是否无效、是否因 value 压缩而无效”。所有支持不足的混合组仍有探索性统计，保存在完整长表的 `all_mixed_exploratory` 行；它们不能替代支持门槛内的主结论。\n')
neg=next(r for r in G if r['grouping']=='strict' and r['view']=='first_exit' and r['horizon']==150 and r['category']=='mixed_supported' and r.get('negative_after_every_episode_drop'))
add(f"唯一值得单独标记的严格组是 **岔口 {neg['junction_cell']}、来向 {neg['incoming_cell']}、goal 格 {neg['goal_cell']}**（零起点的行、列坐标），有 **{neg['physical_visits']} 次访问、{neg['episodes']} 个 episode**。其 50/100/150 步 Δ 为 **+1.63 / +0.52 / −1.39** 个百分点。150 步已在“尚未返回”版本出现负值，且去掉任一单个 episode 后仍为负（范围 **{neg['leave_one_episode_delta_min_pp']:.2f} 至 {neg['leave_one_episode_delta_max_pp']:.2f}**）。但区间 **[−26.49, 0.00]** 仍宽且包含零；同一几何分组内的完整状态也未匹配。它是下一阶段动力学验证的候选，尚不足以证明 critic 错排了动力学成本。多个视图及 goal 合并中出现的记录都是这个候选的重复口径，不是多个独立发现。\n")
add('下一步如果开展验证，优先在这一组匹配完整仿真起始状态、强制不同出口再交回同一 v0 策略，分别测出口是否能执行到、最终成功率和相同预算下的耗时。**本次没有执行此阶段。** 本轮结果也不支持直接放弃 v0 critic：已覆盖的近场权重有明显短路偏好；其余问题需要区分数据覆盖、饱和和决策执行是否落实了这种偏好。\n')
add('## 6. 计算口径与复核\n')
add('采样先于筛选；使用冻结 v0 `MultiHGCDataset`，种子 20261104、每批 16,384、共 1,048,576 条。保持原配置的未来 goal 分布（`actor_geom_sample=False`、`actor_p_randomgoal=0`），没有平衡三个出口。每条查询保留原始起点、完整 goal observation 的实际索引、三个真实标签索引和有效 episode 末端。这里分析的是验证数据的 relabel goal 分布，不是 Task 1–5 固定测试目标的成功率。\n')
add('物理访问由同一原始 episode 的“稳定格内核心区命中序列”确定。格宽 4，核心区为中心 XY 各 ±1.6；仅边界抖动不计为换格。前一个相邻核心格是来向，下一个相邻核心格是首次出口；再次进入同岔口核心区记返回。不额外设置连续驻留帧阈值。相邻核心格若被跳过会标为歧义，本数据没有此类歧义。原始终止标记用于识别真实 episode；采样器 compact 格式使用的末端实际比原始最后状态早一帧，保留原实现而不擅自修正标签。\n')
add('查询级基础排除中，未知来向有 1,600 条（7 次访问）；未知出口有 81,458 条（9 次 episode 末端访问）；goal 位于本岔口格有 100,752 条。这些条件相互重叠，不能直接相加；末端长时间停留能产生很多重复查询，所以仍坚持按物理访问报告独立支持。所有排除样本仍保存在原始查询数组中。\n')
add('冻结 checkpoint 的当前两个 value head 取均值，完整 state 和 goal 输入保持不变。三个标签按实际采样器索引取值；保存顺序为近到远 50/100/150，模型原训练储存顺序则为远到近。对每个跨度独立计算累计差值：\n\n```text\nA_h = mean_head V(s_h, g) − mean_head V(s_0, g)\nw_h = min(100, exp(3 A_h))\nY = 1{D(first_exit, goal_cell) = D(junction, goal_cell) − 1}\np_raw(group) = sum(Y) / n\np_AWR(group) = sum(w_h × Y) / sum(w_h)\nΔ(group) = p_AWR(group) − p_raw(group)\n汇总：对二者使用同一组权重 α_group = n_group / sum(n_group)\n报告百分点：100 × sum[α_group × Δ(group)]\n```\n')
add('没有替换为相邻段 advantage，也没有把不同组直接用权重总和混起来。同一跨度的 high-loss 位置系数在组内占比中抵消。权重采用原模型的 `stable_awr`，浮点触顶值可能为 100.0000076，触顶判断容许这一舍入误差。\n')
add('置信区间按 50 条原始 episode 整体有放回抽样 2,000 次。每次把同一 episode 的所有重复查询、不同 relabel goal、访问一起带入；同一套 bootstrap 计数用于所有表。支持组集合依据原样本固定，不在每次重采样中重新筛选；重采样中缺失或零权重的组在 raw/AWR 两侧一致去掉。query-frequency 汇总按重采样后的 n 取组权重；等组权重版本在出现的组间重新归一化。区间仅描述固定模型及该 held-out 数据下的 episode 抽样不确定性，不覆盖训练 seed 或换地图的变化。\n')
sens=[]
for grouping,weighting,label in [('strict','sampler_query_frequency','严格同格，查询频率混合（主）'),('strict','equal_group','严格同格，组等权'),('same_exit_region','sampler_query_frequency','相邻 goal 合并，查询频率混合'),('same_exit_region','equal_group','相邻 goal 合并，组等权')]:
    r=row(grouping=grouping,weighting=weighting);sens.append([label,r['groups'],pct(r['p_raw']),pct(r['p_awr']),delta(r['delta_pp']),ci(r)])
add(table(['50 步敏感性口径','组数','p_raw','p_AWR','Δ（百分点）','95% 区间'],sens)+'\n')
add('相邻 goal 合并仅限空间相连、最短出口集合完全一致、距离层也相同的格。critic 始终接收每条样本本来的完整 goal observation，不使用 goal 格中心替代输入。\n')
v=load('reference_validation');verify=load('verification')
add(f"旧 2,048 条冻结查询的起点、goal、目标索引及近远顺序全部对齐；初始/未来 value 与 advantage 的最大绝对误差均为 0，权重误差为 **{v['weight_max_abs_error']:.3g}**；与原 agent 的 `high_advantages` 差异最大 **{v['training_advantage_max_abs_error']:.3g}**，属于浮点计算批次差异。另通过 **{verify['check_count']} 项独立输出检查**，包括全部支持组从查询数组重新计算、完整物理支持上界的逐配对枚举、索引不跨原始 episode、分类占比和权重份额守恒。事件与加权单元测试 7 项全部通过。\n")
add('## 7. 文件、原材料与离线复核\n')
add('本文件夹带有这次审计所需的**原始验证集、唯一被分析的 100 万步 checkpoint、冻结 v0 源码、原 2,048 条探针和所有查询索引/分数**。阅读 `report.html` 或 Markdown 和图片不需要网络；没有 CDN、外部图片或符号链接。复算需要兼容 Python 依赖，精确版本见 `environment.json`。无需复制完整训练集或其他运行的 checkpoint。\n')
add(table(['文件','内容'],[
['[report.html](report.html) / [README.md](README.md)','离线静态报告'],
['[primary_distance_horizon_table.csv](primary_distance_horizon_table.csv)','首次选路与实际监督的距离 × h 主表，含两类 advantage 分布和触顶率'],
['[coverage_by_view.csv](coverage_by_view.csv) / [coverage_base.csv](coverage_base.csv)','保留所有覆盖类别；前者按标签可归因口径筛选，后者未筛标签时点'],
['[delta_tables.csv](delta_tables.csv)','全部视图、距离、支持层级和组混合方式'],
['[group_results.csv](group_results.csv)','逐组结果、两类支持量、leave-one-episode 诊断'],
['[label_status_mass.csv](label_status_mass.csv)','尚未离开、未返回、已返回的查询与权重份额'],
['[physical_visits.csv](physical_visits.csv)','427 次物理访问：来向、首次出口、首次返回、原始 episode 边界'],
['[junction_queries.npz](junction_queries.npz)','196,876 条查询及真实索引、事件标签、value、advantage、weight；不只保留支持组'],
['[unfiltered_sample_indices.npz](unfiltered_sample_indices.npz)','筛选前的 1,048,576 条原采样器查询索引'],
['[frame_event_index.npz](frame_event_index.npz) / [geometry.json](geometry.json)','原始帧到事件映射、地图、全部岔口、goal 合并规则'],
['[support_ceiling.json](support_ceiling.json)','同批物理轨迹的可达支持上界'],
['[protocol.json](protocol.json)','结果计算前固定的协议及原材料 SHA-256；绝对路径仅作来源记录'],
['[verification.json](verification.json) / [portable_replay_validation.json](portable_replay_validation.json)','独立检查与仅从包内原材料重放的结果'],
['[inputs/antmaze-giant-navigate-v0-val.npz](inputs/antmaze-giant-navigate-v0-val.npz)','原始 held-out 验证集'],
['[inputs/params_1000000.pkl](inputs/params_1000000.pkl)','冻结 v0 H4/L2/M3 checkpoint'],
['inputs/frozen_v0_source/ / inputs/historical_reference/','完整冻结源码及历史探针'],
['analysis_code/ / logs/ / figures/','分析脚本、原始运行日志、PNG 与 SVG 图'],
['[MANIFEST.sha256](MANIFEST.sha256)','本文件夹的文件完整性校验表（不包含自身）']])+'\n')
add('从复制后的任意目录执行（无需原机器 `/data` 路径）：\n\n```bash\npython analysis_code/verify_outputs.py\npython -m unittest discover -s analysis_code -p test_audit_core.py -v\npython analysis_code/replay_frozen_queries.py --full\npython analysis_code/aggregate.py\npython analysis_code/build_report.py\n```\n\n`replay_frozen_queries.py` 使用包内原材料复核所有抽样索引，并重新评估每条岔口查询；不会训练或启动模拟器。`aggregate.py` 从已冻结的查询重算统计；`build_report.py` 重建图表。`run_queries.py` 保留最初执行的原始来源路径且拒绝覆盖已存在协议，作为来源记录使用，不是便携重放入口。重建输出后会更新文件时间或内容，完整性校验表对应本次交付版本。\n')
md='\n'.join(body)
(ROOT/'README.md').write_text(md)
renderer=MarkdownIt('commonmark',{'html':False}).enable('table')
content=renderer.render(md)
css='''body{margin:0;background:#edf1f5;color:#203344;font:16px/1.75 system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif}main{max-width:1150px;margin:32px auto;padding:36px 48px;background:white;border-radius:12px}h1{font-size:29px;line-height:1.4;color:#123e4a}h2{font-size:23px;margin-top:48px;border-top:1px solid #dce4ea;padding-top:24px}h3{font-size:19px;margin-top:28px}a{color:#126c87}img{max-width:100%;height:auto;margin:16px 0}table{border-collapse:collapse;display:block;overflow-x:auto;width:100%;font-size:13px;margin:20px 0}th,td{padding:9px 11px;border-bottom:1px solid #dce4ea;white-space:nowrap;text-align:left}th{background:#eaf3f3}tbody tr:nth-child(even){background:#f7f9fb}pre{padding:18px;background:#f1f5f8;overflow-x:auto;border-radius:8px}code{font-size:.9em}strong{color:#175d62}@media(max-width:800px){main{margin:0;padding:22px}h1{font-size:25px}}@media print{main{padding:0;margin:0;max-width:none}body{background:white}h2{break-before:auto}img,table{break-inside:avoid}}'''
(ROOT/'report.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>冻结 v0 岔口加权审计</title><style>'+css+'</style></head><body><main>'+content+'</main></body></html>')
print('Wrote README.md, report.html, primary CSV and four PNG/SVG figure pairs.')
