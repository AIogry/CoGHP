"""Geometry-only attainable physical-support ceiling; never changes sample estimates."""
from pathlib import Path
from collections import defaultdict
import csv,json,numpy as np
ROOT=Path(__file__).resolve().parents[1];q=np.load(ROOT/'junction_queries.npz');f=np.load(ROOT/'frame_event_index.npz');g=json.loads((ROOT/'geometry.json').read_text());grid=np.array(g['grid']);nc=grid.shape[1]
from audit_core import geometry,goal_regions,distance_bin
free,adj,D,js=geometry(grid);regions,_=goal_regions(js,adj,D,free)
events=[{k:int(v) if k not in ('incoming_status','exit_status') else v for k,v in row.items()} for row in csv.DictReader((ROOT/'physical_visits.csv').open())]
records={mode:defaultdict(lambda:[set(),set(),set(),set()]) for mode in ['strict','same_exit_region']}
considered=0
for e in events:
 if e['incoming']<0 or e['first_exit']<0:continue
 vi=e['visit_id'];J=e['junction'];exit_idx=e['first_exit_idx'];ret=e['first_return_idx'];end=e['raw_episode_end']-1
 starts=np.flatnonzero(f['visit_id']==vi);starts=starts[starts<=end]
 starts=starts[starts+50>=exit_idx]
 if len(starts)==0:continue
 # If any valid sampled core frame's full50-step label precedes return, all
 # future goal states after exit are feasible. Otherwise goal itself must
 # appear before return, so that clipping keeps the label before return.
 no_return_window=np.any((starts+50<ret)) if ret>=0 else True
 upper=end if no_return_window else min(end,ret-1)
 if upper<exit_idx:continue
 goals=np.unique(f['raw_cell'][exit_idx:upper+1]);considered+=1
 pairs={mode:set() for mode in records}
 for gc in goals:
  gc=int(gc)
  if gc==J:continue
  Y=int(D[e['first_exit'],gc]==D[J,gc]-1);db=int(distance_bin(D[J,gc]))
  pairs['strict'].add((J,e['incoming'],gc,db,Y));pairs['same_exit_region'].add((J,e['incoming'],int(regions[J,gc]),db,Y))
 for mode,ps in pairs.items():
  for J,inc,gk,db,Y in ps:
   key=(J,inc,gk,db);record=records[mode][key];record[Y].add(vi);record[2+Y].add(e['episode_id'])
rows=[]
for mode,groups in records.items():
 for key,rec in groups.items():
  J,inc,gk,db=key;ns,nl=len(rec[1]),len(rec[0]);es,el=len(rec[3]),len(rec[2]);rows.append({'grouping':mode,'junction':J,'incoming':inc,'goal_key':gk,'distance_bin':db,'short_visits_ceiling':ns,'nonshort_visits_ceiling':nl,'short_episodes_ceiling':es,'nonshort_episodes_ceiling':el,'supported_possible':min(ns,nl)>=5 and min(es,el)>=3})
summary=[]
for mode in records:
 for db in [1,2,3]:
  rr=[x for x in rows if x['grouping']==mode and x['distance_bin']==db];summary.append({'grouping':mode,'distance_bin':db,'potential_groups':len(rr),'mixed_groups_possible':sum(x['short_visits_ceiling']>0 and x['nonshort_visits_ceiling']>0 for x in rr),'supported_groups_possible':sum(x['supported_possible'] for x in rr)})
result={'description':'Exhaustive possible first-exit50 physical support in the same held-out episodes, over all sampler-supported future goal indices. No new queries/weights added to estimates. Distinct visits still counted once per group.','eligible_physical_visits':considered,'summary':summary,'groups':rows}
(ROOT/'support_ceiling.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary))
