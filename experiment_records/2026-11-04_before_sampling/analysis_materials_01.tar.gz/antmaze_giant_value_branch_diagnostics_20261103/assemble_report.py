from pathlib import Path
from datetime import datetime,timezone
import json,html,hashlib
root=Path(__file__).resolve().parent
value=json.loads((root/'value/summary.json').read_text());aggregate=json.loads((root/'value/aggregate_metrics.json').read_text());branch=json.loads((root/'branch/summary.json').read_text())
def table(headers,rows):
 return '<div class="tablewrap"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
metric_rows=[]
for name in value['model_order']:
 d=aggregate[name]['validation_upright_cell_median'];metric_rows.append([name,f"{d['spearman_to_negative_bfs']:.3f}",f"{100*d['neighbor_correct_fraction']:.1f}%",d['peaks_prominence_at_least_1_total']])
rows=[]
for case,version in [('v0_task5_ep1_t546','v0'),('v2_task5_ep3_t115','v2')]:
 vals=[]
 for arm in ['native','projected_refresh','hold10','hold25','hold50']:
  d=next(x for x in branch['comparisons'] if x['case']==case and x['version']==version and x['arm']==arm)
  vals.append(f"成功，{d['steps']}步" if d['success'] else f"剩{d['end_distance_cells']}格")
 rows.append([case,*vals])
pairedfile=root/'value/paired_path_value_checks.json';paired=json.loads(pairedfile.read_text()) if pairedfile.exists() else None
paired_html=''
if paired is not None:
 paired_rows=[]
 for case in ['v0_task5_ep1_t546','v2_task5_ep3_t115']:
  for mode,label in [('actual','实际完整state'),('fixedfork','固定fork非XY')]:
   paired_rows.append([case,label,*[f"{paired['cases'][case]['results'][v][mode]['spearman_to_negative_bfs']:.3f}" for v in ['v0','v1','v2']]])
 paired_html='<h3>同一输入轨迹，交给三代critic评价</h3><p><strong>三代critic在第二条路径上都出现反向几何排序。</strong>固定非XY分量后结论不变，因此不能把它说成v2独有的critic退化。第一条路径在三代critic下整体为正相关。两条都是特定区域的相关时间样本，不是独立统计检验，也不能把BFS当作最优动力学价值真值。</p>'+table(['固定轨迹','状态条件','v0 critic','v1 critic','v2 critic'],paired_rows)+'<p>原始配对查询和checkpoint哈希：<a href="value/paired_path_value_checks.json">paired_path_value_checks.json</a>。</p>'

allrows=[]
for d in branch['comparisons']:
 allrows.append([d['case'],d['version'],d['arm'],d['steps'],d['end_distance_cells'],d['max_regression_cells'],'是' if d['success'] else '否',f"{100*d.get('upright_fraction',0):.1f}%"])
locals=[]
for v in ['v0','v1','v2']:
 rs=[x for x in branch['local_target_results'] if x['version']==v];locals.append([v,f"{sum(x['local_reached'] for x in rs)}/{len(rs)}",', '.join(f"{x['minimum_local_distance']:.2f}" for x in rs)])
source_checks=[]
for name,x in branch['case_details'].items():
 checks=x['verification'];source_checks.append([name,checks['original_max_xy_error'],checks['restored_replay_max_xy_error'],checks['verified_steps']])
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CoGHP：Value地图与岔路口诊断</title>
<style>body{font:16px/1.7 system-ui,sans-serif;color:#213044;background:#fff;max-width:1320px;padding:28px;margin:auto}h1,h2,h3{line-height:1.35}h2{margin-top:38px}a{color:#225d98}img{display:block;width:100%;height:auto;margin:16px 0}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:9px 12px;border-bottom:1px solid #dbe2e9;text-align:left}th{background:#f1f4f8}.tablewrap{overflow:auto}.note{border-left:4px solid #32699d;padding:12px 18px;background:#f3f6fa}.controls{display:flex;gap:18px;flex-wrap:wrap;align-items:end;margin:14px 0}label{display:flex;flex-direction:column;gap:4px}select{font:inherit;padding:6px;max-width:100%}.small{font-size:14px;color:#47566b}details{margin:12px 0}code{background:#eff3f7;padding:2px 5px}nav{display:flex;gap:18px;flex-wrap:wrap}.download{font-size:14px}figure{margin:0}figcaption{font-size:14px;color:#47566b}</style>
<h1>Value 地图与岔路口诊断</h1><p>2026-11-03 · v0/v1/v2 · β=3 · seed0 · 冻结1M checkpoint。热图覆盖 M1/H2L1 与 M3/H4L2 的五个 task；分支诊断针对两个 Task5 事件，比较三个 M3 模型。无参数更新。</p>
<nav><a href="#value">五个 task 的 value 热图</a><a href="#branch">岔路口分支结果</a><a href="#local-value">具体路径的 value 排序</a><a href="#files">数据与复现</a></nav>
<p class="note"><strong>目前的主要判断：</strong>全局 value 空间结构仍然存在，v2没有随policy成功率一起整体塌陷。但这不足以保证岔路口局部排序正确；这次在v2折返路径所在区域发现了三代critic共有的逆向排序。短时保持目标可改善一个v0案例，在v2案例中主要改变来自投影接口，而非保持时长本身。</p>
<h2 id="value">1. Task 1–5：value 空间分布</h2>
<p>查询的是当前网络两头 value 的均值，和high/low AWR权重使用的V一致。每个task固定官方episode0的完整goal观测；每张图六个模型共享原始色阶。浅/亮色表示较高V，墙体被遮罩。点击图片可查看原始分辨率。</p>
<div class="controls"><label>Task<select id="task"><option value="1">Task 1</option><option value="2">Task 2</option><option value="3">Task 3</option><option value="4">Task 4</option><option value="5">Task 5</option></select></label><label>完整状态处理方式<select id="view"><option value="dense">固定初始姿态与速度，只替换XY</option><option value="upright">真实验证状态：直立子集格中位数</option><option value="validation">真实验证状态：全部样本格中位数</option><option value="iqr">全部验证状态：格内IQR</option><option value="heads">双头差异（未校准的不确定性代理）</option><option value="goalpose">相同goal XY下的目标姿态敏感性</option><option value="rank">各模型独立百分位（仅比较空间排序）</option></select></label></div>
<p id="view-description" class="small"></p><figure><a id="map-link" href="value/task_1_dense.png" target="_blank"><img id="map" src="value/task_1_dense.png" alt="Task1六组value地图"></a><figcaption id="map-caption"></figcaption></figure>
<p class="download">五个task固定姿态原图：<a href="value/task_1_dense.png">Task1</a> · <a href="value/task_2_dense.png">Task2</a> · <a href="value/task_3_dense.png">Task3</a> · <a href="value/task_4_dense.png">Task4</a> · <a href="value/task_5_dense.png">Task5</a></p>
<p>以下为五个task等权平均。BFS是四邻接maze几何距离，忽略朝向、速度、转向和动力学；相关性与邻格一致率不是critic真实准确率。局部峰只统计比最佳相邻格至少高1的峰，避免把远场饱和区的微小波动夸大为陷阱。</p>
'''+table(['模型','直立状态V与负BFS的Spearman','邻格几何方向一致率','五task局部峰总数（幅度≥1）'],metric_rows)+'''
<p>v1的M1/M3 value图相同是预期现象：该版本encoder仅由value loss更新，同seed与相同采样下critic不受actor循环结构影响。已逐数组核验两组value输出一致（忽略墙体遮罩NaN）。</p><p><strong>姿态混杂需要单独看。</strong>全部验证状态图中，一些格包含大量低趴、倾倒状态，较低value可能合理地反映执行困难。直立子集采用z≥0.4且body-up cosine≥0.5，从同一21389个验证状态保留18539个，86个通行格都有至少16个样本。它是描述性筛选，不是健康保证；完整原始图仍保留。</p>
<p><strong>到达goal的XY不等于完整goal状态。</strong>直接查询V(g,g)约为−0.033至−0.130；仅把初始身体状态平移到goal XY，value可低至−17.57。训练中的goal索引重合与环境的XY成功判据不同，不能把所有同XY负值都判为错误。</p>
<details><summary>查看姿态组成与覆盖</summary><img src="value/upright_coverage.png" alt="验证状态的高度及直立筛选覆盖"><img src="value/geometry_summary_upright.png" alt="六模型value几何统计"></details>
<h2 id="branch">2. 两个岔路口，42条配对分支诊断</h2>
<p>恢复完整MuJoCo积分状态、goal、随机状态与环境计时，再从同一起点执行不同干预。两处原生重放与原记录都完全一致；原模型和checkpoint未变。</p>
'''+table(['源起点','原记录重放最大XY误差','恢复后续跑最大XY误差','验证续跑步数'],source_checks)+'''
<p>主要对照：原生每步重规划；把每次预测分别投影到训练完整状态后每步刷新；同样投影后保持全部三个物理目标10/25/50步。保持期间每步重编码φ(s_t,y)，不固定latent数值。每臂最多350步且不超过原1000步剩余预算，目标已到达时没有提前刷新。</p>
<p>下表是源模型在自己源状态上的结果。数值为诊断结束后的剩余最短格距，成功则注明真实进入0.5XY容差的步数；它们不是正式task成功率。</p>
'''+table(['源起点 / 源模型','原生','投影每步刷新','保持10步','保持25步','保持50步'],rows)+'''
<p><strong>v0源案例：</strong>最初所选出口若不再回到岔路口，要绕较长路径；返回后的出口更短。因此后来的切换可以是在纠正最初选择。保持10/25步都在本次局部对照中到达真正goal，保持50步反而更差。hold50有28.57%的步数已经进入最近held目标0.5XY范围、仍未刷新。投影每步刷新臂还出现较多低姿态状态，因此不能把全部差异只归为抽象路线选择。</p>
<p><strong>v2源案例：</strong>最初出口是较短通路，后来换到的出口是必须折返的死胡同。投影每步刷新将净进展从0格提高到11格，hold10/25/50仅为9/5/5格；本例的主要改善来自command投影/接口改变，不能归功于保持计划。投影同时改变方向、模长、姿态编码等，尚未分离这些因素。</p>
<div class="controls"><label>分叉起点<select id="case"><option value="v0_task5_ep1_t546">v0源：Task5 / episode1 / t546</option><option value="v2_task5_ep3_t115">v2源：Task5 / episode3 / t115</option></select></label><label>诊断图<select id="branch-view"><option value="map">三模型×五种干预的路径</option><option value="timeline">value与几何进展时间线</option><option value="native_detail">源模型原生预测/动作细节</option></select></label></div>
<a id="branch-link" href="branch/v0_task5_ep1_t546_map.png" target="_blank"><img id="branch-map" src="branch/v0_task5_ep1_t546_map.png" alt="岔路口配对分支实验"></a>
<p>“数据支持目标”探针另外执行了12条，每条最多100步，三个command槽位都指向同一个选定出口上的训练完整状态，最终goal保持不变：</p>
'''+table(['模型','到达次数/4','各目标最近XY距离'],locals)+'''
<p>这些目标有训练数据与几何连通支持，未证明从该fork完整状态都能在100步内到达；三个槽位重复也改变了输入分布。因此它们提示局部接口问题，不能当成独立executor能力的严格上界。</p>
<h2 id="local-value">3. 全局结构正确，不保证当前岔路的局部排序正确</h2>
<p>两个源native轨迹均349/350步满足上述直立条件。v2源路径的V与负图距离Spearman为−0.835：在这个局部范围，更靠近目标的状态反而倾向于被打更低分。将非XY分量固定为fork状态或goal状态后，相关性仍为−0.890/−0.882，不能仅用动态姿态变化解释。v0源路径对应为+0.866/+0.804/+0.871。</p>
<p>固定姿态查询是函数切片，不保证每个混合状态动力学可实现；BFS也不是机器人时间最优真值。此外，当前policy推理没有在线读取V，所以这说明现有V在该处不适合未经检验地当作在线引导，而不是证明V直接触发了原生折返。</p>
<a href="branch/value_coordinate_slices.png" target="_blank"><img src="branch/value_coordinate_slices.png" alt="实际姿态与固定姿态下的value空间切片"></a>
'''+paired_html+'''
<details><summary>展开全部30条主干预结果</summary>'''+table(['源起点','模型','干预','步数','剩余格','最大回退格','真正成功','直立比例'],allrows)+'''</details>
<p class="note">下一步应区分两个待验证方向：局部value排序能否可靠比较候选路线，以及预测command如何与executor建立稳定接口。这次结果不支持直接把“少重规划”或“value单调增加”当作普适修复。两个事件是刻意挑选的机制诊断，不代表全任务或多seed统计。</p>
<h2 id="files">数据、方法与复现</h2><ul><li><a href="value/methodology.md">Value查询方法</a> · <a href="value/summary.json">逐task统计</a> · <a href="value/aggregate_metrics.json">汇总统计</a></li><li><a href="branch/report.html">分支实验完整报告</a> · <a href="branch/summary.json">42臂结构化结果</a> · <a href="branch/provenance.json">分支provenance</a></li><li>value目录包含全部原始双头输出、查询状态和取样索引；branch目录包含完整恢复状态及每臂JSON/NPZ。688候选先导单独保留，正式结果使用7692候选。</li><li>每个版本从自身冻结源码加载。模型参数与checkpoint哈希保持不变，GPU1仅用于value前向，分支仿真在CPU上完成。</li></ul>
<script>
const desc={dense:'合成切片：固定该task episode0初始完整姿态、关节和速度，只改变XY。不是实际机器人走遍地图，也未验证每个姿态与墙边兼容。',upright:'真实验证状态，描述性直立筛选：z≥0.4且body-up cosine≥0.5；每格取当前双头均值V的中位数。和主图共享原始色阶。',validation:'真实验证状态全部样本的格中位数，包含倒地、低姿态和格内位置组成差异，不能当纯几何value正确率。',iqr:'全部验证状态的格内IQR；混合XY、姿态、速度和动作阶段差异，不是统计置信区间。',heads:'两头V的绝对差；不是经过校准的不确定性，两头一致也可能共同出错。',goalpose:'固定goal XY，采用四个官方episode的goal非XY分量，显示格中位数的极差。',rank:'每个模型独立的value百分位；仅看空间排序，不能比较原始数值大小。'};
function showValue(){const t=document.getElementById('task').value,v=document.getElementById('view').value,url='value/task_'+t+'_'+v+'.png';document.getElementById('map').src=url;document.getElementById('map').alt='Task '+t+' 六模型 '+v+' value地图';document.getElementById('map-link').href=url;document.getElementById('view-description').textContent=desc[v];document.getElementById('map-caption').textContent='Task '+t+' · v0/v1/v2 × M1/M3 · 点击查看原图';}
function showBranch(){const c=document.getElementById('case').value,v=document.getElementById('branch-view').value,url='branch/'+c+'_'+v+'.png';document.getElementById('branch-map').src=url;document.getElementById('branch-link').href=url;}
for(const id of ['task','view'])document.getElementById(id).addEventListener('change',showValue);for(const id of ['case','branch-view'])document.getElementById(id).addEventListener('change',showBranch);showValue();showBranch();
</script></html>'''
(root/'report.html').write_text(page)
summary={'created_at':datetime.now(timezone.utc).isoformat(),'value_model_count':6,'task_count':5,'branch_forks':2,'branch_runs':42,'parameters_updated':False,'value_aggregate':aggregate,'source_native_comparison':rows,'paired_path_checks_available':paired is not None,'subreports':{'value':'value/summary.json','branch':'branch/summary.json'}}
(root/'combined_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(root/'report.html')
