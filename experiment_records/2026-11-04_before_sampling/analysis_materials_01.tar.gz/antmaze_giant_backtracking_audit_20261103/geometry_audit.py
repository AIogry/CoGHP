import os,sys,json
from pathlib import Path
from collections import deque
import numpy as np
sys.dont_write_bytecode=True
repo=Path('/home/eai/Research/CoGHP');root=repo/'impls/exp/antmaze_giant_backtracking_audit_20261103';atlas=root.parent/'antmaze_giant_map_atlas_20261103'
maze=json.loads((atlas/'maze.json').read_text());grid=np.asarray(maze['grid']);xy=np.asarray(maze['cell_xy']);cell=xy[0,1,0]-xy[0,0,0];R,C=grid.shape;N=R*C
free=np.flatnonzero(grid.ravel()==0);adj={}
for node in free:
 i,j=divmod(int(node),C);adj[int(node)]=[a*C+b for a,b in [(i-1,j),(i+1,j),(i,j-1),(i,j+1)] if 0<=a<R and 0<=b<C and grid[a,b]==0]
dist=np.full((N,N),-1,dtype=np.int16)
for s in free:
 dist[s,s]=0;q=deque([int(s)])
 while q:
  u=q.popleft()
  for v in adj[u]:
   if dist[s,v]<0:dist[s,v]=dist[s,u]+1;q.append(v)
def ids(points):
 ij=np.floor((np.asarray(points)[...,:2]-xy[0,0]+cell/2)/cell).astype(int)
 assert (ij[...,0]>=0).all() and (ij[...,0]<C).all() and (ij[...,1]>=0).all() and (ij[...,1]<R).all()
 a=ij[...,1]*C+ij[...,0];assert (grid.ravel()[a]==0).all();return a

def stable_walk(path):
 p=np.asarray(path);raw=ids(p);keep=[0];last=int(raw[0])
 for t in range(1,len(raw)):
  if raw[t]==last:continue
  center=xy[raw[t]//C,raw[t]%C]
  if np.max(np.abs(p[t]-center)) <= cell/2-.4:
   keep.append(t);last=int(raw[t])
 return raw[np.array(keep)],np.array(keep)

result={'protocol':'geometry-only diagnostic; graph distance ignores posture/dynamics; no training update','cell_width':float(cell),'task_shortest_cells':{},'datasets':{},'rollouts':{}}
for i,t in enumerate(maze['tasks'],1):result['task_shortest_cells'][str(i)]=int(dist[ids(t['init_xy']),ids(t['goal_xy'])])
# Actual sampling semantics, no curated visualization selection.
snapshot=root.parent/'antmaze_giant_v2_diagnosis_20261103/v2/snapshot';man=json.loads((snapshot/'campaign.json').read_text());source=Path(man['source_dir']);sys.path[:0]=[str(source/'impls'),str(source)]
from ogbench.utils import load_dataset
from utils.datasets import Dataset,MultiHGCDataset
cfg=json.loads((snapshot/'runs/hrm_beta30_h4l2_m3/flags.json').read_text())['agent'];cfg={k:tuple(v) if isinstance(v,list) else v for k,v in cfg.items()}
for split,suffix in [('train',''),('validation','-val')]:
 raw=load_dataset(man['datasets']['antmaze-giant-navigate-v0'+suffix+'.npz']['path'],compact_dataset=True);data=Dataset.create(**raw);batch=MultiHGCDataset(data,cfg,rng=np.random.default_rng(20261104)).sample(16384,evaluation=True)
 states=raw['observations'];cell_ids=ids(states);edge=dist[cell_ids[:-1],cell_ids[1:]].astype(np.int32);edge[np.asarray(raw['valids'][:-1])==0]=0;assert (edge>=0).all();prefix=np.r_[0,np.cumsum(edge)]
 start=batch['indices'];goal=batch['high_actor_goal_idxs'];targets=batch['high_actor_target_idxs'];direct=dist[cell_ids[start],cell_ids[goal]];walk=prefix[goal]-prefix[start];valid=direct>=2
 overhead=walk-direct
 record={'queries':len(start),'relabeled_goal_offset_median':float(np.median(goal-start)), 'goal_shortest_at_least_2cells_count':int(valid.sum()),'goal_conditioned_geometric_detour_ratio_median':float(np.median(walk[valid]/direct[valid])),'goal_conditioned_ratio_ge2_fraction':float(np.mean(walk[valid]>=2*direct[valid])),'goal_conditioned_ratio_ge2_and_excess_ge4_fraction':float(np.mean((walk[valid]>=2*direct[valid])&(overhead[valid]>=4))), 'horizons':{}}
 for j,horizon in enumerate([150,100,50]):
  d=dist[cell_ids[start],cell_ids[targets[:,j]]];l=prefix[targets[:,j]]-prefix[start];euclid=np.linalg.norm(states[start,:2]-states[targets[:,j],:2],axis=1);unclipped=(targets[:,j]-start)==horizon
  record['horizons'][str(horizon)]={'clipped_fraction':float(np.mean(~unclipped)),'shortest_cells_median':float(np.median(d[unclipped])),'shortest_cells_p90':float(np.quantile(d[unclipped],.9)),'net_xy_median':float(np.median(euclid[unclipped])),'local_excess_ge4_fraction':float(np.mean((l-d)[unclipped]>=4)),'unclipped_count':int(unclipped.sum())}
 result['datasets'][split]=record;print(split,record,flush=True)
# Quantify observed leave-and-return events with a 0.4-unit cell-core margin.
for version in ['v0','v1','v2']:
 d=json.loads((atlas/f'{version}_paths.json').read_text());records=[]
 for m,run in d['runs'].items():
  for task,group in run['tasks'].items():
   for ep in group['episodes']:
    path=np.asarray(ep['path_xy']);walk,times=stable_walk(path);goal=int(ids(ep['goal_xy']));short=int(dist[walk[0],goal]);travel=int(np.sum(dist[walk[:-1],walk[1:]]));remain=int(dist[walk[-1],goal]);distance=dist[walk,goal];events=[];visits={}
    for k,node in enumerate(walk):
     node=int(node)
     if len(adj[node])<3:continue
     if node in visits:
      a=visits[node];radius=int(np.max(dist[node,walk[a:k+1]]));duration=int(times[k]-times[a])
      if radius>=3 and duration>=50:
       old_branch=int(walk[a+1]) if a+1<len(walk) else None;new_branch=int(walk[k+1]) if k+1<len(walk) else None
       events.append({'junction_cell':[node//C,node%C],'depart_step':int(times[a]),'return_step':int(times[k]),'duration_steps':duration,'max_excursion_cells':radius,'old_first_cell':old_branch,'new_first_cell':new_branch,'changed_exit_after_return':old_branch!=new_branch if new_branch is not None else None})
     visits[node]=k
    records.append({'M':int(m),'task':int(task),'episode':ep['episode'],'success':ep['success'],'steps':ep['steps'],'shortest_start_goal_cells':short,'traversed_cells':travel,'remaining_cells':remain,'excess_cells':travel+remain-short,'max_regression_cells':int(np.max(distance-np.minimum.accumulate(distance))),'junction_return_events':events})
 result['rollouts'][version]=records
 print(version,'M3',{str(task):{'return_event_episodes':sum(bool(x['junction_return_events']) for x in records if x['M']==3 and x['task']==task),'events':sum(len(x['junction_return_events']) for x in records if x['M']==3 and x['task']==task)} for task in range(1,6)},flush=True)
# Full validation trace shown as the first task-5 paired case.
c=json.loads((atlas/'offline_cases.json').read_text())['cases'][24];raw=load_dataset(man['datasets']['antmaze-giant-navigate-v0-val.npz']['path'],compact_dataset=True)
a,b=c['index'],c['goal_index'];p=raw['observations'][a:b+1,:2];walk,t=stable_walk(p);short=int(dist[walk[0],walk[-1]]);travel=int(np.sum(dist[walk[:-1],walk[1:]]))
result['displayed_task5_case1']={'start_index':a,'goal_index':b,'duration':b-a,'shortest_cells':short,'traversed_cells':travel,'ratio':travel/max(short,1)}
(root/'geometry_audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Task5 case',result['displayed_task5_case1'],flush=True)
