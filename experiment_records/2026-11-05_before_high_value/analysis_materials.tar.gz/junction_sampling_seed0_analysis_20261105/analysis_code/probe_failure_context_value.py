"""Critic ranking of two actually executed futures from identical task5 starts."""
import sys
sys.dont_write_bytecode = True
import os,sys,json
from collections import deque
from pathlib import Path
os.environ.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
R=Path(__file__).resolve().parents[1];C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
sys.path[:0]=[str(C/'source/impls'),str(C/'source')]
import numpy as np
import jax,jax.numpy as jnp
from agents.navigation import NavigationAgent,stable_awr
from utils.flax_utils import restore_agent
ids=json.loads((R/'initial_command_rescue.json').read_text())['cases']
art=lambda mode:C/f'runs/{mode}_h4l2_m3/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts'
arrays={}
for mode in ['original','soft']:
 with np.load(art(mode)/'behavior/step_1000000/task_5.npz') as z:
  arrays[mode]={k:z[k] for k in ['observation','next_observation','goal','episode_offsets','action']}
def at(mode,i,h):
 z=arrays[mode];lo,hi=z['episode_offsets'][i:i+2]
 return z['observation'][lo] if h==0 else z['next_observation'][lo+h-1]
starts=np.stack([at('original',i,0) for i in ids]);goals=arrays['original']['goal'][ids]
futures={mode:np.stack([[at(mode,i,h) for h in [50,100,150]] for i in ids]) for mode in arrays}
result={'cases':ids,'checkpoint':1000000,'task':5,'interpretation':'Two actually executed futures at50/100/150 from the same full initial states and full goals. Original eventually succeeds, soft stays in initial cell. This critic comparison does not evaluate arbitrary generated latent plans or establish deployable test-time search.', 'models':{}}
for mode in arrays:
 flags=json.loads((art(mode)/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
 model=NavigationAgent.create(0,starts[:1],np.zeros((1,8),np.float32),cfg);agent=restore_agent(model,str(art(mode)),1000000,json.loads((art(mode)/'checkpoint_metadata.json').read_text()),True)
 @jax.jit
 def values(agent,x,g):return jnp.mean(agent.network.select('value')(x,g),axis=0)
 v0=np.asarray(values(agent,starts,goals));vf={k:np.stack([np.asarray(values(agent,x[:,h],goals)) for h in range(3)],axis=1) for k,x in futures.items()}
 rows=[]
 for j,h in enumerate([50,100,150]):
  diff=vf['original'][:,j]-vf['soft'][:,j]
  rows.append({'horizon':h,'reference_value_greater_count':int(np.sum(diff>1e-6)),'ties':int(np.sum(abs(diff)<=1e-6)),
               'value_difference_median':float(np.median(diff)),'value_difference_mean':float(diff.mean()),
               'reference_advantage_median':float(np.median(vf['original'][:,j]-v0)),
               'stall_advantage_median':float(np.median(vf['soft'][:,j]-v0)),
               'reference_weight_mean':float(np.asarray(stable_awr(vf['original'][:,j]-v0,3.,100.)).mean()),
               'stall_weight_mean':float(np.asarray(stable_awr(vf['soft'][:,j]-v0,3.,100.)).mean())})
 result['models'][mode]={'initial_value_median':float(np.median(v0)),'rows':rows,'initial_values':v0.tolist(),'reference_values':vf['original'].tolist(),'stall_values':vf['soft'].tolist()}
geo=json.loads((art('soft')/'junction_geometry.json').read_text())
adj={tuple(map(int,k.split(','))):[tuple(x) for x in v] for k,v in geo['adjacency'].items()}
def cell(x):return tuple(np.floor((x[:2]-geo['origin_xy'])/4+.5).astype(int)[::-1])
gc=cell(goals[0]);D={gc:0};queue=deque([gc])
while queue:
 x=queue.popleft()
 for y in adj[x]:
  if y not in D:D[y]=D[x]+1;queue.append(y)
result['geometric_context']=[]
for j,h in enumerate([50,100,150]):
 b=np.array([D[cell(x)] for x in futures['original'][:,j]]);s=np.array([D[cell(x)] for x in futures['soft'][:,j]])
 result['geometric_context'].append({'horizon':h,'reference_closer_count':int((b<s).sum()),'ties':int((b==s).sum()),'reference_farther_count':int((b>s).sum()),'reference_distance_median':float(np.median(b)),'stall_distance_median':float(np.median(s))})
(R/'failure_context_value.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['models'],indent=2))
