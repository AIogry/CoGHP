"""Frozen1M effective weight/output-gradient proxy of the actual sampling change."""
import sys
sys.dont_write_bytecode = True
import os,sys,json
from pathlib import Path
os.environ.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
ROOT=Path(__file__).resolve().parents[1]
C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
sys.path[:0]=[str(C/'source/impls'),str(C/'source')]
import numpy as np
import jax,jax.numpy as jnp
from agents.navigation import NavigationAgent,stable_awr
from utils.flax_utils import restore_agent
data=np.load('/data/qijunrong/06-RL/offline-rl/data/raw_ogbench/antmaze-giant-navigate-v0.npz');obs=data['observations'];actions=data['actions']
z=np.load(C/'preflight/sampling/preparation_queries.npz');changed=np.flatnonzero(z['replaced'])
pool=np.random.default_rng(2026110507).choice(len(z['original_start']),8192,replace=False)
query={
 'base':(z['original_start'][pool],z['original_goal'][pool],z['original_targets'][pool]),
 'removed':(z['original_start'][changed],z['original_goal'][changed],z['original_targets'][changed]),
 'added':(z['start_indices'][changed],z['goal_indices'][changed],z['target_indices'][changed])}
rate=990471/(1000000*256)
result={'checkpoint':1000000,'replacement_rate_from_actual_training':rate,'pool_samples':len(pool),'changed_queries':len(changed),
 'interpretation':'Frozen-final-model probe on training-query samples. Weight-share estimates use a random base pool plus paired replacements; not actual historical training-gradient reconstruction. Output-gradient proxy is a norm before the network Jacobian, not parameter gradient or optimizer update.', 'runs':{}}
def stats(x):return {'mean':float(x.mean()),'q10':float(np.quantile(x,.1)),'median':float(np.median(x)),'q90':float(np.quantile(x,.9))}
for snap in sorted((ROOT/'snapshot/runs').iterdir()):
 flags=json.loads((snap/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()};m=cfg['num_subgoals']
 art=Path(json.loads((snap/'run.json').read_text())['run_dir'])/'artifacts'
 model=NavigationAgent.create(0,obs[:1],actions[:1],cfg);agent=restore_agent(model,str(art),1000000,json.loads((snap/'checkpoint_metadata.json').read_text()),True)
 @jax.jit
 def forward(agent,s,g,t):
  v=agent.network.select('value');a=jnp.stack([jnp.mean(v(t[:,j],g),axis=0)-jnp.mean(v(s,g),axis=0) for j in range(m)],axis=1)
  w=stable_awr(a,3.,100.);label=agent.network.select('goal_rep')(jnp.concatenate([jnp.broadcast_to(s[:,None],t.shape),t],axis=-1))
  pred=agent.policy(s,g,jax.random.PRNGKey(19),temperature=0.,return_latents=True)[3]
  coeff=.8**jnp.arange(m-1,-1,-1)/(50*m)
  grad=w*jnp.linalg.norm(pred-label,axis=-1)*coeff
  mse=jnp.mean((pred-label)**2,axis=-1)
  return a,w,grad,mse
 records={};raw={}
 for label,(s,g,t) in query.items():
  vals=[[],[],[],[]]
  for lo in range(0,len(s),128):
   ii=np.arange(lo,min(lo+128,len(s)));n=len(ii);ii=np.pad(ii,(0,128-n),mode='edge')
   out=forward(agent,obs[s[ii]],obs[g[ii]],obs[t[ii,-m:]])
   for pieces,v in zip(vals,out):pieces.append(np.asarray(v)[:n])
  adv,w,grad,mse=[np.concatenate(v) for v in vals];raw[label]=(adv,w,grad,mse)
  records[label]={'waypoints':[{'offset':50*(m-j),'advantage':stats(adv[:,j]),'weight':stats(w[:,j]),'cap_fraction':float(np.mean(w[:,j]>=99.999)), 'mse':float(mse[:,j].mean()),'output_gradient_norm':float(grad[:,j].mean())} for j in range(m)],'output_gradient_proxy_sum':float(grad.sum(1).mean())}
 changes=[]
 for j in range(m):
  b=float(raw['base'][1][:,j].mean());old=float(raw['removed'][1][:,j].mean());new=float(raw['added'][1][:,j].mean());after=b+rate*(new-old)
  changes.append({'offset':50*(m-j),'removed_weight_share_of_base':rate*old/b,'added_weight_share_after_change':rate*new/after,'estimated_total_weight_change_fraction':rate*(new-old)/b})
 bg=records['base']['output_gradient_proxy_sum'];og=records['removed']['output_gradient_proxy_sum'];ng=records['added']['output_gradient_proxy_sum']
 result['runs'][snap.name]={'query_sets':records,'weight_mass_effect':changes,'added_output_gradient_proxy_share':rate*ng/(bg+rate*(ng-og))}
 np.savez_compressed(ROOT/(snap.name+'_intervention_probe.npz'),**{label+'_'+key:arr for label,arrays in raw.items() for key,arr in zip(['advantage','weight','output_gradient_norm','mse'],arrays)})
 (ROOT/'weighted_intervention.json').write_text(json.dumps(result,indent=2)+'\n')
 print(snap.name,json.dumps(result['runs'][snap.name]['weight_mass_effect']),flush=True)
 jax.clear_caches()
result['complete']=True;(ROOT/'weighted_intervention.json').write_text(json.dumps(result,indent=2)+'\n')
