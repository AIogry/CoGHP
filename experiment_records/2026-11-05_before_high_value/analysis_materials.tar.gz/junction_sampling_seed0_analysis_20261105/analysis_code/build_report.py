"""Scientific figures and evidence-graded Chinese report; local static assets."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import json,hashlib,csv,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.colors import ListedColormap
from markdown_it import MarkdownIt

R=Path(__file__).resolve().parents[1];F=R/'figures';F.mkdir(exist_ok=True)
C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
load=lambda n:json.loads((R/(n+'.json')).read_text())
pair=load('paired_results');tasks=load('task_results');curves=load('evaluation_curves');train=load('training_summary');local=load('local_goal_isolation');probe=load('checkpoint_probes');rescue=load('initial_command_rescue');wv=load('weighted_intervention');cv=load('failure_context_value');contexts=load('matched_context_results');fail=load('paired_failure_types');grad=load('gradient_controls');precise=load('gradient_controls_highest')
configs=['h2l1_m1','h2l1_m3','h4l1_m3','h4l2_m3'];names=['H2/L1/M1','H2/L1/M3','H4/L1/M3','H4/L2/M3'];colors={'original':'#2f6e9e','soft':'#ce7132'}
font=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if font.exists():plt.rcParams['font.family']=FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'savefig.dpi':170,'figure.facecolor':'white'})
def save(name):plt.savefig(F/(name+'.png'),bbox_inches='tight');plt.savefig(F/(name+'.svg'),bbox_inches='tight');plt.close()
def total(c):return next(r for r in pair if r['config']==c and r['step']=='all')
def table(h,rows):return '\n'.join(['| '+' | '.join(h)+' |','| '+' | '.join(['---']*len(h))+' |']+['| '+' | '.join(map(str,x))+' |' for x in rows])
pct=lambda x:f'{100*x:.2f}%'

fig,axes=plt.subplots(2,2,figsize=(12,8.3),sharex=True,sharey=True)
for ax,c,n in zip(axes.flat,configs,names):
 for mode in colors:
  a=[x for x in curves if x['method']==mode+'_'+c];ax.plot([x['step']/1e5 for x in a],[x['evaluation/overall_success']*100 for x in a],marker='o',ms=4,label='原采样' if mode=='original' else '软采样',color=colors[mode])
 ax.axvspan(8,10,color='#e8eff2',alpha=.6);ax.set_title(n+f"   预定末三点评分 Δ={total(c)['delta_pp']:+.2f} pp");ax.set_ylim(0,85);ax.set_xticks([1,3,5,7,8,9,10]);ax.grid(alpha=.15)
axes[0,0].legend(frameon=False);fig.supxlabel('训练步数（×100,000）');fig.supylabel('正式5任务平均成功率（%）');fig.suptitle('相同 seed0；每个评估点为每任务50个episode，灰区为预定评分区间',fontsize=12);fig.tight_layout(rect=(0,.02,1,.96));save('success_curves')

fig,axes=plt.subplots(1,3,figsize=(15,4.7));x=np.arange(4)
for ax,key,label,factor in zip(axes,['first_return_rate','never_left_start_cell','union_return_excursion_steps'],['首次岔口访问后返回比例（%）','始终未离开起始格（%）','返回区间并集耗时（步/episode）'],[100,100,1]):
 for mode,dx in [('original',-.18),('soft',.18)]:
  y=[total(c)[mode+'_'+key]*factor for c in configs];ax.bar(x+dx,y,width=.34,label='原采样' if mode=='original' else '软采样',color=colors[mode])
  for i,v in enumerate(y):ax.text(i+dx,v+.02*max(y),f'{v:.1f}',ha='center',va='bottom',fontsize=9)
 ax.set_xticks(x,names,rotation=22);ax.set_ylabel(label);ax.grid(axis='y',alpha=.15);ax.set_ylim(0,ax.get_ylim()[1]*1.15)
axes[0].legend(frameon=False);fig.suptitle('800k / 900k / 1M 实际轨迹：返回率须结合访问覆盖与停滞一起看',fontsize=13);fig.tight_layout(rect=(0,0,1,.94));save('behavior_changes')

fig,axes=plt.subplots(1,2,figsize=(12,4.7),sharey=True)
for ax,mode,title in zip(axes,['predicted','teacher'],['模型原生 planner + executor','给定真实局部目标的 executor']):
 for variant,dx in [('original',-.18),('soft',.18)]:
  y=[local['runs'][variant+'_'+c]['summary'][mode]['success_rate']*100 for c in configs];ax.bar(x+dx,y,width=.34,color=colors[variant],label='原采样' if variant=='original' else '软采样')
  for i,v in enumerate(y):ax.text(i+dx,v+1,f'{v:.1f}',ha='center',fontsize=9)
 ax.set_title(title);ax.set_xticks(x,names,rotation=20);ax.set_ylim(0,108);ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('局部目标到达率（%）');axes[0].legend(frameon=False,loc='lower right');fig.suptitle('64 个相同验证集完整起始状态，50步数据目标，最多执行100步；不是正式任务成功率',fontsize=12);fig.tight_layout(rect=(0,0,1,.94));save('local_control')

fig,ax=plt.subplots(figsize=(8.5,4.6))
for mode,dx,col,label in [('native_replay',-.18,'#b85555','原生 soft 回放'),('reference_prefix50',.18,'#208575','仅前50步使用物理参考 command')]:
 rr=[r for r in rescue['rows'] if r['mode']==mode];yy=[sum(x[k] for x in rr) for k in ['left_start_cell','success']];ax.bar(np.arange(2)+dx,yy,width=.34,color=col,label=label)
 for i,v in enumerate(yy):ax.text(i+dx,v+.3,f'{v}/19',ha='center')
ax.set_xticks([0,1],['离开起始格','最终到达 goal']);ax.set_ylim(0,22);ax.set_ylabel('案例数');ax.set_title('H4/L2/M3，Task5，1M：全部19个“原模型成功、新模型起点停滞”案例');ax.legend(frameon=False,loc='upper right',fontsize=9);save('prefix_rescue_counts')

# Show the first three eligible case IDs, not handpicked successful rescues.
art=lambda mode:C/f'runs/{mode}_h4l2_m3/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts'
geo=json.loads((art('soft')/'junction_geometry.json').read_text());grid=np.ones(geo['lattice_shape'])
for cell in geo['free_cells']:grid[tuple(cell)]=0
native={}
for mode in ['original','soft']:
 with np.load(art(mode)/'behavior/step_1000000/task_5.npz') as z:native[mode]={k:z[k] for k in ['observation','next_observation','goal','episode_offsets']}
with np.load(R/'initial_command_rescue_paths.npz') as z:rp={k:z[k] for k in z.files}
fig,axes=plt.subplots(1,3,figsize=(15,5.3))
for ax,i in zip(axes,rescue['cases'][:3]):
 ax.imshow(grid,origin='lower',extent=(-6,58,-6,42),cmap=ListedColormap(['#f5f7f8','#d5dce1']),vmin=0,vmax=1)
 for mode,label,col in [('original','原采样原生','#2f6e9e'),('soft','软采样原生','#b85555')]:
  z=native[mode];lo,hi=z['episode_offsets'][i:i+2];p=np.concatenate([z['observation'][lo:lo+1],z['next_observation'][lo:hi]])[:,:2];ax.plot(p[:,0],p[:,1],color=col,lw=1.3,alpha=.85,label=label)
 p=rp[f'reference_prefix50_{i}'][:,:2];ax.plot(p[:,0],p[:,1],color='#208575',lw=1.3,label='前50步参考干预');ax.scatter(*p[0],s=20,c='black');ax.scatter(*native['soft']['goal'][i,:2],marker='*',s=95,c='black')
 row=next(r for r in rescue['rows'] if r['mode']=='reference_prefix50' and r['episode']==i);ax.set_title(f"episode {i}：干预后{'成功' if row['success'] else '仍失败'}");ax.set(xlim=(-2,54),ylim=(-2,38),aspect='equal');ax.set_xlabel('X');ax.set_ylabel('Y')
axes[0].legend(frameon=False,fontsize=9,loc='upper left');fig.suptitle('按episode编号取前3个诊断案例；只改变初期command，剩余步骤仍用同一个soft模型',fontsize=12);fig.tight_layout(rect=(0,0,1,.93));save('prefix_rescue_routes')

b=[];add=b.append
add('# v0 高层软采样：seed0 结果与失效定位\n\n2026-11-05 · 8 个完成的 seed0 运行 · 无训练更新的后验诊断\n')
add('**当前结论：这轮改善了被替换示范的选路倾向，但没有形成跨结构稳定的闭环收益。H4/L1/M3 有正收益；H4/L2/M3 出现明显回归。最强的定位证据是：在部分官方远目标失败案例中，只改变最初的 planner command、保留同一 executor 与同一模型后续策略，就能解除停滞并恢复部分成功。** 这比“采样没用”或“executor坏了”的总括更符合数据。\n')
add('## 1. 暂停和分析范围\n\n已按用户要求用 SIGSTOP 暂停本 campaign 的 launcher 和两个 seed1 进程。最后已记录的训练步数分别为 H2/L1/M1 810k、H2/L1/M3 340k；尚未落盘的参数、优化器与 RNG 保留在进程内存。训练计算停止，但显存仍保留。此报告不把未完成 seed1 纳入效果比较，也没有重训或改变生产策略。暂停现场见 [pause_record.json](pause_record.json)。\n')
add('## 2. 首先核实结果，而不是先解释下降\n')
rows=[]
for c,n in zip(configs,names):
 r=total(c);rows.append([n,pct(r['original_success']),pct(r['soft_success']),f"{r['delta_pp']:+.2f}",f"[{r['ci95_pp'][0]:+.2f}, {r['ci95_pp'][1]:+.2f}]"])
add(table(['结构','原采样','软采样','差值（百分点）','配对episode bootstrap 95%区间'],rows)+'\n')
add('主分数仍为800k、900k、1M三个预定checkpoint的成功率均值。每个checkpoint是5任务×50 episodes，原/新模型的完整reset state、完整goal和episode seed逐一一致。bootstrap按任务内episode身份重采样，并把同一episode的三个checkpoint绑在一起；区间只反映固定seed0模型的评估不确定性，**不能代表跨训练seed的可靠性**。H2两组的小差值区间含零；H4两组变化更大且方向相反。\n')
add('四个新跑的original基线，其全部10个评估点、全部task及总体成功率与历史v0日志**逐项一致**。配对配置之间唯一不同的agent配置是 `high_sampling_probability: 0 → 0.5`。全程记录的训练指标有限。未发现本轮把v0实现、评估种子或low/value采样意外换掉的证据。\n')
add('### 新发现：首轮还缺一个“空干预双前向”控制\n\n为分开high与low的样本，本轮soft走了两次forward，original仍走原单forward。先前的冻结v0复现验证了**original路径**；小模型数据流测试验证了数学等价及low/value梯度隔离，尚未排除生产GPU下拆分计算图的数值影响。\n')
gr=[]
for c,n in [('h4l1_m3','H4/L1/M3'),('h4l2_m3','H4/L2/M3')]:
 rr=grad['models'][c];hh=precise['models'][c];changed=[x for x in rr if x['replacements']>0]
 gr.append([n,f"{100*np.median([x['sham_vs_single']['relative_difference'] for x in rr]):.4f}%",f"{100*np.median([x['real_vs_sham']['relative_difference'] for x in changed]):.2f}%",f"{100*np.median([x['sham_vs_single']['relative_difference'] for x in hh]):.6f}%"])
add(table(['1M冻结模型','默认GPU精度：空双前向相对单前向','发生替换的batch：真实替换相对空双前向','最高矩阵乘精度：空双前向相对单前向'],gr)+'\n')
add('默认精度使用实际seed0采样流的前16个batch，包含6个零替换batch；表中真实替换列仅汇总10个发生替换的batch。最高精度复核的是相同的前4个batch。差异定义为梯度差的L2范数除以参考总梯度范数；本检查没有优化器更新。\n\n**即使没有换任何样本，GPU总梯度也会轻微变化；提高矩阵乘精度后差异收缩到约0.0002%–0.0003%，支持计算图/数值精度因素。** 真实数据干预通常更大，不能据此说性能下降主要由数值差异造成；反过来，未跑空干预控制，也不能把全部最终变化确定归给采样语义。一次冻结梯度检查不估计百万步累积效果。\n\n这是首轮对照设计中遗漏的一项控制，需要明确补上。当前结果应理解为“局部采样改变在新high/low分离实现下的结果”，尚未完全剥离计算路径影响。正式精度配置没有在本次分析中修改。\n')
add('![成功率曲线](figures/success_curves.png)\n')
add('## 3. 新采样改善了什么，又只改动了多大范围\n')
add('四个soft运行各实际替换 **990,471 / 256,000,000 = 0.3869%** 的高层查询；每个5000步窗口的替换数量序列完全相同。平均每个256样本batch约换 **0.99 条**，所以结构间的差异不是某一组碰巧用了更多干预样本。\n')
add('独立的1,048,576条训练查询审计中，19,419条满足歧义触发条件，8,156条通过独立替代访问和时间bin门槛，实际替换4,056条。也就是全部触发查询中约 **20.9%** 被替换；保留原查询的情况仍占大多数。改动仅作用于岔口核心区、最近标签已离开且未返回、goal来自之后返回阶段、且存在其它episode替代出口的情形。岔口之前、其它非岔口状态和许多缺乏匹配支持的困难查询没有直接被修正。\n')
ig=load('intervention_geometry')
add(f"在这4,056对替换中，实际首出口属于BFS较短出口的比例从 **{ig['original_short_exit_fraction']:.2%} → {ig['donor_short_exit_fraction']:.2%}**。其中2,917对由非较短变为较短，169对相反。说明示范确实朝更直接的路线移动，但不是完全修复；非BFS最短也不能直接判错，采样本来就没有使用最短路筛选。\n")
add('保持的条件是“同岔口、同来向、同goal格、同时间bin、同50/100/150截短模式”。**替换的是整条查询，并没有给原来的同一个完整状态配上新标签。** donor的起点XY平均相差1.48（格宽4），XY速度平均相差1.92；goal时间距离均值约736→701。相同几何组不等于相同动力学状态。这是第一版方案的实质局限，而不是实现时漏拷贝状态。\n')
add('对8个1M冻结checkpoint重算，donor近端平均权重约65–67，移除查询约18–23；考虑实际替换率，donor占估计总近端权重质量的 **0.42%–0.44%**。这描述的是监督权重的覆盖，**不能作为参数梯度影响的上界**：上面的真实替换batch已测到约2.65%–2.95%的典型梯度变化。这里是终点冻结模型上的估计，不是历史百万次训练梯度的重建；另记录的output-gradient范数代理也不是参数梯度或Adam更新。见 [weighted_intervention.json](weighted_intervention.json)。\n')
add('**这支持“干预范围很窄”，但不足以把所有下降都解释成力度不够。** 同一批改动既带来H4/L1的改善，也带来H4/L2的回归；直接提高替换比例可能同时放大两类变化。\n')
add('## 4. 实际闭环行为：有改善，也有新停滞和更多返回\n')
rows=[]
for c,n in zip(configs,names):
 r=total(c);rows.append([n,f"{r['original_first_return_rate']:.2%} → {r['soft_first_return_rate']:.2%}",f"{r['original_union_return_excursion_steps']:.1f} → {r['soft_union_return_excursion_steps']:.1f}",f"{r['original_never_left_start_cell']:.2%} → {r['soft_never_left_start_cell']:.2%}"])
add(table(['结构','每岔口首次访问后的返回比例','返回区间并集步数/episode','始终未离开起始格'],rows)+'\n')
add('这些统计覆盖三个checkpoint。返回时间是观察到的游走时长，不是可避免成本的因果估计；一个返回也可能是合理纠错。为了避免把“走不到岔口”误当作“更少折返”，同时检查访问覆盖和起点停滞。\n')
add('在1M，进一步只比较双方都至少有5个episode的共同“task × 岔口 × 来向 × goal格”组，并给两边使用相同组权重：H4/L1的返回率 **7.37%→5.20%**；H4/L2 **6.67%→10.14%**。这说明H4/L2的返回问题不只是两种策略访问了不同的岔口。到达这些岔口时的完整状态仍可能不同，故这不是相同仿真状态的出口干预实验。\n')
add('![实际行为变化](figures/behavior_changes.png)\n')
add('H4/L2的Task5尤其明显：三个checkpoint均值成功率 **54.67%→18.67%**，始终留在起始格的比例 **12%→48%**。在1M分别为原模型36/50成功、2/50停滞，新模型12/50成功、26/50停滞。该task起始格是 **(5,9)**，**不是岔口**。这证明本轮回归还出现在采样干预区之外，不能只解释为“岔口第一出口没教好”。\n')
add('H4/L2在750个配对评估观察中丢失247次原本成功的结果，也新增102次成功；净减少145。丢失的247次中，42次新模型一直留在起始格，89次出现过返回。后两者不是完整、互斥的失败分类。起点停滞只是部分回归，Task1/3/4等其它损失仍需区分绕行、返回与预算耗尽。\n')
add('进一步看失败尾段：这247次丢失的成功中，112次在最后200步内相对该窗口起点的最大XY偏移不足1单位（格宽4）；阈值放宽到2单位为134次。说明还存在中途局部停滞，不能把剩余失败全称为“路线太长”。这是空间停滞的描述，与曾经返回可能重叠，不能单独判定高层或低层成因。见 [tail_stall_analysis.json](tail_stall_analysis.json)。\n')
add('## 5. executor是否已经坏了：固定真实局部目标诊断\n')
add('从验证集选择同一批64个完整仿真状态，目标是该真实轨迹50步后的状态，最多执行100步。原生条件用各模型自己的planner；teacher条件用同一个真实物理目标，随着当前状态重新编码，再交给该模型自己的executor。M3所有slot都截短到这个局部goal。所有模型从完全相同的qpos/qvel开始，没有训练更新。\n')
rows=[]
for c,n in zip(configs,names):
 a=local['runs']['original_'+c]['summary'];s=local['runs']['soft_'+c]['summary']
 rows.append([n,f"{a['predicted']['success_count']}/64 → {s['predicted']['success_count']}/64",f"{a['teacher']['success_count']}/64 → {s['teacher']['success_count']}/64"])
add(table(['结构','原生planner+executor','给定真实目标的executor'],rows)+'\n')
add('H4/L2的teacher条件都是 **62/64=96.875%**；原生条件只是55/64→54/64。这个局部测试不支持“executor整体丧失移动或目标跟踪能力”。它也不能证明executor在远目标、任意预测latent command下都没有问题；局部目标与正式navigation的输入分布不同。\n')
add('![局部控制测试](figures/local_control.png)\n')
add('## 6. 更直接的反事实：只改前50步command\n')
add('选择1M的Task5中**全部19个**“original成功、soft始终留在起始格”的配对案例。先按原seed完整重放soft，动作与已有记录逐元素一致，状态轨迹在1e−8精度内一致。然后保持同一个soft模型、同一完整初态、同一最终goal，仅在最初50步，每步t取original成功轨迹中的真实t+50/100/150状态作为参考，使用**soft自己的encoder**相对当前状态重新编码，交给**soft自己的executor**。50步之后恢复原生soft策略。没有跨模型混用latent坐标，也没有换低层权重；这不是把初始command固定保持50步，本实验没有检验计划保持策略。\n')
add(table(['条件','离开起始格','实际到达过岔口','最终成功'],[['soft原生重放','0/19','0/19','0/19'],['仅前50步参考command','16/19','16/19','7/19']])+'\n')
add('**这是目前最强的阶段定位证据：对这组失败，只改变早期command就能解除大部分停滞，并恢复部分最终成功。** 它把问题指向远目标条件下的早期command生成及其与executor形成的闭环，而不是只能归咎于执行器本身。\n')
add('这个实验使用了另一条成功轨迹的未来信息，是oracle诊断，不是可部署算法，也不是新的正式成功率。它是在选定失败案例上的因果干预，不能外推到所有task或整个19.33百分点下降；12/19在干预后仍失败，仍有后续规划/执行与预算问题。\n')
add('![早期command反事实计数](figures/prefix_rescue_counts.png)\n\n![前3个案例完整路径](figures/prefix_rescue_routes.png)\n')
add('## 7. high loss在变好，为何planning仍能变坏\n')
rows=[]
for c,n in zip(configs,names):
 aa=probe['runs']['original_'+c]['1000000'];bb=probe['runs']['soft_'+c]['1000000'];a=aa['waypoints'][-1];s=bb['waypoints'][-1]
 rows.append([n,f"{a['mse']:.4f} → {s['mse']:.4f}",f"{a['target_effective_rank']:.2f} → {s['target_effective_rank']:.2f}",f"{aa['actions']['teacher_data_mse']:.4f} → {bb['actions']['teacher_data_mse']:.4f}",f"{aa['actions']['predicted_data_mse']:.4f} → {bb['actions']['predicted_data_mse']:.4f}"])
add(table(['结构','近端latent MSE','目标encoder有效rank','teacher action MSE','predicted action MSE'],rows)+'\n')
add('这是同一批2,048条验证查询的1M检查，不是仅256条训练日志batch。H4/L2的近端MSE和两种action MSE都略有下降，但正式表现下降；H4/L1的近端MSE上升而正式表现改善。**latent拟合误差不能直接当作物理路径质量。** 不同模型的encoder坐标本身也在变化；有效rank没有出现此前value-only encoder那样的严重坍塌，因此本轮也不能沿用那一轮的解释。\n')
add('当前固定标准差Gaussian high loss，在固定encoder与value权重、忽略函数族约束时，可写成：\n\n```text\nL_H = E[ Σ_h c_h w_h (C + 1/2 || μ_h(s,g) − φ(s,s_h) ||²) ]\nμ*_h(s,g) = E[w_h φ(s,s_h) | s,g] / E[w_h | s,g]\n```\n\n因此它直接优化的是加权latent标签拟合。若相近输入仍有多个路线/动力学模态，均值未必是一条可执行、稳定的计划；采样偏好只能改变这个目标分布，不能自动保证均值落在可执行command上。**“均值落在不合适区域”是由损失形式支持的待验证假设，目前没有把19个停滞案例证明为具体的模态平均。**\n')
add('另外，训练时的loss不检查“执行预测command后是否真的出了岔口”，也不约束下一环境步的计划与当前选择保持一致。`_run_joint_planner`每次从`carry=None`开始，`sample_actions`每环境步重新调用；内部H/L循环不是跨环境时间的计划记忆。本轮刻意保留了这些v0设置。示范质量改善和闭环稳定性之间，仍隔着这些未被本轮直接约束的环节。\n')
add('原low/value **数据流**保持不变，也不等于它们训练后的**参数或语义**不变。goal encoder仍由high/low/value共同更新；high数据变化可以经共享表示改变value、AWR和executor。这是原v0允许的耦合，单步梯度隔离测试不能消除百万步训练中的这种间接效应。\n')
add('## 8. value能否自动把这些参考前缀扶正：目前不能假定\n')
add('在上述19个相同起点/goal上，比较original实际走过的未来状态与soft停滞轨迹的未来状态。两种模型自己的value对“最终成功参考轨迹状态”的偏好都不一致：\n')
rows=[]
for mode,label in [('original','original critic'),('soft','soft critic')]:
 for x in cv['models'][mode]['rows']:
  rows.append([label,x['horizon'],f"{x['reference_value_greater_count']}/19",f"{x['reference_weight_mean']:.2f}",f"{x['stall_weight_mean']:.2f}"])
add(table(['critic','h','参考状态V更高','参考前缀平均AWR权重','停滞前缀平均AWR权重'],rows)+'\n')
add('这说明不能想当然地认为现有AWR会一致强化能摆脱停滞的参考前缀。但**不能据此判定Bellman学习错误或critic把最优路线排错**：两条原生轨迹的后续策略不同，V也不是某个实际planner-command的Q；50步时16/19案例的两条未来仍在同一BFS距离层，涉及姿态和速度差异，后来成功不等于每个早期状态都有更高的最优剩余价值。若要改critic，应先补“从候选完整状态出发、统一后续策略和剩余预算”的校准实验。此项是针对失败上下文的线索，不替代该校准。\n')
add('## 9. 对用户提出的几种解释逐项判断\n')
add(table(['候选解释','本轮证据支持到哪里'],[
['采样实现有bug或污染low/value batch','未发现这类语义错误；独立采样/RNG/边界检查通过。但双forward的GPU数值路径影响尚未用空干预训练对照剥离。'],
['采样方法仍不够好','有依据：只改0.3869%总体查询、约1/5触发查询；匹配的是粗组，替换了完整初态/goal，非原状态上的反事实标签修复；不返回也不保证最优。'],
['改善数据本身不足以改善planning','不能一概而论，H4/L1有正向闭环变化；可以确认当前设计不稳定、未把局部示范改善可靠转化为全局表现。'],
['planning已经改善，只是executor无法转化成成功','H4/L2不支持这个前提：真实停滞与返回变坏，latent MSE下降不等于planning改善。teacher局部控制保持，早期command干预能救回部分案例。'],
['high actor训练目标仍有缺口','存在明确的目标/部署差距：加权latent拟合、Gaussian均值、每步重新规划，没有直接优化出岔口和时间一致性；但尚未证明某一个数学项是回归的唯一原因。'],
['H4/L2架构本身不适合','证据不足；只有一个训练seed，H/L改变与采样交互明显，不能从这一次定性否定HRM或L=2。']])+'\n')
add('## 10. 下一步的优先顺序\n\n1. **先补空干预控制。** 同一个成熟v0 checkpoint、同一Adam状态、同一原sampler RNG，比较原单forward、双forward但不换样本、双forward加真实软采样。优先用回归最明显的H4/L2，再用H4/L1核对。这能先分开实现路径影响与采样方向；短程续训只能诊断局部更新方向，若要解释从头训练的最终差异仍需相应完整空对照。本次没有启动这些训练，也没有扩展原16组队列。\n2. **固定任务条件下的失败诊断。** 保留Task5非岔口起点停滞、共同岔口返回、teacher局部控制和前50步参考command实验。平均success和latent MSE之外，需要能看到“尚未到岔口就失败”的情况。\n3. **再区分监督偏好、状态匹配与闭环约束。** 若真实采样相对空对照仍回归，检查同完整状态下的有益方向是否获得更高相对训练偏好、新command是否可执行，再考虑更严格位置/速度匹配或计划持续性。不要同时改β、critic和多种结构。\n4. **若转向critic，先做同一后续策略下的候选状态校准。** 当前失败上下文已经具体，可先验证value的判别对象是否符合planner需要，再决定是否设计新的high value。\n\n暂不建议仅依据这轮结果扩大替换比例或继续扩大H/L网格。我们已经有“局部示范质量提高、全局行为仍可退化”的可复现实例，也发现了应补的实验控制；下一步应先让训练改动对既有行为的影响更容易归因。\n')
add('## 文件与复现\n')
add(table(['文件','内容'],[
['[paired_results.csv](paired_results.csv) / [task_results.csv](task_results.csv)','配对成功率、区间、分task变化'],
['[episode_metrics.csv](episode_metrics.csv) / [junction_events.csv](junction_events.csv)','6000次正式episode观察的运动、停滞和岔口事件'],
['[matched_context_results.csv](matched_context_results.csv)','共同几何上下文中的返回率'],
['[training_summary.json](training_summary.json) / [checkpoint_probes.json](checkpoint_probes.json)','固定验证batch与2048条共同查询的loss/表示/动作探针'],
['[local_goal_isolation.json](local_goal_isolation.json)','64个局部任务×8模型×2模式，含每条轨迹'],
['[initial_command_rescue.json](initial_command_rescue.json) / [initial_command_rescue_paths.npz](initial_command_rescue_paths.npz)','19个选定失败案例的原生重放与前缀反事实'],
['[intervention_geometry.json](intervention_geometry.json) / [weighted_intervention.json](weighted_intervention.json)','替换内容与冻结终点权重质量估计'],
['[failure_context_value.json](failure_context_value.json)','相同官方起点的两条真实未来状态value比较'],
['[gradient_controls.json](gradient_controls.json) / [gradient_controls_highest.json](gradient_controls_highest.json)','生产GPU上的空双前向、真实采样梯度差异及精度敏感性复核'],
['[verification.json](verification.json) / [provenance.json](provenance.json)','计算口径、原材料路径与hash'],
['snapshot/ / analysis_code/ / logs/ / figures/','完成seed0日志快照、分析脚本、诊断日志及PNG/SVG图'],
['[report.html](report.html)','无需网络的静态报告；模型与原始数据复算路径见provenance']])+'\n')
add('报告、图像和已计算的结果可在本文件夹内阅读。复算模型/模拟器诊断需要原campaign的checkpoint、验证集及兼容Python依赖；本次没有把这些大原材料再复制到报告目录，也没有删除它们。\n')
md='\n'.join(b);(R/'README.md').write_text(md)
content=MarkdownIt('commonmark',{'html':False}).enable('table').render(md)
css='''body{margin:0;background:#eff2f5;color:#233643;font:16px/1.8 system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif}main{max-width:1160px;margin:30px auto;padding:35px 48px;background:white;border-radius:12px}h1{font-size:29px;line-height:1.5;color:#164853}h2{font-size:23px;border-top:1px solid #dae3e9;padding-top:22px;margin-top:44px}strong{color:#175d65}a{color:#196d94}img{max-width:100%;height:auto}table{border-collapse:collapse;display:block;overflow-x:auto;margin:20px 0;font-size:14px}th,td{border-bottom:1px solid #dce4e9;padding:9px 12px;text-align:left;min-width:85px}th{background:#e9f2f2}tbody tr:nth-child(even){background:#f7f9fb}pre{background:#f1f5f7;padding:18px;overflow-x:auto;border-radius:8px}code{font-size:.9em}@media(max-width:850px){main{margin:0;padding:20px}}'''
(R/'report.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>高层采样seed0结果分析</title><style>'+css+'</style></head><body><main>'+content+'</main></body></html>')
print('REPORT WRITTEN',R)
