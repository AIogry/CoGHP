"""Descriptive terminal spatial stagnation on saved official trajectories."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import json
import numpy as np
R=Path(__file__).resolve().parents[1];C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
rows=json.loads((R/'episode_metrics.json').read_text());bykey={(r['method'],r['step'],r['task'],r['episode']):r for r in rows};out=[]
for method in sorted({r['method'] for r in rows}):
 a=C/f'runs/{method}/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts'
 for step in [800000,900000,1000000]:
  for task in range(1,6):
   with np.load(a/f'behavior/step_{step}/task_{task}.npz') as z:xy=z['next_observation'][:,:2];offset=z['episode_offsets']
   for ep in range(50):
    r=bykey[(method,step,task,ep)];lo,hi=offset[ep:ep+2];p=xy[max(lo,hi-200):hi];exc=float(np.linalg.norm(p-p[0],axis=1).max())
    out.append({'method':method,'step':step,'task':task,'episode':ep,'success':r['success'],'tail200_max_excursion':exc,'tail_stall_lt1':not r['success'] and exc<1.,'tail_stall_lt2':not r['success'] and exc<2.})
summary=[];lookup={(r['method'],r['step'],r['task'],r['episode']):r for r in out}
for conf in ['h2l1_m1','h2l1_m3','h4l1_m3','h4l2_m3']:
 d={'config':conf}
 for mode in ['original','soft']:
  failed=[r for r in out if r['method']==mode+'_'+conf and not r['success']]
  d[mode+'_failure_count']=len(failed);d[mode+'_tail_stall_lt1']=sum(r['tail_stall_lt1'] for r in failed);d[mode+'_tail_stall_lt2']=sum(r['tail_stall_lt2'] for r in failed)
 lost=[r for r in out if r['method']=='soft_'+conf and not r['success'] and lookup[('original_'+conf,r['step'],r['task'],r['episode'])]['success']]
 d['lost_success_count']=len(lost);d['lost_with_tail_stall_lt1']=sum(r['tail_stall_lt1'] for r in lost);d['lost_with_tail_stall_lt2']=sum(r['tail_stall_lt2'] for r in lost);summary.append(d)
(R/'tail_stall_analysis.json').write_text(json.dumps({'definition':'Failed rollout, maximum XY excursion during final200 states from first of these states <1 or2 world units; cell width4. This is spatial stagnation, not proof of its cause.','summary':summary,'episodes':out},indent=2)+'\n')
