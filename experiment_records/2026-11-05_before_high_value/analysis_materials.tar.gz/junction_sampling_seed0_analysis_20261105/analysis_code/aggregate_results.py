"""Completed seed0 paired outcomes, actual movement, and intervention content."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from collections import defaultdict, deque
import csv, json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
CAMPAIGN=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
STEPS=[800000,900000,1000000]
CONFIGS=['h2l1_m1','h2l1_m3','h4l1_m3','h4l2_m3']
def readcsv(p):return [{k:float(v) for k,v in r.items() if v!=''} for r in csv.DictReader(p.open())]
def dump(name,rows):
    (ROOT/(name+'.json')).write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
    if isinstance(rows,list) and rows:
        keys=list(dict.fromkeys(k for r in rows for k in r))
        with (ROOT/(name+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in rows)
geometry=json.loads(next(CAMPAIGN.glob('runs/original_h2l1_m1/**/seed_000/**/artifacts/junction_geometry.json')).read_text())
free={tuple(x) for x in geometry['free_cells']};adj={tuple(map(int,k.split(','))):[tuple(x) for x in v] for k,v in geometry['adjacency'].items()}
dist={}
for g in free:
    d={g:0};q=deque([g])
    while q:
        u=q.popleft()
        for v in adj[u]:
            if v not in d:d[v]=d[u]+1;q.append(v)
    dist[g]=d
def cells(xy):return np.floor((np.asarray(xy)-geometry['origin_xy'])/4+.5).astype(int)[:,::-1]
episode_rows=[];events=[];summary=[];training=[];configs={};stored={};evaluation=[]
for name in [x+'_'+c for c in CONFIGS for x in ['original','soft']]:
    snap=ROOT/'snapshot/runs'/name;state=json.loads((snap/'run.json').read_text());a=Path(state['run_dir'])/'artifacts'
    cfg=json.loads((snap/'flags.json').read_text())['agent'];configs[name]=cfg
    train=readcsv(snap/'train.csv');ev=readcsv(snap/'eval.csv');evaluation.extend(dict(method=name,**r) for r in ev)
    assert [int(r['step']) for r in train]==list(range(5000,1000001,5000))
    assert len(ev)==10 and all(np.isfinite(list(r.values())).all() for r in train)
    # One fixed validation batch; compare whole final window, not its luckiest row.
    late=[r for r in train if r['step']>=800000]
    tr={'method':name,'mean_score':state['metric']['mean']}
    for k in late[0]:
        if k.startswith(('validation/','validation_action/','training/grad','sampling/')):
            tr[k]=float(np.mean([r[k] for r in late]))
    if name.startswith('soft'):
        tr['total_replacements']=int(sum(r['sampling/interval_replacements'] for r in train))
        tr['overall_replacement_fraction']=tr['total_replacements']/(1000000*256)
        tr['sampler_series']=[r['sampling/interval_replacements'] for r in train]
    training.append(tr)
    for step in STEPS:
        official=next(r for r in ev if int(r['step'])==step)
        for task in range(1,6):
            p=a/'behavior'/f'step_{step}'/f'task_{task}.json';b=json.loads(p.read_text())
            with np.load(p.with_suffix('.npz')) as archive:
                z={key:archive[key] for key in ['observation','next_observation','goal','episode_offsets']}
            assert len(b['episodes'])==50 and abs(np.mean([e['success'] for e in b['episodes']])-official[f'evaluation/task{task}_success'])<1e-9
            for ep in b['episodes']:
                i=ep['episode_index'];lo,hi=z['episode_offsets'][i:i+2]
                obs=np.concatenate([z['observation'][lo:lo+1],z['next_observation'][lo:hi]])
                xy=obs[:,:2];ij=cells(xy);goal=z['goal'][i];gc=tuple(cells(goal[None,:2])[0]);ds=np.array([dist[gc].get(tuple(v),np.nan) for v in ij])
                displacement=np.linalg.norm(xy-xy[0],axis=1);path=np.linalg.norm(np.diff(xy,axis=0),axis=1).sum()
                key=(name,step,task,i);stored[key]={'start':obs[0].copy(),'goal':goal.copy(),'seed':ep['metadata']['episode_seed']}
                rr={'method':name,'step':step,'task':task,'episode':i,'episode_seed':ep['metadata']['episode_seed'],
                    'success':int(ep['success']),'steps':ep['steps'],'path_length':float(path),
                    'max_displacement':float(displacement.max()),'never_left_start_cell':bool(np.all(ij==ij[0])),
                    'max_displacement_lt1':bool(displacement.max()<1),'max_displacement_lt2':bool(displacement.max()<2),'max_displacement_lt4':bool(displacement.max()<4),
                    'first100_max_displacement':float(displacement[:101].max()),
                    'initial_goal_cells':int(ds[0]),'best_goal_cells':float(np.nanmin(ds)),'final_goal_cells':float(ds[-1]),
                    'best_cell_progress':float(ds[0]-np.nanmin(ds)),'final_cell_progress':float(ds[0]-ds[-1]),
                    'mean_body_z':float(obs[:,2].mean()),'body_z_below_0p2_fraction':float(np.mean(obs[:,2]<.2)),
                    'mean_xy_velocity':float(np.linalg.norm(obs[:,15:17],axis=1).mean()),
                    'goal_min_xy_distance':float(np.linalg.norm(xy-goal[:2],axis=1).min()),
                    'junction_visits':ep['junction_visits'],'distinct_junctions':ep['distinct_junctions'],
                    'known_exit_visits':ep['known_exit_visits'],'returned_visits':ep['returned_known_exit_visits'],
                    'first_known_exit_visits':ep['first_known_exit_visits'],'first_visit_returns':ep['first_visit_returns'],
                    'union_return_excursion_steps':ep['union_return_excursion_steps'],'no_exit_visits':ep['no_exit_observed_visits']}
                episode_rows.append(rr)
                for e in ep['events']:events.append({'method':name,'step':step,'task':task,'episode':i,'episode_success':int(ep['success']),**e})
    print('AGGREGATED',name,flush=True)

# Paired bootstrap of episode identities, repeated checkpoints kept together.
rng=np.random.default_rng(20261105);boot=np.stack([rng.integers(0,50,(4000,50)) for _ in range(5)],axis=1)
pairs=[];taskpairs=[]
for c in CONFIGS:
    a='original_'+c;b='soft_'+c
    for step in STEPS:
        for task in range(1,6):
            for i in range(50):
                x=stored[a,step,task,i];y=stored[b,step,task,i]
                assert x['seed']==y['seed'] and np.array_equal(x['start'],y['start']) and np.array_equal(x['goal'],y['goal'])
    for step in [*STEPS,'all']:
        aa=[r for r in episode_rows if r['method']==a and (step=='all' or r['step']==step)]
        bb=[r for r in episode_rows if r['method']==b and (step=='all' or r['step']==step)]
        aa=sorted(aa,key=lambda x:(x['task'],x['episode'],x['step']));bb=sorted(bb,key=lambda x:(x['task'],x['episode'],x['step']))
        yy=np.array([y['success']-x['success'] for x,y in zip(aa,bb)]).reshape(5,50,-1).mean(2)
        draws=np.stack([yy[t][boot[:,t]].mean(1) for t in range(5)],axis=1).mean(1)
        p=dict(config=c,step=step,original_success=float(np.mean([x['success'] for x in aa])),soft_success=float(np.mean([x['success'] for x in bb])),
               delta_pp=float(100*yy.mean()),ci95_pp=(100*np.quantile(draws,[.025,.975])).tolist())
        for label,rows in [('original',aa),('soft',bb)]:
            for key in ['never_left_start_cell','max_displacement_lt1','max_displacement_lt2','max_displacement_lt4','first100_max_displacement','path_length','mean_body_z','body_z_below_0p2_fraction','mean_xy_velocity','best_cell_progress','final_cell_progress','junction_visits','distinct_junctions','union_return_excursion_steps']:
                p[label+'_'+key]=float(np.mean([r[key] for r in rows]))
            n=sum(r['first_known_exit_visits'] for r in rows);v=sum(r['first_visit_returns'] for r in rows)
            p[label+'_first_return_rate']=v/n if n else None
            p[label+'_first_exit_count']=n;p[label+'_first_return_count']=v
            p[label+'_zero_junction_fraction']=float(np.mean([r['junction_visits']==0 for r in rows]))
            success=[r for r in rows if r['success']];p[label+'_success_steps']=float(np.mean([r['steps'] for r in success])) if success else None
        pairs.append(p)
        for t in range(1,6):
            x=[r for r in aa if r['task']==t];y=[r for r in bb if r['task']==t]
            taskpairs.append(dict(config=c,step=step,task=t,original_success=float(np.mean([r['success'] for r in x])),soft_success=float(np.mean([r['success'] for r in y])),
                 original_stall=float(np.mean([r['never_left_start_cell'] for r in x])),soft_stall=float(np.mean([r['never_left_start_cell'] for r in y])),
                 original_zero_junction=float(np.mean([r['junction_visits']==0 for r in x])),soft_zero_junction=float(np.mean([r['junction_visits']==0 for r in y]))))

# Actual initially encountered junction contexts common to both policies; same
# geometric context does NOT imply identical full states at arrival.
context=[]
for c in CONFIGS:
    for step in STEPS:
        groups=defaultdict(lambda:[[],[]])
        for e in events:
            if e['step']!=step or e['method'] not in ('original_'+c,'soft_'+c) or not e['first_visit_at_junction'] or e['incoming'] is None or e['first_exit'] is None or e['junction']==e['goal_cell']:continue
            key=(e['task'],tuple(e['junction']),tuple(e['incoming']),tuple(e['goal_cell']))
            groups[key][int(e['method'].startswith('soft'))].append(e)
        for threshold in [1,5]:
            shared=[(k,x,y) for k,(x,y) in groups.items() if len({a['episode'] for a in x})>=threshold and len({a['episode'] for a in y})>=threshold]
            weights=np.array([len(x)+len(y) for _,x,y in shared],float)
            if len(weights):weights/=weights.sum()
            out={'config':c,'step':step,'min_episodes_per_side':threshold,'common_groups':len(shared),'original_visits':sum(len(x) for _,x,y in shared),'soft_visits':sum(len(y) for _,x,y in shared)}
            for k,idx in [('original',1),('soft',2)]:
                out[k+'_standardized_return_rate']=float(sum(w*np.mean([e['returned'] for e in group[idx]]) for w,group in zip(weights,shared))) if shared else None
            context.append(out)

# Exactly which real labels were replaced during the independent preparation.
z=np.load(CAMPAIGN/'preflight/sampling/preparation_queries.npz');idx=np.flatnonzero(z['replaced'])
index=np.load(CAMPAIGN/'preflight/sampling/junction_index.npz');meta=json.loads((CAMPAIGN/'preflight/sampling/junction_index.json').read_text())
nc=meta['geometry']['lattice_shape'][1];em=index['event_matrix'];fv=index['frame_visits'];fc=index['frame_cells']
src=z['original_start'][idx];dst=z['start_indices'][idx];goal=z['original_goal'][idx]
vs=fv[src];vd=fv[dst];gc=[divmod(int(x),nc) for x in fc[goal]]
def shorter(v,g):
    J=divmod(int(em[v,1]),nc);e=divmod(int(em[v,3]),nc);return dist[g][e]==dist[g][J]-1
old=np.array([shorter(v,g) for v,g in zip(vs,gc)]);new=np.array([shorter(v,g) for v,g in zip(vd,gc)])
intervention={'replacements':len(idx),'original_short_exit_fraction':float(old.mean()),'donor_short_exit_fraction':float(new.mean()),
    'transitions':{f'{a}->{b}':int(np.sum((old==bool(a))&(new==bool(b)))) for a in [0,1] for b in [0,1]},
    'note':'BFS is a descriptive proxy only; sampler did not optimize it. Replacements are complete queries at different full states.'}
for a in [*STEPS,'all']:
    for c in CONFIGS:
        rows=[r for r in pairs if r['config']==c and r['step']==a];assert len(rows)==1
dump('paired_results',pairs);dump('task_results',taskpairs);dump('episode_metrics',episode_rows);dump('junction_events',events)
dump('matched_context_results',context);dump('training_summary',training);dump('evaluation_curves',evaluation);dump('intervention_geometry',intervention)
dump('verification',dict(seed0_runs=8,official_episodes=6000,paired_full_starts_and_goals_exact=True,success_matches_official_logs=True,all_training_metrics_finite=True,
     bootstrap='4000 paired resamples of50 episode identities per task; checkpoints retained as a cluster. Conditional evaluation uncertainty, not training-seed uncertainty.',no_training_updates=True))
print('RESULTS',json.dumps([r for r in pairs if r['step']=='all']))
print('INTERVENTION',json.dumps(intervention))
