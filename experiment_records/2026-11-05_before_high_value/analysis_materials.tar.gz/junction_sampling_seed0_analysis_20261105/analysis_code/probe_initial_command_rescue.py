"""Selected failure diagnosis: physical reference commands for first50 steps only.

Same soft policy/encoder/executor, exact task5 reset and full goal; no training.
All cases with original success and soft never leaving initial cell at1M are used.
This oracle-prefix intervention is not a deployable algorithm or population eval.
"""
import sys
sys.dont_write_bytecode = True
import os,sys,json
from pathlib import Path
os.environ.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',EGL_PLATFORM='surfaceless',PYTHONDONTWRITEBYTECODE='1')
os.environ.pop('MUJOCO_EGL_DEVICE_ID',None)
ROOT=Path(__file__).resolve().parents[1];C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
sys.path[:0]=[str(C/'source/impls'),str(C/'source')]
import numpy as np
import jax,jax.numpy as jnp
import ogbench
from agents.navigation import NavigationAgent
from utils.flax_utils import restore_agent
from utils.junction_behavior import summarize_episode
rows=json.loads((ROOT/'episode_metrics.json').read_text())
lookup=lambda mode:{r['episode']:r for r in rows if r['method']==mode+'_h4l2_m3' and r['step']==1000000 and r['task']==5}
base,soft=lookup('original'),lookup('soft');cases=[i for i in sorted(base) if base[i]['success'] and soft[i]['never_left_start_cell']]
art=lambda mode:C/'runs'/f'{mode}_h4l2_m3/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts'
with np.load(art('original')/'behavior/step_1000000/task_5.npz') as f:orig={k:f[k] for k in f.files}
with np.load(art('soft')/'behavior/step_1000000/task_5.npz') as f:saved={k:f[k] for k in f.files}
meta=json.loads((art('soft')/'behavior/step_1000000/task_5.json').read_text());geo=meta['geometry']
flags=json.loads((art('soft')/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
agent=NavigationAgent.create(0,saved['observation'][:1],saved['action'][:1],cfg);agent=restore_agent(agent,str(art('soft')),1000000,json.loads((art('soft')/'checkpoint_metadata.json').read_text()),True)
env=ogbench.make_env_and_datasets(flags['env_name'],env_only=True)
@jax.jit
def teacher(agent,ob,goal,targets,key):
 label=agent.network.select('goal_rep')(jnp.concatenate([jnp.broadcast_to(ob,targets.shape),targets],axis=-1))[None]
 dist=agent.policy(ob[None],goal[None],key,commands=label,temperature=0.,chain_source='teacher')[1]
 return jnp.clip(dist.mode()[0],-1,1)
result={'protocol':'first50-physical-reference-prefix-counterfactual','cases':cases,'selection':'All task5 episodes at1M where original H4L2M3 succeeds and soft H4L2M3 never leaves initial cell. Selected failures, not a population estimate.','prefix_steps':50,'source_of_reference':'Successful ORIGINAL recorded full states at t+50/100/150, re-encoded by SOFT encoder at each current state. After step50 return to unmodified SOFT native policy.','training_updates':0,'rows':[]}
paths={}
for mode in ['native_replay','reference_prefix50']:
 for i in cases:
  lo,hi=saved['episode_offsets'][i:i+2];ol,oh=orig['episode_offsets'][i:i+2]
  ref=np.concatenate([orig['observation'][ol:ol+1],orig['next_observation'][ol:oh]])
  md=meta['episodes'][i]['metadata'];ob,info=env.reset(seed=md['episode_seed'],options={'task_id':5,'render_goal':False});goal=info['goal']
  assert np.array_equal(ob,saved['observation'][lo]) and np.array_equal(goal,saved['goal'][i])
  key=jax.random.PRNGKey(md['actor_seed']);path=[ob.copy()];asave=[];done=False
  for t in range(1000):
   key,k=jax.random.split(key)
   if mode=='reference_prefix50' and t<50:
    targets=ref[np.minimum(t+np.array([150,100,50]),len(ref)-1)]
    action=np.asarray(teacher(agent,ob.astype(np.float32),goal.astype(np.float32),targets.astype(np.float32),k))
   else:action=np.asarray(agent.sample_actions(observations=ob,goals=goal,seed=k,temperature=0.))
   action=np.clip(action,-1,1);ob,reward,terminated,truncated,info=env.step(action);path.append(ob.copy());asave.append(action.copy())
   if terminated or truncated:break
  path=np.asarray(path);actions=np.asarray(asave)
  if mode=='native_replay':
   assert np.array_equal(actions,saved['action'][lo:hi])
   assert np.allclose(path[1:],saved['next_observation'][lo:hi],atol=1e-8,rtol=1e-8)
  summary=summarize_episode(path,goal,geo,success=bool(info['success']),terminated=terminated,truncated=truncated,episode_index=i)
  ij=np.floor((path[:,:2]-geo['origin_xy'])/4+.5).astype(int)
  rr={'episode':i,'mode':mode,'success':bool(info['success']),'steps':t+1,'left_start_cell':bool(np.any(ij!=ij[0])),'junction_visits':summary['junction_visits'],'first_visit_returns':summary['first_visit_returns'],'first50_max_displacement':float(np.linalg.norm(path[:51,:2]-path[0,:2],axis=1).max()),'final_goal_distance':float(np.linalg.norm(path[-1,:2]-goal[:2]))}
  result['rows'].append(rr);paths[f'{mode}_{i}']=path
  (ROOT/'initial_command_rescue.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(rr),flush=True)
env.close();result['complete']=True;result['native_replay_matches_saved_actions_and_states']=True
(ROOT/'initial_command_rescue.json').write_text(json.dumps(result,indent=2)+'\n');np.savez_compressed(ROOT/'initial_command_rescue_paths.npz',**paths)
