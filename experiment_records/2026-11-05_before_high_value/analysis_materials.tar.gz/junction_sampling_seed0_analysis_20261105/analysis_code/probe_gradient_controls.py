"""Production-GPU frozen gradients: single forward, sham split, real split.

No optimizer step or model update. All16 first sampler batches are retained,
including zero replacements. Data and donor RNG match the formal seed0 run.
"""
import sys
sys.dont_write_bytecode = True
import os,sys,json,argparse
from pathlib import Path
os.environ.update(CUDA_VISIBLE_DEVICES='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',JAX_PLATFORMS='cuda',XLA_PYTHON_CLIENT_PREALLOCATE='false',XLA_FLAGS='--xla_gpu_deterministic_ops',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
R=Path(__file__).resolve().parents[1];C=Path('/data/qijunrong/06-RL/offline-rl/exp/joint_planner_v0_junction_sampling_hlm_seed01_20261104')
sys.path[:0]=[str(C/'source/impls'),str(C/'source')]
import numpy as np
import jax
from agents.navigation import NavigationAgent
from ogbench.utils import load_dataset
from utils.datasets import Dataset,MultiHGCDataset
from utils.junction_sampling import JunctionRouteIndex,JunctionHighSampler
from utils.evaluation import derive_seed
from utils.flax_utils import restore_agent
assert jax.default_backend()=='gpu'
parser=argparse.ArgumentParser();parser.add_argument('--precision',choices=['default','highest'],default='default');parser.add_argument('--batches',type=int,default=16);args=parser.parse_args()
if args.precision=='highest':jax.config.update('jax_default_matmul_precision','highest')
output=R/('gradient_controls.json' if args.precision=='default' else 'gradient_controls_highest.json')
raw=load_dataset('/data/qijunrong/06-RL/offline-rl/data/raw_ogbench/antmaze-giant-navigate-v0.npz',compact_dataset=True)
idx=JunctionRouteIndex.load(C/'preflight/sampling/junction_index');obs=raw['observations']
result={'checkpoint':1000000,'physical_gpu':1,'optimizer_updates':0,'sampling_batches':args.batches,'matmul_precision':args.precision,'interpretation':'Frozen mature original-model gradients only. Sham split preserves every example. Real split uses unchanged production donor sampler. Numerical graph differences are compared to semantic intervention, not claimed to predict entire training trajectories.','models':{}}
def compare(a,b):
 leaves=list(zip(jax.tree_util.tree_leaves(a),jax.tree_util.tree_leaves(b)));sq=0.;norm=0.;mx=0.;changed=0
 for x,y in leaves:
  x=np.asarray(x,dtype=np.float64);y=np.asarray(y,dtype=np.float64);d=x-y;sq+=float(np.sum(d*d));norm+=float(np.sum(y*y));mx=max(mx,float(np.max(abs(d))));changed+=int(np.count_nonzero(d))
 return {'difference_norm':float(np.sqrt(sq)),'reference_norm':float(np.sqrt(norm)),'relative_difference':float(np.sqrt(sq/max(norm,1e-30))),'max_absolute_difference':mx,'different_elements':changed}
for conf in ['h4l1_m3','h4l2_m3']:
 art=C/f'runs/original_{conf}/antmaze-giant-navigate-v0/seed_000/attempt_000/artifacts';flags=json.loads((art/'flags.json').read_text());cfg={k:tuple(v) if isinstance(v,list) else v for k,v in flags['agent'].items()}
 ds_seed=json.loads((art/'reproducibility.json').read_text())['train_dataset_seed'];sampler=MultiHGCDataset(Dataset.create(**raw),cfg,rng=np.random.default_rng(ds_seed));donor=JunctionHighSampler(idx,obs,.5,derive_seed(ds_seed,51004),5,3)
 model=NavigationAgent.create(0,obs[:1],raw['actions'][:1],cfg);agent=restore_agent(model,str(art),1000000,json.loads((art/'checkpoint_metadata.json').read_text()),True)
 @jax.jit
 def gradients(agent,b):return jax.grad(lambda params:agent.total_loss(b,params,jax.random.PRNGKey(20261105))[0])(agent.network.params)
 rows=[]
 for i in range(args.batches):
  b=sampler.sample(256);d=donor.sample(b['indices'],b['high_actor_goal_idxs'],b['high_actor_target_idxs'])
  sham={**b,'high_only_observations':b['observations'],'high_only_goals':b['high_actor_goals'],'high_only_targets':b['high_actor_targets']}
  real={**b,'high_only_observations':obs[d['start_indices']],'high_only_goals':obs[d['goal_indices']],'high_only_targets':obs[d['target_indices']]}
  g0=gradients(agent,b);g1=gradients(agent,sham);g2=gradients(agent,real)
  row={'batch':i,'replacements':int(d['replaced'].sum()),'sham_vs_single':compare(g1,g0),'real_vs_sham':compare(g2,g1),'by_module':{name:compare(g2[name],g1[name]) for name in g1}}
  rows.append(row);print(conf,i,row['replacements'],row['sham_vs_single']['relative_difference'],row['real_vs_sham']['relative_difference'],flush=True)
 result['models'][conf]=rows;output.write_text(json.dumps(result,indent=2)+'\n');jax.clear_caches()
result['complete']=True;output.write_text(json.dumps(result,indent=2)+'\n')
